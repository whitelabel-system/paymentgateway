<?php
session_start();
include "include.php";
include "session.php";
$editor = "1";

if ($_GET['user_id'] > 0 && $_GET['withdrawal_request_id'] > 0) {
    $user_id = $_GET['user_id'];
    $withdrawal_request_id = $_GET['withdrawal_request_id'];
} else {
    $o1->ticket_id = 0;
}

if (isset($_GET['aid'])) {
    $o1->ticket_id = $_GET['aid'];
} else {
    $o1->ticket_id = 0;
}
if ($o1->ticket_id > 0) {
    $o1 = $factory->get_object($o1->ticket_id, "tickets", "ticket_id");
} else {
    $o1->is_active = 1;
}
if ($_GET['uid'] > 0) {
    $user_id = $_GET['uid'];
}
if ($_GET['cid'] > 0) {
    $chargeback_id = $_GET['cid'];
}
if ($chargeback_id > "0") {
    $sql = "select user_id from chargeback where chargeback_id='" . $chargeback_id . "' ";
    $res = getXbyY($sql);
    $user_id = $res[0]['user_id'];
}
if ($_GET['did'] > "0") {
    $dispute_id = $_GET['did'];
    $sql = "select user_id from disputes where dispute_id='" . $dispute_id . "' ";
    $res = getXbyY($sql);
    $user_id = $res[0]['user_id'];
}
if ($_GET['rid'] > "0") {
    $wallet_id = $_GET['rid'];
    $sql = "select user_id from wallet where wallet_id='" . $wallet_id . "' ";
    $res = getXbyY($sql);
    $user_id = $res[0]['user_id'];
}

include "includes/header.php";
include "html/add_ticket.php";
include "includes/footer.php";
include "js/add_ticket.js";
?>