 <?php
session_start();
include"include.php";
include"session.php";

if ($_POST['updte']=="1") {

$o1->chargeback_id =$_POST['chargeback_id'];
$o1 = $factory->get_object($o1->chargeback_id , "chargeback" ,"chargeback_id");
$o2 = $factory->get_object($o1->wallet_id , "wallet" ,"wallet_id");
$o4 = $factory->get_object($o1->user_id , "users" ,"user_id");
$o8 = $factory->get_object("1" , "users" ,"user_id");

$o1->resolved_by = $o->user_id;
$o1->resolution_date = todaysDate();
$o1->chargeback_resolution = $_POST['chargeback_resolution'];

if ($_POST['chargeback_status1'] =="Approve") {
	$o1->chargeback_status = "Approve";
	$o2->disputed="Approved";


	$o5->user_id = $o4->user_id;
	$o5->user_name = $o4->user_name." ".$o4->name;
	$o5->transaction_type = "Chargeback";
	$o5->user_old_balance = $o4->amount_balance ;
	$o5->amount = $o2->amount;
$o5->user_new_balance = $o5->user_old_balance - $o2->amount;
$o5->transaction_details = $_POST['chargeback_resolution'];
$o5->transaction_date = todaysDate();
$o5->month_year =  date("F") . "-" . date('Y');
$o5->status = "Success";
$o5->created_at  = todaysDate();
$o5->updated_at  = todaysDate();
$o5->ref_number = $o1->transaction_number;
$o5->year = date('Y');
$o5->wallet_id = $insertor->insert_object($o5,"wallet");
	$o4->amount_balance = $o4->amount_balance - $o2->amount;
	$o4->disputed_amount = $o4->disputed_amount - $o2->amount;
$o8->admin_chargeback_amount = $o8->admin_chargeback_amount + $o2->amount;

	
}else{
$o1->chargeback_status = "Reject";	
$o2->disputed="Rejected";
}
$o8->user_id = $updater->update_object($o8, "users");

$o1->chargeback_id = $updater->update_object($o1, "chargeback");
$o2->wallet_id = $updater->update_object($o2, "wallet");
$o4->user_id = $updater->update_object($o4, "users");
$notification = "Chargeback has been ".$o2->disputed." against transaction number ".$o1->transaction_number." ";
insert_notifications("1",$notification , "chargeback");

$result['error']="1";
$result['error_msg'] ="Chargeback responded Accordingly";

}else{
	$result['error']="0";
}



echo json_encode($result);
?>