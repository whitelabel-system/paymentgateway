<?php

session_start();
include"include.php";
include"session.php";
$page_name = "disputes";
unset($_SESSION['dispute_search']);
//unset($_SESSION['payment_search']);
$tables = '1';
// pt($_GET);
if ($_GET['status'] != '') {
    $status = $_GET['status'];
    $_SESSION['dispute_search']['status'] = $status;
} else {
    $status = 'Pending';
}
if ($status == 'All') {
    $sql = "Select * from disputes where is_active ='1'  ";
} else {
    $sql = "Select * from disputes where is_active ='1' and dispute_status ='" . $status . "'";
}
// pt($sql);
$res = getXbyY($sql);
$rows = count($res);

include "includes/header.php";
include "html/disputes.php";
include "includes/footer.php";
include "js/disputes.js";
?>