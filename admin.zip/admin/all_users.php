<?php
session_start();
include"include.php";
include"session.php";



$tables = '1';


$trigger ="user_type='Staff'";	

$sql = "select * from users where user_type!='Admin' and $trigger and parent_id='".$o->user_id."' order by user_id Desc ";
$res = getXbyY($sql);
$row = count($res);


include "includes/header.php";
include "html/all_users.php";
include "includes/footer.php";
include "js/all_users.js";
?>
