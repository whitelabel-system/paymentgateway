<?php
session_start();
include"include.php";
include"session.php";
$page_name ="chargeback";
unset($_SESSION['chargeback_search']);
$tables = '1';

$sql = "Select * from chargeback  ";
$res = getXbyY($sql);
$rows = count($res);
include "includes/header.php";
include "html/chargeback.php";
include "includes/footer.php";
include "js/chargeback.js";
?>