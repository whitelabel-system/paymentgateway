<?php
session_start();
include"include.php";
include"sesion.php";


if ($_POST['updte']=="1") {


	$o2 = $factory->get_object($_POST['user_id'],"users", "user_id");

	if ($_POST['plan_id']=="custom") {


		$o1->pricing_name =$_POST['pricing_name'];
		$o1->gateway_transaction_fees = $_POST['gateway_transaction_fees'];
		$o1->gateway_fees_type = $_POST['gateway_fee_type'];
		$o1->gateway_max_fee = $_POST['gateway_max_fee'];
		$o1->monthly_maintaince_fees = $_POST['monthly_maintaince_fees'];
		$o1->monthly_fee_type = $_POST['monthly_fee_type'];
		$o1->monthly_max_fee = $_POST['monthly_max_fee'];

		$o1->annual_maintaince_fees = $_POST['annual_maintaince_fees'];
		$o1->annual_fee_type = $_POST['annual_fee_type'];
		$o1->annual_max_fee = $_POST['annual_max_fee'];
		$o1->mid_setup_fees = $_POST['mid_setup_fees'];
		$o1->mid_fee_type = $_POST['mid_fee_type'];
		$o1->mid_max_fee = $_POST['mid_max_fee'];
		$o1->virtual_fee_type = $_POST['virtual_fee_type'];
		$o1->virtual_terminal = $_POST['virtual_terminal'];
		$o1->virtual_max_fee = $_POST['virtual_max_fee'];
		$o1->pci_compliance =$_POST['pci_compliance'];
		$o1->pci_fee_type =$_POST['pci_fee_type'];
		$o1->pci_max_fee =$_POST['pci_max_fee'];
		$o1->wire_transfer = $_POST['wire_transfer'];
		$o1->wire_fee_type = $_POST['wire_fee_type'];
		$o1->wire_max_fee = $_POST['wire_max_fee'];
		$o1->refund_fee =$_POST['refund_fee'];
		$o1->refund_fee_type =$_POST['refund_fee_type'];
		$o1->refund_max_fee =$_POST['refund_max_fee'];
		$o1->charge_back_fee = $_POST['charge_back_fee'];
		$o1->chargeback_fee_type = $_POST['chargeback_fee_type'];
		$o1->chargeback_max_fee = $_POST['chargeback_max_fee'];
		$o1->rolling_reserve = $_POST['rolling_reserve'];
		$o1->rolling_fee_type = $_POST['rolling_fee_type'];
		$o1->rolling_max_fee = $_POST['rolling_max_fee'];
		$o1->discount_fees =$_POST['discount_fees'];
		$o1->discount_fee_type =$_POST['discount_fee_type'];
		$o1->discount_max_fee =$_POST['discount_max_fee'];
		$o1->fraud_fees = $_POST['fraud_fees'];
		$o1->fraud_fee_type = $_POST['fraud_fee_type'];
		$o1->fraud_max_fee = $_POST['fraud_max_fee'];
		$o1->call_verification_fee = $_POST['call_verification_fee'];
		$o1->call_max_fee = $_POST['call_max_fee'];
		$o1->call_fee_type = $_POST['call_fee_type'];
		$o1->integration_fee = $_POST['integration_fee'];
		$o1->integration_fee_type = $_POST['integration_fee_type'];
		$o1->integration_max_fee = $_POST['integration_max_fee'];
		$o1->gateway_affiliate_fee =$_POST['gateway_affiliate_fee'];
		$o1->monthly_affiliate_fee =$_POST['monthly_affiliate_fee'];
		$o1->annual_affiliate_fee =$_POST['annual_affiliate_fee'];
		$o1->virtual_affiliate_fee =$_POST['virtual_affiliate_fee'];
		$o1->mid_affiliate_fee =$_POST['mid_affiliate_fee'];
		$o1->pci_affiliate_fee =$_POST['pci_affiliate_fee'];
		$o1->wire_affiliate_fee =$_POST['wire_affiliate_fee'];
		$o1->refund_affiliate_fee =$_POST['refund_affiliate_fee'];
		$o1->chargeback_affiliate_fee =$_POST['chargeback_affiliate_fee'];
		$o1->rolling_affiliate_fee =$_POST['rolling_affiliate_fee'];
		$o1->discount_affiliate_fee =$_POST['discount_affiliate_fee'];
		$o1->fraud_affiliate_fee =$_POST['fraud_affiliate_fee'];
		$o1->call_affiliate_fee =$_POST['call_affiliate_fee'];
		$o1->integration_affiliate_fee =$_POST['integration_affiliate_fee'];
		$o1->is_active="1";
		$o1->user_setting_id  = $insertor->insert_object($o1, "user_setting");
		$o2->plan_id = $o1->user_setting_id;
	}else{
		$o2->plan_id = $_POST['plan_id'];
	}

	$o2->parent_id = $_POST['parent_id'];
	$o2->base_currency  =$_POST['base_currency'];
	$o2->user_id = $updater->update_object($o2, "users");
	$result['user_id'] = $o2->user_id;
	$result['error']="1";

}else{
	$result['error']="0";
}



echo json_encode($result);

?>