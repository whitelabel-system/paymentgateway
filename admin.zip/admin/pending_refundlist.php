<?php
session_start();
include 'include.php';
include 'session.php';

$tables = '1';
unset($_SESSION['refund_search']);
$sql = "select * from refund where status='Pending' order by refund_id desc ";
$res = getXbyY($sql);
$row = count($res);

include "includes/header.php";
include "html/pending_refundlist.php";
include "includes/footer.php";
include 'js/refund_list.js';
?>