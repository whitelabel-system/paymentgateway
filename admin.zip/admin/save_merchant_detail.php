<?php
session_start();
include"include.php";
include"session.php";


if ($_POST['updte']=="1") {

    if ($_POST['user_id']>"0") {
        $o1->user_id=$_POST['user_id'];
        $o1= $factory->get_object($o1->user_id , "users","user_id");
    }

    $sql_check = "Select user_id , mobile_verified , email_verified  from users where (email = '" . $_POST['email'] . "' or mobile = '" . $_POST['mobile'] . "')  and user_id !='".$_POST['user_id']."' ";
    $res_check = getXbyY($sql_check);
    $row_check = count($res_check);
    if ($row_check =="0") {


        $o1->name = $_POST['name'];
        $o1->email = $_POST['email'];
        $o1->mobile = $_POST['mobile'];
        $o1->mobile_1 = $_POST['mobile_1'];
        $o1->company_type =$_POST['company_type'];
        $o1->company_name  =$_POST['company_name'];
        $o1->user_type ="Merchant";
        $o1->user_adress = $_POST['user_adress'];
        $o1->country_id = $_POST['country_id'];
        $o1->gender = $_POST['gender'];
        $o1->url =$_POST['url'];
        $o1->otp_enabled = $_POST['otp_enabled'];
        $o1->minimum_withdrawal_amount = $_POST['minimum_withdrawal_amount'];
        $o1->secure_amount = $_POST['secure_amount'];
        if ($o1->user_id>"0") {

        }else{
            $o1->password =cpassword($_POST['password']);
            $o1->created_at = todaysDate();
            $o1->user_name = create_username($o1->user_type);
            $o1->last_login = todaysDate();
            $o1->kyc_date = todaysDate();
            $o1->dob = todaysDate();
        }
        $o1->user_name_id = crc32($o1->user_name);
        $o1->email_otp = rand(5000, 9999);
        $o1->mobile_otp = rand(5000, 9999);
        $o1->otp = rand(5000, 9999);


        $o1->login_ip = check_ipaddress();
        $o1->mobile_verified = 'No';
        $o1->email_verified = 'No';
        $o1->kyc_status = 'No';
        $o1->business_status = 'No';
        $o1->status = 'Not Verify';
        $o1->gst = '0';
        $o1->kyc_id = '0';
        $o1->credit_limit = '0';
        $o1->credit_amount = '0';
        $o1->settled_amount = '0';
        $o1->amount_balance = '0';
        $o1->commission_amount = '0';
        $o1->tds = '0';
        $o1->commission = '0';
        $o1->route = '0';
        $o1->is_active = $_POST['is_active'];
        if ($_POST['user_id']>"0") {
            $o1->user_id=$_POST['user_id'];
            $o1->user_id= $updater->update_object($o1, "users");
            $result['error_msg']="Member Detail Updated Successfully";
        }else{
            $o1->user_id = $insertor->insert_object($o1, "users");
            $result['error_msg']="Member Added Successfully";
            $message = "Congratulations! Your Account on E-secure Payment is active now.  url : http://esecure_payment.in/ <br/> Username: " . $o1->mobile . " or " . $o1->email . " <br/>password is: " . $_POST['password'];

            sendmail($email_from, $o->email,"E-secure Payment  Account is active now." , $message);
        }

        if ($_FILES['profile_pic']['name'] != "") {

            if ($o1->profile_pic != "") {
                $img_link = "../img/" . $o1->profile_pic;
                $img_thumb_link = "profile_pic/thumbs/" . $o1->profile_pic;
                unlink($img_link);
                unlink($img_thumb_link);
            }

            $tmpfile = $_FILES['profile_pic']['tmp_name'];
            $source = "../img/";
            $file_extension = explode(".", $_FILES['profile_pic']['name']);
            $destination = $o1->user_id."." . end($file_extension);
            $thumbnail = 1;
            $newsize = "100";
            $watermark = "";

            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

            $o1->profile_pic = $destination;
            $o1->user_id = $updater->update_object($o1, "users");

        }
        if ($_FILES['logo']['name'] != "") {

            if ($o1->logo != "") {
                $img_link = "../img/" . $o1->logo;
                $unlink($img_link);
            }

            $tmpfile = $_FILES['logo']['tmp_name'];
            $source = "../img/";
            $file_extension = explode(".", $_FILES['logo']['name']);
            $destination = $o1->user_id."logo_." . end($file_extension);
            $thumbnail = 1;
            $newsize = "100";
            $watermark = "";

            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

            $o1->logo = $destination;
            $o1->user_id = $updater->update_object($o1, "users");

        }
        $result['error']="1";

    }else{
     $result['error']="0";
     $result['error_msg'] = "Email / Mobile is  Associated to another Account. Please Try another";

 }
}else{
    $result['error']="0";
}
echo json_encode($result);
?>