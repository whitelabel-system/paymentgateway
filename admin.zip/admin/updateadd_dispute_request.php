<?php
session_start();
include"include.php";
include"session.php";

if ($_POST['updte']=="1") {

$wallet_id = $_POST['adispute_id'];
//$o1 = $factory->get_object($o1->dispute_id , "disputes" ,"dispute_id");
$o2 = $factory->get_object($wallet_id , "wallet" ,"wallet_id");
 $o4 = $factory->get_object($o2->user_id , "users" ,"user_id");
// $o8 = $factory->get_object("1" , "users" ,"user_id");
$o1->is_active = 1;
$o1->wallet_id = $wallet_id;
$o1->user_id = $o2->user_id;
$o1->dispute_date = todaysDate();
$o1->dispute = $_POST['dispute_reason'];
$o1->transaction_number = $o2->ref_number;
//$o1->resolved_by = $o->user_id;
//$o1->resolution_date = todaysDate();
//$o1->dispute_resolution = $_POST['dispute_resolution'];
// if ($o2->user_1_id > "0") {
// $o3 = $factory->get_object($o2->user_1_id , "users" ,"user_id");
// $o3->disputed_amount = $o3->disputed_amount -$o2->amount;
// }

// if ($_POST['dispute_status1'] =="Approve") {
// 	$o1->dispute_status = "Approve";
// 	$o2->disputed="Resolved";
// 	$o3->amount_balance = $o3->amount_balance - $o2->amount;
// 	$o4->amount_balance = $o4->amount_balance - $o2->amount;

//  $o5->chargeback_status = "Approve";
//  $o5->wallet_id = $o1->wallet_id;
//  $o5->user_id = $o1->user_id;
//  $o5->resolved_by = $o1->resolved_by;
//  $o5->chargeback=$o1->dispute;
//  $o5->chargeback_date = $o1->dispute_date;
//  $o5->chargeback_resolution= $o1->dispute_resolution;
//  $o5->resolution_date = $o1->resolution_date;
//  $o5->transaction_number = $o1->transaction_number;
//  $o5->is_active ="1";
//  $o5->chargeback_id = $insertor->insert_object($o5,"chargeback");
//  $o8->admin_chargeback_amount = $o8->admin_chargeback_amount + $o2->amount;




// }else{
$o1->dispute_status = "Pending";	
$o2->disputed = "Pending";
// }
// if ($o2->user_1_id >"0") {
// 	$o3->user_id = $updater->update_object($o3, "users");
// }
// $o8->user_id = $updater->update_object($o8, "users");
$o1->dispute_id = $insertor->insert_object($o1, "disputes");
$o2->wallet_id = $updater->update_object($o2, "wallet");
// $o4->user_id = $updater->update_object($o4, "users");
$notification = "Dispute has been added  against transaction number ".$o2->ref_number." ";
insert_notifications($o4->user_id,$notification , "dispute");
//insert_notifications($o3->user_id,$notification , "dispute");
$result['error']="1";
$result['error_msg'] ="Dispute Added SuccessFully";

}else{
	$result['error']="0";
}



echo json_encode($result);
?>