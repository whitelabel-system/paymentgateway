<?php
session_start();
include"include.php";
include"session.php";
$page_name="choose_user_plan";

$user_id = $_GET['aid'];
$o1= $factory->get_object($user_id , "users","user_id");
$sql = "select * from user_currency where user_id ='".$o1->user_id."' and status='yes' ";
$res = getxbyY($sql);
$row = count($res);
// pt($o1);
include "includes/header.php";
include "html/choose_user_plan.php";
include "includes/footer.php";
include "js/choose_user_plan.js";
?>