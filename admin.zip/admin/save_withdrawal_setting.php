<?php
session_start();
include"include.php";
include"session.php";
$page_name="save_withdrawal_setting";
if ($_POST['updte']=="1") {

$o1->country_id = $_POST['country_id'];
$o1 = $factory->get_object($o1->country_id, "countries", "country_id");
$o1->commission_type = $_POST['commission_type'];
$o1->surcharge = $_POST['surcharge'];
$o1->tds = $_POST['tds'];
$o1->gst = $_POST['gst'];
$o1->tds_value = $_POST['tds_value'];
$o1->gst_value = $_POST['gst_value'];
$o1->country_id = $updater->update_object($o1, "countries");

$result['error']="1";
$result['error_msg']=" Setting Added Successfullt";	

}else{
	$result['error']="0";
}



echo json_encode($result);
?>