<?php
session_start();
include 'include.php';
include 'session.php';



$sql = "Select * from Currency";
$res = getXbyY($sql);
$row = count($res);


include "includes/header.php";
include "html/Currecny_convertor.php";
include "includes/footer.php";
include 'js/currency_Convertor.js';
?>