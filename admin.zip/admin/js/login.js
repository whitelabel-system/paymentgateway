//<script type="text/javascript">

//$('#login_form').submit(function () {
//    $('#form_login').hide();
//    $('#processing').show();
//    var values = $("#login_form").serialize();
//    $.ajax({
//       url: "check_login.php",
//        type: "post", 
//        data: values,
//        success: function (response) {  
//            var result = jQuery.parseJSON(response);
//            console.log(result);
//            if (result['error'] == 1) {
//                swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
//                $('#form_login').show();
//                $('#processing').hide();
//            } else {
//                swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false, timer: 2000});
//                window.location.href = "index.php";
//            }
//    },
//        error: function (jqXHR, textStatus, errorThrown) {
//            console.log(textStatus, errorThrown);
//        }
//    });
//});
//});
//</script>
<script type="text/javascript">

function change_div() {

  $("#login_div").hide();
  $("#register_div").show();
  $('#custom-con').removeClass('custom-register-container');
  $('#custom-con').addClass('custom-login-container');
}

$('#forget_pass').click(function(){
	$('#login_div').hide();
	$('#forgetpassdiv').show();

});
$('#login12').click(function(){
	
	$('#forgetpassdiv').hide();
	$('#login_div').show();

});

// $('#forgetp').click(function(){
	
// 	$('#forgetpassdiv').hide();
// 	$('#update_div').show();

// });
// $('#update_btn').click(function(){
	
// 	$('#update_div').hide();
// 	$('#login_div').show();

// });
$('#login_form').submit(function () {
   $('#pro_login').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
    var values = $("#login_form").serialize();
        $.ajax({
                url: "login_check.php",
                type: "post",
                data: values,

                success: function(response) { 
                    $('#pro_login').html("Login").prop('disabled', false);
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    
                    if (result['error'] == 0) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        window.location.href = "index.php";
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
    });

$('#forgetpassform').submit(function(){
var values = $('#forgetpassform').serialize();
$('#forgetp').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
$.ajax({
   url:'forget-password.php',
   type:'post',
   data :values,
   success:function(response){
    $('#forgetp').html("Reset Password").prop('disabled', false);
var result = jQuery.parseJSON(response);
      if(result['error'] == '0'){
swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false, timer: 2000});
    // $('#logindiv').show();
    // $('#forgetpassdiv').hide();
    	$('#forgetpassdiv').hide();
 	$('#login_div').show();
      }else{
swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
      }
   },

});

});
   
</script>