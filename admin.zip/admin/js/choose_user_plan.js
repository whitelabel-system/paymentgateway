<script type="text/javascript">
$("#ra").submit(function(){
 var values = $("#ra").serialize();
        $.ajax({
                url: "save_choosen_plan.php",
                type: "post",
                data: values,

                success: function(response) { 
                    $('#save_button').html("Processing.....").prop('disabled', true);
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button').html("save").prop('disabled', false);
                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // $("#ra")[0].reset();
                        // window.location.href = "index.php";
                        window.location.href ="user_security.php?aid="+result['user_id'];
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});
function custom_plan(){
    var plan = $("#plan_id").val();
    if (plan=="custom") {
        $("#custom_plan").show();
    }else{
        $("#custom_plan").hide();

    }
}
function check_type(type){
// alert(type);
var tt = $('#' + type + "_fee_type").val();

if (tt=="Flat") {
$('#' + type + "_max_fee").prop('disabled', true);

}else{
$('#' + type + "_max_fee").prop('disabled', false);

}
}


function save_user_currency(currency, i, user_id) {

    var status = $('#status_' + i).prop("checked");
    if (status == false) {
        var status = "No";
    } else {
        var status = "Yes";
    }


    $.ajax({ 
        url: "save_user_currency.php",
        type: "post",
        data: {"id": user_id, "currency": currency, "status": status, "updte": 1},

        success: function (response) {
            var results = jQuery.parseJSON(response);
            $('#processing_update_status').hide();
            if (results['error'] == 1) {

            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

</script>