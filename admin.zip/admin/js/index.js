<script type="text/javascript">
$(document).ready(function(){
	get_page_values();
});
function get_page_values(){
	$.ajax({
		url: "get_dashboard_values.php",
		type: "post",
		data: {updte:"1"},

		success: function(response) { 

			var result = jQuery.parseJSON(response);
			console.log(result);

			if (result['error'] == 0) {

				$("#total_merchants").html(result['total_merchants']);
				$("#total_affiliate").html(result['total_affiliate']);
				$("#total_users").html(result['total_users']);
				$("#yearly_payment").html(result['yearly_payment']);
				$("#monthly_payment").html(result['monthly_payment']);
				$("#today_payment").html(result['today_payment']);
				$("#total_transaction").html(result['total_transaction']);
				$("#pending_amount").html(result['pending_amount']);
				$("#failed_payment").html(result['failed_payment']);
				$("#success_payment").html(result['success_payment']);
				$("#pending1").html(result['pending_amount']);
				$("#tds_gst").html(result['tds_gst']);
			} else{
				swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
			}
		},
		error: function (jqXHR, textStatus, errorThrown) {
			console.log(textStatus, errorThrown);
		}

	});

}
</script>