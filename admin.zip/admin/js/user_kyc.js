<script type="text/Javascript">
    function show_document(document_name){
        var img;
        img = "<img src='../img/"+document_name+"' style='width:100%' class='img-responsive' />";
        $('#img_div').html(img);
        $('#defaultModal').modal('show');        
    }
</script>