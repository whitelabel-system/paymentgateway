<script type="text/javascript">
$("#profile").submit(function() {

   var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_profile.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);
                // $("#add_team").show();
                // $("#processing").hide();

                if (results['error'] == 1) {
                    swal({title: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    window.location.href = "index.php";
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

    });

$('#change_password').submit(function () {
    var values = $("#change_password").serialize();
    if($('#new_password').val() != $('#confirm_password').val()){
        swal({title: "Error", text: "New Password & Confirm Password Donot Match", icon: "error", buttons: false, timer: 2000});
        $('#confirm_password').val('');
        $('#confirm_password').focus();
        return false;
    }
    $("#cpassword").hide();
    $("#c_processing").show();
    $.ajax({
        url: "save_change_password.php",
        type: "post",
        data: values,
        success: function (response) {
           $("#change_password")[0].reset();
           var results = jQuery.parseJSON(response);
           $("#cpassword").show();
           $("#c_processing").hide();
           if (results['error'] == 1) {
            swal({title: "Error", text: results['error_msg'], icon: "error", buttons: false, timer: 2000});             
        } else {
            swal({title: "Success", text: results['error_msg'], icon: "success", buttons: false, timer: 2000});             
        }
    },
    error: function (jqXHR, textStatus, errorThrown) {
        console.log(textStatus, errorThrown);
    }
});
});


$('#ra').submit(function () {
    
     $('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 
    var values = $("#ra").serialize();
    $.ajax({
        url: "save_bank.php",
        type: "post", 
        data: values,
        success: function (response) {  
            var result = jQuery.parseJSON(response);
            console.log(result);
               $('#save_button').html("Save").prop('disabled', false);
            if (result['error'] == 1) {
                swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                
            } else {
                swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false, timer: 2000});
                window.location.reload();
            }
    },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
});
</script>	
