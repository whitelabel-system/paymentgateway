<script type="text/javascript">
$(document).ready(function(){
    var reload_history = $('#dispute_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'new_dispute_list.php'
//            'url': 'dispute_list.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'transaction_number'},
            {data: 'total_amount'},
            {data : 'amount'},
            {data: 'transaction_date'},
            {data: 'status'},
            {data: 'action'},
           
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });
    var reload_history = $('#reject_dispute_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'rejected_dispute_list.php'
//            'url': 'dispute_list.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'transaction_number'},
            {data: 'total_amount'},
            {data : 'amount'},
            {data: 'transaction_date'},
            {data: 'status'},
            {data: 'action'},
           
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });

    

var reload_history = $('#pending_dispute_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'pending_dispute_list.php'
//            'url': 'dispute_list.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'transaction_number'},
            {data: 'total_amount'},
            {data : 'amount'},
            {data: 'transaction_date'},
            {data: 'status'},
            {data: 'action'},
           
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });





$("#search_txn").submit(function(){

 var values = $("#search_txn").serialize();
        $.ajax({
                url: "search_dispute.php",
                type: "post",
                data: values,

                success: function(response) { 
                    // var result = jQuery.parseJSON(response);
//                  reload_history.ajax.reload();
$('#dispute_list').DataTable().ajax.reload()
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });

});
});
function update_status(dispute_id){
    // alert(status);
    var status = $("#status"+dispute_id).val();
    // alert(status);
    if (status=="Ticket") {
window.location.href ="add_ticket.php?did="+dispute_id;
    }else{
    $("#dispute_status1").val(status);
    $("#dispute_id").val(dispute_id);
    $("#dispute_modal").modal("toggle"); 
}
}

$("#dispute_response").submit(function(){
$('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 var values = $("#dispute_response").serialize();
        $.ajax({
                url: "update_dispute_request.php",
                type: "post",
                data: values,

                success: function(response) { 
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button').html("Save").prop('disabled', false);

        $("#dispute_modal").modal("toggle"); 

                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
//                        window.location.href ="disputes.php?status="+result.status;
if(result.status == "Approve"){
 window.location.href ="approve_disputes.php";
} else {
 window.location.href ="rejected_disputes.php";
}
                       
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});  
function add_dispute(id){
    $('#adispute_id').val(id);
    $('#disputereasonadd_modal').show();
    // alert(id);

}
$('#dissmiss').click(function(){
 $('#disputereasonadd_modal').hide();

});
$('#dissmiss1').click(function(){
 $('#disputereasonadd_modal').hide();

});
$("#dispute_add").submit(function(){
$('#save_button1').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 var values = $("#dispute_add").serialize();
        $.ajax({
                url: "updateadd_dispute_request.php",
                type: "post",
                data: values,

                success: function(response) { 
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button1').html("Save").prop('disabled', false);

                     $("#disputereasonadd_modal").modal("toggle"); 

                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
                        window.location.href ="pending_disputes.php";
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});  
</script>