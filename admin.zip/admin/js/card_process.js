<script type="text/javascript">

function save_user_card(user_id, i , id) {

    var status = $('#status_' + i).prop("checked");
    if (status == false) {
        var status = "No";
    } else {
        var status = "Yes";
    }


    $.ajax({ 
        url: "save_user_card.php",
        type: "post",
        data: {"id": user_id,"status": status, "credit_card_processor_id":id ,"updte": 1},

        success: function (response) {
            var results = jQuery.parseJSON(response);
            $('#processing_update_status').hide();
               window.location.reload();
            if (results['error'] == 1) {

            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

</script>