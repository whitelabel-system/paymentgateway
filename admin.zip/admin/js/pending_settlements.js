<script type="text/javascript">
function update_status(status , withdrawal_request_id){
    if(status == "Ticket"){
        $('#hide_div').hide();    
        $('#processing').show();
        $.ajax({
                url: "update_withdrawal_request.php",
                type: "post",
                data: {"status":status, "withdrawal_request_id" : withdrawal_request_id, "updte":1},
                   
                success: function(response) { 
                    var result = jQuery.parseJSON(response);
                    console.log(result);
//                    $('#save_button').html("Save").prop('disabled', false);
//                    $("#settlement_modal").modal("toggle");

                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
                       
                        var status = result['status'];
                        window.location.href = status;
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
    } else {
    $("#status").val(status);
    $("#withdrawal_request_id").val(withdrawal_request_id);
    $("#settlement_modal").modal("toggle");
    }

}
$("#settlement_response").submit(function(){
$('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 var values = $("#settlement_response").serialize();
        $.ajax({
                url: "update_withdrawal_request.php",
                type: "post",
                data: values,

                success: function(response) { 
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button').html("Save").prop('disabled', false);
                    $("#settlement_modal").modal("toggle");

                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
                       
                        var status = result['status'];
                        window.location.href = status;
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});
</script>