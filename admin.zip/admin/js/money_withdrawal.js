<script type="text/javascript">


$("#money_withdrawal").submit(function(){
    // $("#update_status").val(submit_type);
    $('#save').html("<i class='fa fa-spinner fa-spin'></i> Requesting....").prop('disabled', true);

    var values = $("#money_withdrawal").serialize();
        $.ajax({
            url: "request_money_withdrawal.php",
            type: "post",
            data: values,

            success: function (response) {
                var results = jQuery.parseJSON(response);
                    $('#save').html("Withdrawal Request").prop('disabled', false);
                // $("#request_modal").modal("toggle");
                if (results['error'] == 0) {
                    // $('#send_money_direct').html(results['details']);
                    // window.reload();
                    $("#money_withdrawal")[0].reset();
                    swal({title:"Success" , text: results['error_msg'], icon: "success", timer: 2000, html: true, showConfirmButton: false});

                } else {
                    swal({title:"Error" , text: results['error_msg'], icon: "error", timer: 2000, html: true, showConfirmButton: false});
                }
               
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });
});


$("#bank_id").change(function () {
// var bank_id = $("#bank_id").val();
var id = $(this).val();
// alert(id);

$.ajax({
            url: "get_user_bank_details.php",
           type: "post",
            data: {"bank":id},

            success: function (response) {
                var results = jQuery.parseJSON(response);
                if (results['error'] == 0) {
                    $('#send_money_direct').html(results['details']);

                } else {
                    $('#send_money_direct').html('');
                    // $('#user_id').val('');
                    swal({title: results['error_msg'], type: "error", timer: 2000, html: true, showConfirmButton: false});
                }
                reload_history.ajax.reload();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});

function get_userbalance(id){
$.ajax({
            url: "get_userBalance.php",
           type: "post",
            data: {"updte":"1","uid":id},

            success: function (response) {
                var results = jQuery.parseJSON(response);
                if(results['error'] == 0) {
                  
                    $('#balnce_div').show();
                    $('#bal_uu').html(results.balance);

                } 
               
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });
}

</script>