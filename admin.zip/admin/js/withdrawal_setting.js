<script type="text/javascript">
$("#withdrawal_setting").submit(function(){
 var values = $("#withdrawal_setting").serialize();
        $.ajax({
                url: "save_withdrawal_setting.php",
                type: "post",
                data: values,

                success: function(response) { 
                    $('#pro_login').html("Login").prop('disabled', false);
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    
                    if (result['error'] == 1) {
                        // swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
                        window.location.href ="withdrawal_setting.php";
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});
</script>