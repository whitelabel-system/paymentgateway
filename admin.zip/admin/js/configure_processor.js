<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
<script type="text/javascript">
$(document).ready(function() {       
    $('#account_type').multiselect({       
        nonSelectedText: 'Select Classification'             
    });
});
function save_user_rights(service_id, i, user_id) {

    var status = $('#status_' + i).prop("checked");
    if (status == false) {
        var status = "No";
    } else {
        var status = "Yes";
    }


    $.ajax({ 
        url: "save_user_rights.php",
        type: "post",
        data: {"id": user_id, "service_id": service_id, "status": status, "updte": 1},

        success: function (response) {
            var results = jQuery.parseJSON(response);
            $('#processing_update_status').hide();
            if (results['error'] == 1) {

            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}
</script>