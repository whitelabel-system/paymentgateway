<script type="text/javascript">
$('#ticket').submit(function () {
    
     $('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
     var content= tinymce.get("text_message").getContent();
   $('#message').val(content);
 
  var formData = new FormData(this);
    $.ajax({
        url: "save_ticket.php",
        type: "post", 
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        success: function (response) {  
            var result = jQuery.parseJSON(response);
            console.log(result);
               $('#save_button').html("Save").prop('disabled', false);
            if (result['error'] == 1) {
                swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                
            } else { 
                swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false, timer: 2000});
                if(result['page'] == "pending_settlements"){
                window.location.href = "pending_settlements.php";
                } else if(result['page'] == "dispute"){
                window.location.href = "pending_disputes.php";
                } else if(result['page'] == "refunds"){ 
                window.location.href = "pending_refundlist.php";
                } 
                else {
                 window.location.href = "all_tickets.php";
             }
            }
    },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
});
$("#add_more").click(function(){
    var res = $("#att").html();
$("#exta_att").append(res);
});
</script>