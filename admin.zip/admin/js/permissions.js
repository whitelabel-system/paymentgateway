<script type="text/javascript">
$("#ra").submit(function(){
 var values = $("#ra").serialize();
        $.ajax({
                url: "save_permissions.php",
                type: "post",
                data: values,

                success: function(response) { 
                    $('#save_button').html("Processing.....").prop('disabled', true);
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button').html("save").prop('disabled', false);
                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // $("#ra")[0].reset();
                        // window.location.href = "index.php";
                        window.location.reload();
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});

function check_type(type){
// alert(type);
var tt = $('#' + type + "_fee_type").val();

if (tt=="Flat") {
$('#' + type + "_max_fee").prop('disabled', true);

}else{
$('#' + type + "_max_fee").prop('disabled', false);

}
}

</script>