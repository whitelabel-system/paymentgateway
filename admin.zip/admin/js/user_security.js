<script type="text/javascript">
$("#ra").submit(function() {

 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_user_security.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    window.location.href = "review_user.php?aid="+results['user_id'];
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});
var i='1';
function add_more(ip){
        i++;

    var datata = $('#'+ip+'_div').html();
    $('#'+ip+'_add_div').append(datata);
}

</script>	