<script type="text/javascript">
$("#ra").submit(function() {

 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_team_detail.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    window.location.href = "users.php";
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});

</script>	