<script type="text/javascript">
function user_rights(id) {

    $.ajax({
        url: "get_user_services.php",
        type: "post",
        data: {"updte": 1, "user_id": id},
        success: function (response) {

            var result = jQuery.parseJSON(response);
            if (result['error'] == 1) {

                $('#user_service_rights').html(result['body']);
            }
        }

    });
    $('#user_rights_status').modal('toggle');
}
function delete_user(user_id){
        $.ajax({
        url: "delete_user.php",
        type: "post",
        data: {"updte": 1, "id": user_id},
        success: function (response) {

            var result = jQuery.parseJSON(response);
           if (result['error'] == 1) {
                swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false, timer: 2000});
                window.location.href = "all_users.php";
                
            } else {
                swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});

            }
        }

    });
}
function save_user_rights(service_id, i, user_id) {

    var status = $('#status_' + i).prop("checked");
    if (status == false) {
        var status = "No";
    } else {
        var status = "Yes";
    }


    $.ajax({ 
        url: "save_user_rights.php",
        type: "post",
        data: {"id": user_id, "service_id": service_id, "status": status, "updte": 1},

        success: function (response) {
            var results = jQuery.parseJSON(response);
            $('#processing_update_status').hide();
            if (results['error'] == 1) {

            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

$('#update_status').submit(function () {

    swal({title: "Success", text: "User rights updated successfully", icon: "success" , timer:"2000"});
    $('#user_rights_status').modal('hide');

});

</script>