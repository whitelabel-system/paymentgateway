<script type="text/javascript">


$(document).ready(function () {
    var reload_history = $('#category_question_table').DataTable({

        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'list_category_question.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'category_name'},
            {data: 'question'},
            {data: 'answer'},
            {data: 'status'},
            {data: 'action'},
         ],
        dom: 'Blfrtip',
        buttons: [
            'excel', 'pdf'
        ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000], [10, 25, 50, 100, 500, 1000]]
    });

$("#ra").submit(function() {

 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_category_question.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";\
                    $("#ra")[0].reset();
                    $("#help_category_question_id").val();
                    reload_history.ajax.reload();
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

}); 
});
function edit_question(id){
       $.ajax({
            url: "get_question_detail.php",
            type: "post",
            data: {"updte": 1 , "id":id},
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    $("#category_name").val(results['category_name']);
                    $("#category_question").val(results['category_question']);
                    $("#category_answer").val(results['category_answer']);
                    $("#is_active").val(results['is_active']);
                    // swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";
                    // reload_history.ajax.reload();
                    $("#help_category_question_id").val(id);
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});
 
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

}
</script>	