
<script type="text/javascript">
$('#document').ready(function(){
 $('#ifsc_code').change(function () {

  var ifsc=$('#ifsc_code').val();

  $.ajax({
    url: "get_user_register_bank_details.php",
    type: "post",
    data: {"updte": 1, "ifsc": ifsc},
    success: function (response) {
      var results = jQuery.parseJSON(response);  
      $('#bank_name').val(results['bank_name']);
      $('#bank_details').show();
      $('#bank_details').html(results['bank_details']);
      $('#bank_address').val(results['bank_details']);
    },
    error: function (jqXHR, textStatus, errorThrown) {
      console.log(textStatus, errorThrown);
    }
  });
  
});
});



$('#ra').submit(function () {
    
     $('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 
    var values = $("#ra").serialize();
    $.ajax({
        url: "save_bank.php",
        type: "post", 
        data: values,
        success: function (response) {  
            var result = jQuery.parseJSON(response);
            console.log(result);
            
               $('#save_button').html("Save").prop('disabled', false);
            if (result['error'] == 1) {
                swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                
            } else {
                swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false, timer: 2000});
                window.location.href = "user_bank.php?aid="+result['user_id'];
            }
    },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
});

</script>