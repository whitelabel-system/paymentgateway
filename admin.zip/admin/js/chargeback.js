<script type="text/javascript">
$(document).ready(function(){
    var reload_history = $('#chargeback_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'chargeback_list.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'transaction_number'},
            {data: 'amount'},
            {data : 'chargeback'},
            {data: 'status'},
            {data: 'chargeback_date'},
            {data: 'action'},
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });

    


$("#search_txn").submit(function(){

 var values = $("#search_txn").serialize();
        $.ajax({
                url: "search_chargeback.php",
                type: "post",
                data: values,

                success: function(response) { 
                    // var result = jQuery.parseJSON(response);
                  reload_history.ajax.reload();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });

});
});


function chargeback(wallet_id){
	$("#wallet_id").val(wallet_id);
	$("#chargeback_modal").modal("show");
}

$("#chargeback_response").submit(function(){
 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "add_chargeback.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);
	$("#chargeback_modal").modal("hide");

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});
function update_status(chargeback_id){
    // alert(status);
     var status = $("#status"+chargeback_id).val();
    // alert(status);
    if (status=="Ticket") {
window.location.href ="add_ticket.php?cid="+chargeback_id;
    }else if(status==""){
return false;
    } else{
$("#chargeback_status1").val(status);
$("#chargeback_id").val(chargeback_id);
$("#dispute_modal").modal("toggle"); 
}
}
$("#chargeback_response_submit").submit(function(){
$('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 var values = $("#chargeback_response_submit").serialize();
        $.ajax({
                url: "update_chargeback_request.php",
                type: "post",
                data: values,

                success: function(response) { 
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button').html("Save").prop('disabled', false);

        $("#dispute_modal").modal("toggle"); 

                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
                        window.location.href ="chargeback.php";
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});  
</script>