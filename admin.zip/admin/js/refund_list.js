<script type="text/javascript">
$(document).ready(function(){
    var reload_history = $('#dispute_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'new_list_refunds.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'transaction_number'},
            {data : 'total_amount'},
            {data: 'amount'},
            {data: 'transaction_date'},           
            {data: 'status'},       
            {data: 'action'},
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });

    
 var reload_history = $('#approvedispute_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'list_approve_refund.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'amount'},
            {data : 'remark'},
            {data: 'status'},
            {data: 'refund_date'},
//            {data: 'action'},
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });

 var reload_history = $('#pendingdispute_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'list_pending_refund.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'amount'},
            {data : 'remark'},
            {data: 'status'},
            {data: 'refund_date'},
            {data: 'action'},
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });


 var reload_history = $('#rejectdispute_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'list_reject_refund.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'amount'},
            {data : 'remark'},
            {data: 'status'},
            {data: 'refund_date'},
//            {data: 'action'},
  
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });


$("#search_txn").submit(function(){

 var values = $("#search_txn").serialize();
        $.ajax({
                url: "search_refund.php",
                type: "post",
                data: values,

                success: function(response) { 
                    // var result = jQuery.parseJSON(response);
                  reload_history.ajax.reload();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });

});
});
function update_status(refund_id){
    
    var status = $("#status"+refund_id).val();
//     alert(status);
    if (status=="Ticket") {
window.location.href ="add_ticket.php?rid="+refund_id;
    }else{
    $("#refund_status1").val(status);
    $("#refund_id").val(refund_id);
    if(status != "Approved"  && status != "Rejected"){
    $("#dispute_modal").modal("toggle"); 
    }
}
}

$("#dispute_response").submit(function(){
$('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 var values = $("#dispute_response").serialize();
        $.ajax({
                url: "update_refund_request.php",
                type: "post",
                data: values,

                success: function(response) { 
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button').html("Save").prop('disabled', false);

        $("#dispute_modal").modal("toggle"); 

                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
                        var status = result['status'];
                        window.location.href = status;
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});  
function update_status_refund(refund_id){
    
    var status = $("#status"+refund_id).val();
//     alert(status);
    if (status=="Ticket") {
window.location.href ="add_ticket.php?rid="+refund_id;
    }else{
    $("#refund_status1").val(status);
    $("#refund_id").val(refund_id);
    if(status != "Approved"  && status != "Rejected"){
    $("#dispute_modal").modal("toggle"); 
    }
}
}

$("#pending_refund").submit(function(){
$('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 var values = $("#pending_refund").serialize();
        $.ajax({
                url: "update_pending_refund.php",
                type: "post",
                data: values,

                success: function(response) { 
                    var result = jQuery.parseJSON(response);
                    console.log(result);
                    $('#save_button').html("Save").prop('disabled', false);

        $("#dispute_modal").modal("toggle"); 

                    if (result['error'] == 1) {
                        swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false,timer: 2000});
                        // window.location.href = "index.php";
                        var status = result['status'];
                        window.location.href = status;
                    } else{
                        swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });
});  

</script>