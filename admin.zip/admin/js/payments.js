
<script type="text/javascript" >

$(document).ready(function(){
    var reload_history = $('#payment_list').DataTable({
         "fixedHeader": true,
        "serverSide": true,
        "processing": true,
        "paging": true,
        "searching": false,
        "ordering": false,
        'ajax': {
            type: "post",
            data: {'search_new': $('#search_new').val()},
            'url': 'payment_list.php'
        },
        columnDefs: [{
                targets: "_all",
                orderable: false
            }],
        'columns': [
            {data: 'sr_no'},
            {data: 'transaction_type'},
            {data: 'user_details'},
            {data: 'transaction_detail'},
            {data: 'total_amount'},
            {data: 'amount'},
          
            {data: 'transaction_date'},
    {data: 'status'},
           
            
        ],
        dom: 'Blfrtip',
          buttons: [
                {
                  extend: "copy",
                  className: "btn-sm"
                },
                {
                  extend: "csv",
                  className: "btn-sm"
                },
                {
                  extend: "excel",
                  className: "btn-sm"
                },
                {
                  extend: "pdfHtml5",
                  className: "btn-sm"
                },
                {
                  extend: "print",
                  className: "btn-sm"
                },
              ],
        "lengthMenu": [[10, 25, 50, 100, 500, 1000, -1], [10, 25, 50, 100, 500, 1000 ,'All']],
        "pageLength": 10
    });

    


$("#search_txn").submit(function(){

 var values = $("#search_txn").serialize();
        $.ajax({
                url: "search_payment.php",
                type: "post",
                data: values,

                success: function(response) { 
                    // var result = jQuery.parseJSON(response);
                  reload_history.ajax.reload();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
          }
                    
        });

});
});
</script>