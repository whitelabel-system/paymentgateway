<script type="text/javascript">
$('#ticket_reply').submit(function () {
    
 $('#save_button').html("<i class='fa fa-spinner fa-spin'></i> Processing....").prop('disabled', true);
 var content= tinymce.get("text_message").getContent();
 $('#message').val(content);
 var formData = new FormData(this);
    // var values = $("#ticket_reply").serialize();
    $.ajax({
        url: "save_ticket_reply.php",
        type: "post", 
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        success: function (response) {  
            var result = jQuery.parseJSON(response);
            console.log(result);
            $('#save_button').html("Save").prop('disabled', false);
            if (result['error'] == 1) {
                swal({title: "Error", text: result['error_msg'], icon: "error", buttons: false, timer: 2000});
                
            } else {
                swal({title: "Success", text: result['error_msg'], icon: "success", buttons: false, timer: 2000});
                window.location.href = "all_tickets.php";
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
});
function show_document(document_name){
    var img;
    img = "<iframe src='../img/"+document_name+"' style='width:100% ;height:398px;' frameborder='0'></iframe>";
    $('#img_div').html(img);
    $('#defaultModal').modal('show');        
}
</script>