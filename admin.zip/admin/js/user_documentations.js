<script type="text/Javascript">
    function show_document(document_name){
        var img;
        img = "<img src='../img/"+document_name+"' style='width:100%' class='img-responsive' />";
        $('#img_div').html(img);
        $('#defaultModal').modal('show');        
    }

// $("#kyc_form").submit(function() {

//  var formData = new FormData(this);
//         // $("#add_team").hide();
//         // $("#processing").show();

//         $.ajax({
//             url: "save_kyc_detail.php",
//             type: "post",
//             data: formData,
//             cache: false,
//             contentType: false,
//             processData: false,
//             success: function (response) {
//                 var results = jQuery.parseJSON(response);

//                 if (results['error'] == 1) {
//                     swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
//                     // window.location.href = "users.php";
//                 } else {

//                     swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

//                 }
//             },
//             error: function (jqXHR, textStatus, errorThrown) {
//                 console.log(textStatus, errorThrown);
//             }
//         });

// });
// $("#kyc_form3").submit(function() {

//  var formData = new FormData(this);
//         // $("#add_team").hide();
//         // $("#processing").show();

//         $.ajax({
//             url: "save_kyc_detail.php",
//             type: "post",
//             data: formData,
//             cache: false,
//             contentType: false,
//             processData: false,
//             success: function (response) {
//                 var results = jQuery.parseJSON(response);

//                 if (results['error'] == 1) {
//                     swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
//                     // window.location.href = "users.php";
//                 } else {

//                     swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

//                 }
//             },
//             error: function (jqXHR, textStatus, errorThrown) {
//                 console.log(textStatus, errorThrown);
//             }
//         });

// });




    function remove_document(type, j,document_name){
       $("#kyc_doc"+j).hide();
         $.ajax({
            url: "remove_document.php",
            type: "post",
            data: {"updte":"1" , "document_name":document_name , "type":type , "j":j},
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        }); 
       
    }
function save_kYc(i){

    // alert(i);
    $("#kyc_form"+i).submit(function() {

 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();
 // alert(formData);
        $.ajax({
            url: "save_kyc_detail.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                 window.location.reload();
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});
}

function save_address(i){
   
    $("#address_form"+i).submit(function() {

 var formData = new FormData(this);
 // alert(formData);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_kyc_detail.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";
                     window.location.reload();
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});
}

function save_Company(i){
$("#company_form"+i).submit(function() {

 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_kyc_detail.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";
                     window.location.reload();
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});
}
function save_CompanyAddress(i){
    $("#company_address_form"+i).submit(function() {

 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_kyc_detail.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";
                     window.location.reload();
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});

}
function save_domain(i){
    $("#domain_form"+i).submit(function() {

 var formData = new FormData(this);
        // $("#add_team").hide();
        // $("#processing").show();

        $.ajax({
            url: "save_kyc_detail.php",
            type: "post",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (response) {
                var results = jQuery.parseJSON(response);

                if (results['error'] == 1) {
                    swal({title:"success",text: results['error_msg'], type: "success", timer: 2000, html: true, showConfirmButton: false});
                    // window.location.href = "users.php";
                     window.location.reload();
                } else {

                    swal({title: "Error", text: results['error_msg'], icon: "error", showConfirmButton: true});

                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });

});

}
</script>	