function notifications() {
    $.ajax({
        url: "notifications.php",
        type: "post",
        data: {"updte": 1},
        success: function (response) {
            var result = jQuery.parseJSON(response);
            console.log(result);
            if(result['notifications'] > 0){
                $('#notifications').html(result['notifications']);
                
            }else{
                $('#notifications').html('');
            }
            if (result['pending_request_money']>0) {
            $("#pending_request_money").html(result['pending_request_money']);
        }else{
            $("#pending_request_money").html('');

            
        }
$('#amount_balance').html(result['amount_balance']);
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
    setTimeout(function () {notifications();}, 10000);
}
setTimeout(function () {notifications();}, 1000);

function show_notifications(){
    $.ajax({
        url: "my_notificstion.php",
        type: "post",
        data: {"updte": 1},
        success: function (response) {
            $('#my_notifications').html(response);            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

function clear_notifications(){
    $.ajax({
        url: "clear_notifications.php",
        type: "post",
        data: {"updte": 1},
        success: function (response) {
            $('#my_notifications').html(response);

        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}
function show_request_money(){
     $.ajax({
        url: "my_request_money.php",
        type: "post",
        data: {"updte": 1},
        success: function (response) {
            $('#my_request_money').html(response);            
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}
