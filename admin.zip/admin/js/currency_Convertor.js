<script>

function get_cuval(value){

$('#curval').html(value);


}



</script>