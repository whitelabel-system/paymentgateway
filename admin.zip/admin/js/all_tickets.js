
<script type="text/javascript">
function close_ticket(ticket_id){
	$.ajax({
		url :"update_ticket_status.php",
		type:"post",
		data:{"updte":"1" , "ticket_id":ticket_id},
		success: function(response) {
			var result = jQuery.parseJSON(response);
			console.log(result);
			if(result['error'] == 1){
				swal({title: "Error", text: result['error_msg'], icon:"error",buttons:false, timer:2000});

			}else{
				swal({title: "Success", text: result['error_msg'], icon:"success",buttons:false, timer:2000});
				// swal({title: "Error", text: result['error_msg'], icon:"error",buttons:false, timer:2000});
				location.reload();
			}
		},
		error: function(jqXHR, textStatus, errorThrown) {
			console.log(textStatus, errorThrown);
		}
	});
}
function open_ticket(ticket_id){
	$.ajax({
		url :"open_ticket_status.php",
		type:"post",
		data:{"updte":"1" , "ticket_id":ticket_id},
		success: function(response) {
			var result = jQuery.parseJSON(response);
			console.log(result);
			if(result['error'] == 1){
				swal({title: "Error", text: result['error_msg'], icon:"error",buttons:false, timer:2000});

			}else{
				swal({title: "Success", text: result['error_msg'], icon:"success",buttons:false, timer:2000});
				// swal({title: "Error", text: result['error_msg'], icon:"error",buttons:false, timer:2000});
							location.reload();
			}
		},
		error: function(jqXHR, textStatus, errorThrown) {
			console.log(textStatus, errorThrown);
		}
	});
}
</script>
