<?php
session_start();
include"include.php";
include"session.php";
$page_name="dispute_list";

$recharge_page = 1;
$tables = 1;

// pt($_POST);pt($_GET);
## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$length = $_POST['length'];

if ($row == "") { 
    $row = 0;
}

if ($length == "") {
    $length = 10;
}

$trigger_from_date = "1=1";
$trigger_to_date = "1=1";
$trigger_user_id = "1=1";

if (isset($_SESSION['refund_search'])) {

    if (isset($_SESSION['refund_search']['from_date'])) {
$trigger_from_date = "refund_date >= '" . $_SESSION['refund_search']['from_date']." 00:00:00'";
    }
    if (isset($_SESSION['refund_search']['to_date'])) {
$trigger_to_date = "refund_date <= '" . $_SESSION['refund_search']['to_date']." 23:59:59'";
    }
    if (isset($_SESSION['refund_search']['user_id'])) {
        $trigger_user_id = "user_id='".$_SESSION['refund_search']['user_id']."'  ";
    }
}

$triggers = $trigger_user_id . " and " . $trigger_from_date . " and " . $trigger_to_date;

$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value
//pt($_POST);

$sql_total = "Select count(wallet_id) as total_transactions from wallet where  $triggers  ";
$res_total = getXbyY($sql_total);

$sql_transactions = "Select * from wallet where $triggers order by wallet_id ASC limit $row ,$length";
//$sql_transactions = "Select * from wallet where user_id = ".$o->user_id." order by transaction_date DESC";
$res_transactions = getXbyY($sql_transactions);
$row_transactions = count($res_transactions);

if ($row_transactions > 0) {

    for ($i = 0; $i < $row_transactions; $i++) {
	$refund_status = get_refund_status($res_transactions[$i]['wallet_id']);
	if($refund_status !=""){
	    $action = $refund_status;
	} else {
//        $wallet = get_wallet_detail($res_transactions[$i]['wallet_id']);
         $action = '<Select class="form-control"  id="status'.$res_transactions[$i]['wallet_id'].'" onchange="update_status('.$res_transactions[$i]['wallet_id'].')" > <option>Select Action</option> ';
        // if ($res_transactions[$i]['status']=="Pending") {
            $action .='<option onclick="update_status1("Approve","'.$res_transactions[$i]['wallet_id'].'")" value="Approve" > Approve</option> <option onclick="update_status1("Reject","'.$res_transactions[$i]['wallet_id'].'")" value="Reject" > Reject </option> ';
        // }else if ($res_transactions[$i]['status']=="Approve") {
            // $action.='<option value="">Approved</option>';
        // }elseif ($res_transactions[$i]['status']=="Reject") {
//          $action .= '<option value="" >Rejected</option>';  
        // }
        $action .='<option value="Ticket" >Ticket </option></Select>';
	}
        $ttype=$res_transactions[$i]['transaction_type'];

	$data[] = array(
	    "sr_no" => ($i+1) + $row,
	    "transaction_type" => $res_transactions[$i]['transaction_type'],
	    "user_details" => $res_transactions[$i]['user_name'],
	    "transaction_number" => $res_transactions[$i]['transaction_details'] . "<br>" . $res_transactions[$i]['ref_number'],
	    "total_amount" => "<i class='fa fa-rupee-sign'></i> " . $res_transactions[$i]['total_amount'],
	    "amount" => "<i class='fa fa-rupee-sign'></i> " . $res_transactions[$i]['amount'],
	    "transaction_date" => format_date($res_transactions[$i]['transaction_date']),
	    "status" => $res_transactions[$i]['status'],
	    "action" => $action,
		// "api" => $res_transactions[$i]['api_name'],
	);
    }
} else {
    $data = array();
}

## Response
$response = array(
    "draw" => intval($draw),
    "iTotalRecords" => $res_total[0]['total_transactions'],
    "iTotalDisplayRecords" => $res_total[0]['total_transactions'],
    "aaData" => $data,
);

echo json_encode($response);


?>