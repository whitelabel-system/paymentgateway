<?php

session_start();
include "include.php";
include "session.php";

if ($updte == 1) {
    if (isset($_POST['bank_id'])) {
        $o1->bank_id = $_POST['bank_id'];
    } else {
        $o1->bank_id = 0;
    }
    if ($o1->bank_id > 0) {
        $o1 = $factory->get_object($o1->bank_id, "bank", "bank_id");
    }


    $o1->name = $_POST['name'];
    $o1->user_id = $_POST['user_id'];
    $o1->account_number = $_POST['account_number'];
    $o1->ifsc_code = $_POST['ifsc_code'];
    $o1->swift_code =$_POST['swift_code'];
    $o1->iban =$_POST['iban'];
    $o1->aba_number = $_POST['aba_number'];
    $api_response = fetch_bank_details($o1->ifsc_code);
    if($api_response->BRANCH == ''){
      $o1->branch = $api_response->BRANCH;
    }else{
            $o1->branch = $_POST['branch'];
    }
       if($api_response->ADDRESS == ''){
   $o1->address = $api_response->ADDRESS;
    }else{
            $o1->address =  $_POST['address'];
    }
  
  
    $o1->city = $api_response->CITY . "-" . $api_response->CENTRE;
    if($api_response->CONTACT == ''){
  $o1->contact = $api_response->CONTACT;
    }else{
           $o1->contact = $_POST['bank_number'];
    }
   if($api_response->BANK == ''){
    $o1->bank_name = $api_response->BANK;
    }else{
    $o1->bank_name = $_POST['name'];
    }
    $o1->state = $api_response->STATE;
    $o1->rtgs = $api_response->RTGS;
    $o1->district = $api_response->DISTRICT;
    $o1->bank_code = $api_response->BANKCODE;
    $o1->address = $_POST['bank_address'];
    $o1->company_address  = $_POST['company_address'];
 
    $o1->is_active = $_POST['is_active'];
    if ($o1->bank_id > 0) {

        $o1->updated_at = todaysDate();
        $o1->bank_id = $updater->update_object($o1, "bank");
        $result['error_msg'] = "Bank Updated Successfully";
    } else {
        $o1->created_at = todaysDate();
        $o1->updated_at = todaysDate();
        $o1->bank_id = $insertor->insert_object($o1, "bank");
        $result['error_msg'] = "Bank Added Successfully";
    }

 $result['user_id'] = $o1->user_id;
    $result['error'] = 0;
} else {
    $result['error'] = 1;
    $result['error_msg'] = "Something went wrong. Please try again";
}

echo json_encode($result);
?>