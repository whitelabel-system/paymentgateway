<?php
session_start();

include "include.php";
include "session.php";

$tables = 1;


$sql = "Select * from services order by service_name";
$res = getXbyY($sql);
$rows = count($res);	

include "includes/header.php";
include "html/services.php";
include "includes/footer.php";
?>