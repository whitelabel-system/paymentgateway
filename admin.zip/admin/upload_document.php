<?php
session_start();
include"include.php";
include"session.php";
$page_name="upload_document";

$user_id = $_GET['aid'];

 
include "includes/header.php";
include "html/upload_document.php";
include "includes/footer.php";
include "js/upload_document.js";
?>