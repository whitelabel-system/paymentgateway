<?php

session_start();
include"include.php";
include"session.php";

if ($_POST['updte'] == "1") {

    $o1->withdrawal_request_id = $_POST['withdrawal_request_id'];
    $o1 = $factory->get_object($o1->withdrawal_request_id, "withdrawal_request", "withdrawal_request_id");
    $o2 = $factory->get_object($o1->user_id, "users", "user_id");
    $o3 = $factory->get_object($o1->wallet_id, "wallet", "wallet_id");
    $o1->updated_at = todaysDate();
    $o1->status = $_POST['status'];
    $o1->utr_number = $_POST['utr_number'];
    $o1->remark = $_POST['remark'];
    if ($o1->status == "Approve") {
	$o3->status = "Success";
	$o3->updated_at = todaysDate();
	$messages = "You Withdrawal Request has been Approved It will to take 3-5 working days to affect your Account";
    } else {
	$o3->status = "Failed";
	$o3->updated_at = todaysDate();

	$o4->user_id = $o3->user_id;
	$o4->user_name = $o3->user_name;
	$o4->parent_id = $o3->wallet_id;
	$o4->transaction_type = "Refund";
	$o4->transaction_details = "Refund For transaction_number " . $o3->ref_number;
	$o4->amount = $o3->amount;
	$o4->user_old_balance = $o2->amount_balance;
	$o4->user_new_balance = $o4->user_old_balance + $o4->amount;
	$o4->transaction_date = todaysDate();
	$o4->created_at = todaysDate();
	$o4->status = "Success";
	$o4->bank_id = $insertor->insert_object($o4, "wallet");
	$o2->amount_balance = $o2->amount_balance + $o4->amount;
	$o2->user_id = $updater->update_object($o2, "users");
	$messages = "You Withdrawal Request has been Rejected You Wallet balance has be Refunded";
    }

    $email_to = $o2->email;
    $email_subject = "Response to Withdrawal Request";
    //$email_message = "Verification Code : ".$o->new_password;
    include"../mails/update_withdrawal_request.php";

    sendmail($email_from, $email_to, $email_subject, $email_message);
    $o3->wallet_id = $updater->update_object($o3, "wallet");
    $o1->withdrawal_request_id = $updater->update_object($o1, "withdrawal_request");

    $status = $o1->status . "ed";



    if ($_POST['status'] == "Approve") {
	$result['status'] = "approve_settlements.php";
    } else if ($_POST['status'] == "Reject") {
	$result['status'] = "rejected_settelments.php";
    } else  {
	$result['status'] = "add_ticket.php?user_id=".$o1->user_id."&withdrawal_request_id=".$o1->withdrawal_request_id;
    }

    $result['error'] = "1";
    $result['error_msg'] = "Request Updated Successfully";
} else {
    $result['error'] = "0";
}
echo json_encode($result);
?>