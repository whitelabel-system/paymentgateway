<?php
session_start();
include "include.php";
include "session.php";


if (isset($_GET['aid'])) {
	$o1->help_category_id = $_GET['aid'];
} else {
	$o1->help_category_id = 0;
}
if ($o1->help_category_id > 0) {
	$o1 = $factory->get_object($o1->help_category_id, "help_category", "help_category_id");
} else {
	$o1->is_active = 1;
}
if ($updte == 1) {
	$o1->category_name = $_POST['category_name'];
	$o1->is_active = $_POST['is_active'];




	if ($o1->help_category_id > 0) {
		$o1->help_category_id = $updater->update_object($o1, "help_category");
	} else {
		$o1->help_category_id = $insertor->insert_object($o1, "help_category");
	}

	if ($_FILES['category_icon']['name'] != "") {

        if ($o->other != "") {
            $img_link = "../img/" . $o1->other;
            unlink($img_link);
        }

        $tmpfile = $_FILES['category_icon']['tmp_name'];
        $source = "../img/";
        $file_extension = explode(".", $_FILES['category_icon']['name']);
        $destination = $o1->help_category_id."." . end($file_extension);
        $thumbnail = 0;
        $newsize = "100";
        $watermark = "";

        uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

        $o1->other = $destination;
        $o1->help_category_id = $updater->update_object($o1, "help_category");

    }
	header("location:all_help_category.php?msgid=3");
}
 

include "includes/header.php";
include "html/help_category.php";
include "includes/footer.php";
include "js/help_category.js";
?>