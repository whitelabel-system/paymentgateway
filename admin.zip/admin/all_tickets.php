<?php
session_start();
include 'include.php';
include 'session.php';

$tables = 1;

$sql = "select * from tickets where parent_id = 0 order by ticket_id desc ";
$res = getXbyY($sql);
$row = count($res);

include "includes/header.php";
include "html/all_tickets.php";
include "includes/footer.php";
include 'js/all_tickets.js';
?>