<?php
session_start();
include "include.php";
include "session.php";


if (isset($_GET['aid'])) {
	$o1->user_setting_id  = $_GET['aid'];
} else {
	$o1->user_setting_id  = 0;
}
if ($o1->user_setting_id  > 0) {
	$o1 = $factory->get_object($o1->user_setting_id , "user_setting", "user_setting_id");
} else {
	$o1->is_active = 1;
}

$page_name = "all_user_setting";
$tables = '1';
$sql="Select * from user_setting ";
$res = getXbyY($sql);
$rows=count($res);

include "includes/header.php";
include "html/user_setting.php";
include "includes/footer.php";
include "js/user_setting.js";
?>
