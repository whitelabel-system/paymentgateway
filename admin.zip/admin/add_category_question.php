<?php
session_start();
include "include.php";
include "session.php";
$page_name="add_category_question";

$tables = 1;

if (isset($_GET['aid'])) {
	$o1->help_category_id = $_GET['aid'];
} else {
	$o1->help_category_id = 0;
}
if ($o1->help_category_id > 0) {
	$o1 = $factory->get_object($o1->help_category_id, "help_category", "help_category_id");
	$_SESSION['help_category_id'] = $o1->help_category_id;
} else {
header("location:all_help_category.php");
}


 
include "includes/header.php";
include "html/add_category_question.php";
include "includes/footer.php";
include "js/add_category_question.js";
?>