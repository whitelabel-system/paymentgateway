<?php
session_start();
include"include.php";
include"session.php";

$tables = '1';

//$sql="Select w.*,u.user_id,u.amount_balance from withdrawal_request as w right join users as u on (u.user_id = w.user_id) Where  w.status='Pending' ";
$sql = "SELECT w.*,u.user_id,u.amount_balance,C.status AS ticket_status FROM withdrawal_request AS w RIGHT JOIN users AS u ON (u.user_id = w.user_id) LEFT JOIN tickets AS C ON (w.withdrawal_request_id = C.withdrawal_request_id) WHERE (w.status='Pending' OR w.status='Ticket')";
$res = getXbyY($sql);
$rows=count($res);


include"includes/header.php";
include"html/pending_settlements.php";
include"includes/footer.php";
include"js/pending_settlements.js";

?>