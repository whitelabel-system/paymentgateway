<?php
session_start();

include "include.php";
include "session.php";
$ajax_logout = 1;

unset($_SESSION['ledger_search']);

$from_date = $_POST['from_date'];
$to_date = $_POST['to_date'];

$user_id = $_POST['user_id'];


if ($from_date != "") {
	$_SESSION['ledger_search']['from_date'] = $from_date ;
}
if ($to_date != "") {
	$_SESSION['ledger_search']['to_date'] = $to_date ;
}


if ($user_id > 0 ) {
	$_SESSION['ledger_search']['user_id'] = $user_id;
}


?>