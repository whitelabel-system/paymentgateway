<?php
session_start();
include"include.php";
include"session.php";
$page_name ="credit_card_list";
$tables = '1';
$sql="Select * from  wallet where (transaction_type ='New Payment' OR transaction_type ='Transaction Using API' OR transaction_type='Transaction using payment link') ";
$res = getXbyY($sql);
$row = count($res);
include"includes/header.php";
include"html/credit_card_list.php";
include"includes/footer.php";
include"js/chargeback.js";
?>