<?php
session_start();
include"include.php";
include"session.php";

$tables = '1';
$page_name="user_documents";

$sql="select * from kyc order by kyc_id DESC";
$res = getXbyY($sql);
$rows=count($res);

include "includes/header.php";
include "html/user_documents.php";
include "includes/footer.php"; 
include "js/user_documentations.js";
?>