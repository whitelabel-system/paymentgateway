<?php
session_start();
include"include.php";
include"session.php";
$page_name="user_authentication";

$tables = '1';

 $sql = "select * from users where user_type!='Admin'";
$res = getXbyY($sql);
$row = count($res);


include "includes/header.php";
include "html/user_authentication.php";
include "includes/footer.php";
include "js/user_authentication.js"
?>