<?php
session_start();
include"include.php";
include"session.php";
$page_name="payments";
$date = format_date_without_time(todaysDate());
$month = date("F") . "-" . date('Y');
$year = date('Y');
$tables = '1';
$trigger = "1=1";
unset($_SESSION['payment_search']);
if (isset($_GET['type'])) {
	$filter = $_GET['type'];
}
if ($filter =="success") {
	$trigger =" status='Success' ";
}else if($filter =="pending"){
	$trigger =" status='Pending' ";

}else if($filter =="failed"){
	$trigger =" status='Failed' ";
}else if($filter =="today"){
	$trigger = "date(transaction_date)='".$date."'  ";
}else if ($filter =="month") {
	$trigger = "month_year='".$month."'  ";
}else if($filter=="year"){
	$trigger = "year='".$year."'  ";
}
$sql ="Select * from wallet where transaction_type='New Payment' and $trigger  ";
$res=getXbyY($sql);
$row=count($res);

include "includes/header.php";
include "html/payments.php";
include "includes/footer.php";
include "js/payments.js";
?>