<?php
session_start();
include"include.php";
include"session.php";


if ($_POST['updte']=="1") {
$o->name = $_POST['name'];
$o->email = $_POST['email'];
$o->mobile = $_POST['mobile'];
$o->mobile_1 = $_POST['mobile_1'];
$o->company_name =$_POST['company_name'];
$o->user_address = $_POST['user_address'];
$o->district = $_POST['district'];
$o->state = $_POST['state'];
$o->pincode =$_POST['pincode'];
$o->url=$_POST['url'];
$o->country_id = $_POST['country_id'];
$o->timeZone =$_POST['timeZone'];
$o->otp_enabled = $_POST['otp_enabled'];
// $o->user_id = $updater->update_object($o, "users");
    if ($_FILES['profile_pic']['name'] != "") {

        if ($o->profile_pic != "") {
            $img_link = "../img/" . $o->profile_pic;
             unlink($img_link);
            }

        $tmpfile = $_FILES['profile_pic']['tmp_name'];
        $source = "../img/";
        $file_extension = explode(".", $_FILES['profile_pic']['name']);
        $destination = $o->user_id."." . end($file_extension);
        $thumbnail = 1;
        $newsize = "100";
        $watermark = "";

        uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

        $o->profile_pic = $destination;
        // $o->user_id = $updater->update_object($o, "users");

    }
    if ($_FILES['logo']['name'] != "") {

        if ($o->logo != "") {
            $img_link = "../img/" . $o->logo;
            unlink($img_link);
        }

        $tmpfile = $_FILES['logo']['tmp_name'];
        $source = "../img/";
        $file_extension = explode(".", $_FILES['logo']['name']);
        $destination = $o->user_id."_logo." . end($file_extension);
        $thumbnail = 1;
        $newsize = "100";
        $watermark = "";

        uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

        $o->logo = $destination;
      

$Sql_logo = "UPDATE site_info SET logo ='".$destination."'  ";
$res_logo = setXbyY($Sql_logo);


    }
     $o->user_id = $updater->update_object($o, "users");
    $result['error']="1";
    $result['error_msg']="Profile Updated Successfully";
}else{
	$result['error']="0";

}
echo json_encode($result);
?>