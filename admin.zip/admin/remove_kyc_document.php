<?php
session_start();
include "include.php";
include "session.php";

if(isset($_GET['aid'])){
    $o1->kyc_id = $_GET['aid'];
}else{
    $o1->kyc_id = 0;
}

if($o1->kyc_id > 0){
    $o1 = $factory->get_object($o1->kyc_id,"kyc", "kyc_id");
    $o2 = $factory->get_object($o1->user_id, "users", "user_id");
    
    unlink("../user_documents/$o1->kyc_doc1");
    unlink("../user_documents/$o1->kyc_doc2");
    unlink("../user_documents/$o1->kyc_doc3");
    unlink("../user_documents/$o1->kyc_doc4");
    unlink("../user_documents/$o1->kyc_doc5");
    unlink("../user_documents/$o1->address_file");
    unlink("../user_documents/$o1->address_file2");
    unlink("../user_documents/$o1->address_file3");
    unlink("../user_documents/$o1->comapny_file1");
    unlink("../user_documents/$o1->comapny_file2");
    unlink("../user_documents/$o1->comapny_file3");
    unlink("../user_documents/$o1->comapny_file4");
    unlink("../user_documents/$o1->comapny_file5");
    unlink("../user_documents/$o1->comapny_file");
    
    $sql = "Delete from  kyc where kyc_id = ".$o1->kyc_id;
    $res = setXbyY($sql);
    
    header("location:user_documents.php?");
}else{
    header("location:user_documents.php?");

}
?>