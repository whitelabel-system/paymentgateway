 <?php
session_start();
include"include.php";
include"session.php";

// pt($_POST);
// die();

if ($_POST['kyc_id'] > 0) {
        $o1->kyc_id=$_POST['kyc_id'];
        $o1= $factory->get_object($o1->kyc_id , "kyc","kyc_id");
    }
if ($_POST['kyc_note'] !="") {
    if($_POST['kyc_note'] == 'Driving Licence'){
$o1->kyc_doc2 = $_POST['kyc_note'];
    }else   if($_POST['kyc_note'] == 'Passport'){
$o1->kyc_doc1 = $_POST['kyc_note'];
    }else   if($_POST['kyc_note'] == 'Voter Card'){
$o1->kyc_doc3 = $_POST['kyc_note'];
    }else   if($_POST['kyc_note'] == 'Additional Document'){
        $o1->kyc_doc5 = $_POST['kyc_note'];
    }

}
if ($_POST['address_note'] !="") {
     if($_POST['address_note'] == 'Bank Statement'){
$o1->address_doc = $_POST['address_note'];
    }else   if($_POST['address_note'] == 'Utillity Bill'){
$o1->address_doc1 = $_POST['address_note'];
    }else   if($_POST['address_note'] == 'Insurance'){
$o1->address_doc2 = $_POST['address_note'];
    }else   if($_POST['address_note'] == 'Additional Document'){
        $o1->address_doc3 = $_POST['address_note'];
    }
	// $o1->address_note = $_POST['address_note'];
}
if ($_POST['company_note']!="") {
     if($_POST['company_note'] == 'Incorporation'){
$o1->company_doc = $_POST['company_note'];
    }else   if($_POST['company_note'] == 'MOA'){
$o1->company_doc1 = $_POST['company_note'];
    }else   if($_POST['company_note'] == 'AOA'){
$o1->company_doc2 = $_POST['company_note'];
    }else   if($_POST['company_note'] == 'PAN'){
    $o1->company_doc3 = $_POST['company_note'];
    }else   if($_POST['company_note'] == 'GST'){
    $o1->company_doc4 = $_POST['company_note'];
    }else   if($_POST['company_note'] == 'Any licenses'){
    $o1->company_doc5 = $_POST['company_note'];
    }

}
if ($_POST['company_address_note']!="") {
     if($_POST['company_address_note'] == 'Bank Statement'){
$o1->company_address_doc = $_POST['company_address_note'];
    }else   if($_POST['company_address_note'] == 'Cancel Check'){
$o1->company_address_doc1 = $_POST['company_address_note'];
    }else   if($_POST['company_address_note'] == 'Sample Invoice'){
$o1->company_address_doc2 = $_POST['company_address_note'];
    }else   if($_POST['company_address_note'] == 'Rental Agreement'){
 $o1->company_address_doc3 = $_POST['company_address_note'];
    }else   if($_POST['company_address_note'] == 'Utillity Bill'){
 $o1->company_address_doc4 = $_POST['company_address_note'];
    }else   if($_POST['company_address_note'] == 'Additional Document'){
 $o1->company_address_doc5 = $_POST['company_address_note'];
    }
	
}
if ($_POST['domain_note'] !="") {
     if($_POST['domain_note'] == 'Domain Ownership'){
    $o1->domain_type = $_POST['domain_note'];
    }else   if($_POST['domain_note'] == 'Processing statement'){
    $o1->processing_statement_doc = $_POST['domain_note'];
    }

}
    
        if ($_POST['kyc_id']>"0") {
            $o1->kyc_id=$_POST['kyc_id'];
            // $o1->kyc_id= $updater->update_object($o1, "kyc");
           
        }
        if ($_FILES['other_kyc_doc']['name'] != "") {


            $tmpfile = $_FILES['other_kyc_doc']['tmp_name'];
            $source = "../img/";
            $file_extension = explode(".", $_FILES['other_kyc_doc']['name']);
            if($_POST['kyc_note'] == 'Driving Licence'){
 $destination = $o1->kyc_id."Driving_licence." . end($file_extension);
    }else   if($_POST['kyc_note'] == 'Passport'){
 $destination = $o1->kyc_id."Passport." . end($file_extension);
    }else   if($_POST['kyc_note'] == 'Voter Card'){
  $destination = $o1->kyc_id."Voter_Card." . end($file_extension);
    }else   if($_POST['kyc_note'] == 'Additional Document'){
        $destination = $o1->kyc_id."Additional_doc." . end($file_extension);
    }
           
           
            $thumbnail = 1;
            $newsize = "100";
            $watermark = "";

            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);
           if($_POST['kyc_note'] == 'Driving Licence'){
 $o1->kyc_file2 = $destination;
    }else   if($_POST['kyc_note'] == 'Passport'){
 $o1->kyc_file1 = $destination;
    }else   if($_POST['kyc_note'] == 'Voter Card'){
 $o1->kyc_file3 = $destination;
    }else   if($_POST['kyc_note'] == 'Additional Document'){
       $o1->kyc_file5 = $destination;
    }
           
            // $o1->kyc_id = $updater->update_object($o1, "kyc");

        }
         if ($_FILES['other_doamin_doc']['name'] != "") {


            $tmpfile = $_FILES['other_doamin_doc']['tmp_name'];
            $source = "../img/";
            $file_extension = explode(".", $_FILES['other_doamin_doc']['name']);
              if($_POST['domain_note'] == 'Domain Ownership'){
      $destination = $o1->kyc_id."Domain_ownser." . end($file_extension);
    }else   if($_POST['domain_note'] == 'Processing statement'){
      $destination = $o1->kyc_id."Processing_st." . end($file_extension);
    }
          
            $thumbnail = 1;
            $newsize = "100";
            $watermark = "";

            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);
  if($_POST['domain_note'] == 'Domain Ownership'){
    $o1->domain_doc = $destination;
    }else   if($_POST['domain_note'] == 'Processing statement'){
    $o1->processing_statement = $destination;
    }
           
            // $o1->kyc_id = $updater->update_object($o1, "kyc");

        }
                if ($_FILES['other_company_doc']['name'] != ""){


            $tmpfile = $_FILES['other_company_doc']['tmp_name'];
            $source = "../img/";
            $file_extension = explode(".", $_FILES['other_company_doc']['name']);
              if($_POST['company_note'] == 'Incorporation'){
 $destination = $o1->kyc_id."Incorporation." . end($file_extension);
    }else   if($_POST['company_note'] == 'MOA'){
 $destination = $o1->kyc_id."MOA." . end($file_extension);
    }else   if($_POST['company_note'] == 'AOA'){
 $destination = $o1->kyc_id."AOA." . end($file_extension);
    }else   if($_POST['company_note'] == 'PAN'){
   $destination = $o1->kyc_id."PAN." . end($file_extension);
    }else   if($_POST['company_note'] == 'GST'){
    $destination = $o1->kyc_id."GST." . end($file_extension);
    }else   if($_POST['company_note'] == 'Any licenses'){
    $destination = $o1->kyc_id."Anylicenses." . end($file_extension);
    }
           
            $thumbnail = 1;
            $newsize = "100";
            $watermark = "";

            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);
 if($_POST['company_note'] == 'Incorporation'){
  $o1->company_file = $destination;
    }else   if($_POST['company_note'] == 'MOA'){
  $o1->company_file1 = $destination;
    }else   if($_POST['company_note'] == 'AOA'){
  $o1->company_file2 = $destination;
    }else   if($_POST['company_note'] == 'PAN'){
  $o1->company_file3 = $destination;
    }else   if($_POST['company_note'] == 'GST'){
   $o1->company_file4 = $destination;
    }else   if($_POST['company_note'] == 'Any licenses'){
     $o1->company_file = $destination;
    }
          
            // $o1->kyc_id = $updater->update_object($o1, "kyc");

        }
         if ($_FILES['other_company_adress_doc']['name'] != ""){


            $tmpfile = $_FILES['other_company_adress_doc']['tmp_name'];
            $source = "../img/";
            $file_extension = explode(".", $_FILES['other_company_adress_doc']['name']);
             if($_POST['company_address_note'] == 'Bank Statement'){
  $destination = $o1->kyc_id."Bank_st." . end($file_extension);

    }else   if($_POST['company_address_note'] == 'Cancel Check'){
  $destination = $o1->kyc_id."Cancel_check." . end($file_extension);
    }else   if($_POST['company_address_note'] == 'Sample Invoice'){
 $destination = $o1->kyc_id."Sample_invoice." . end($file_extension);
    }else   if($_POST['company_address_note'] == 'Rental Agreement'){
  $destination = $o1->kyc_id."Rental_agree." . end($file_extension);
    }else   if($_POST['company_address_note'] == 'Utillity Bill'){
  $destination = $o1->kyc_id."Utillity_bill." . end($file_extension);
    }else   if($_POST['company_address_note'] == 'Additional Document'){
  $destination = $o1->kyc_id."Additional_doc." . end($file_extension);
    }
                      $thumbnail = 1;
            $newsize = "100";
            $watermark = "";

            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);
 if($_POST['company_address_note'] == 'Bank Statement'){
  $o1->company_address_file = $destination;

    }else   if($_POST['company_address_note'] == 'Cancel Check'){
 $o1->company_address_file1 = $destination;
    }else   if($_POST['company_address_note'] == 'Sample Invoice'){
  $o1->company_address_file2 = $destination;
    }else   if($_POST['company_address_note'] == 'Rental Agreement'){
   $o1->company_address_file3 = $destination;
    }else   if($_POST['company_address_note'] == 'Utillity Bill'){
   $o1->company_address_file4 = $destination;
    }else   if($_POST['company_address_note'] == 'Additional Document'){
 $o1->company_address_file5 = $destination;
    }
           
            // $o1->kyc_id = $updater->update_object($o1, "kyc");

        }
        if ($_FILES['other_address_doc']['name'] != "") {

 
            $tmpfile = $_FILES['other_address_doc']['tmp_name'];
            $source = "../img/";
            $file_extension = explode(".", $_FILES['other_address_doc']['name']);
             if($_POST['address_note'] == 'Bank Statement'){
 $destination = $o1->kyc_id."Bank_St." . end($file_extension);
    }else   if($_POST['address_note'] == 'Utillity Bill'){
 $destination = $o1->kyc_id."Utillity_nbill." . end($file_extension);
    }else   if($_POST['address_note'] == 'Insurance'){
 $destination = $o1->kyc_id."Insurance." . end($file_extension);
    }else   if($_POST['address_note'] == 'Additional Document'){
        $destination = $o1->kyc_id."Additional_doc" . end($file_extension);
    }
           
            $thumbnail = 1;
            $newsize = "100";
            $watermark = "";

            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);
if($_POST['address_note'] == 'Bank Statement'){
  $o1->address_file = $destination;
    }else   if($_POST['address_note'] == 'Utillity Bill'){
  $o1->address_file1 = $destination;
    }else   if($_POST['address_note'] == 'Insurance'){
  $o1->address_file2 = $destination;
    }else   if($_POST['address_note'] == 'Additional Document'){
        $o1->address_file3 = $destination;
    }
          
           

        }
      
if ($_POST['kyc_id'] > 0) {
     $o1->kyc_id = $updater->update_object($o1, "kyc");
    $result['error'] = 1;
    $result['error_msg'] = "Saved SuccessFully";
}else{
  $result['error'] = 0;
    $result['error_msg'] = "Something Went Wrong";
}
  
  

echo json_encode($result);
?>