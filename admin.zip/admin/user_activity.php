<?php
session_start();
include "include.php";
include "session.php";

$tables = "1";

$sql = "Select A.user_id as a_user_id,A.*,B.* from user_activity as A CROSS JOIN wallet as B on (A.user_id = B.user_id) order by B.user_id desc" ;
$res = getXbyY($sql);
$row = count($res);

include "includes/header.php";
include "html/user_activity.php";
include "includes/footer.php";
include "js/user_activity.js";
?>