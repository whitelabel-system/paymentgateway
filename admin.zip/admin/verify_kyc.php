<?php
session_start();
include "include.php";
include "session.php";

if(isset($_GET['aid'])){
    $o1->kyc_id = $_GET['aid'];
}else{
    $o1->kyc_id = 0;
}

if($o1->kyc_id > 0){
    $o1 = $factory->get_object($o1->kyc_id,"kyc", "kyc_id");
    
    $o1->is_active = 1;
    $o1->status = "Approved";
    
    $o1->kyc_id = $updater->update_object($o1,"kyc");
    $o2 = $factory->get_object($o1->user_id,"users", "user_id");

    insert_notifications($o2->user_id , "You Doucments has been Verified" , "user_document");

    if ($o2->status =="Not Verify" && $o1->is_active =="1" ) {
    	$o2->kyc_id = $o1->kyc_id;
        $o2->status = "Verified";
    	$o2->user_id = $updater->update_object($o2,"users");
    }
    
    header("location:user_documents.php");

}else{
    header("location:user_documents.php");
}
?>