<?php
session_start();
include"include.php";
include"session.php";
if ($_POST['updte']=="1") {
if ($_POST['id'] > "0") {
$id = $_POST['id'];
}else{
	$id="0";
}
	if ($id >"0") {

$o1 = $factory->get_object($id, "help_category_question", 'help_category_question_id');
$result['category_name'] = $o1->category_name;
$result['category_question'] = $o1->category_question;
$result['category_answer'] = $o1->category_answer;
$result['is_active'] = $o1->is_active;

	$result['error']='1';	
	}else{
	$result['error']="0";

	}

}else{
	$result['error']="0";
}



echo json_encode($result);
?>