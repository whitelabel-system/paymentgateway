<?php
session_start();
include"include.php";
include"session.php";
$page_name="approve_disputes";
$tables= '1';

$sql = "Select * from disputes where is_active ='1' and dispute_status ='Approve' ";
$res = getXbyY($sql);
$rows = count($res);

include "includes/header.php";
include "html/approve_disputes.php";
include "includes/footer.php";
include "js/disputes.js";
?>