<?php
session_start();
include"include.php";
include"session.php";

if ($_POST['updte']=="1") {
$o1->refund_id =$_POST['refund_id'];

$o1 = $factory->get_object($o1->refund_id , "refund" ,"refund_id");
$o2 = $factory->get_object($o1->wallet_id , "wallet" ,"wallet_id");
$o4 = $factory->get_object($o1->user_id , "users" ,"user_id");
$o5 = $factory->get_object("1" , "users" ,"user_id");
$o1->resolved_by = $o->user_id;
$o1->updated_at = todaysDate();
$o1->other = $_POST['refund_resolution'];
$o5 = $factory->get_object("1" , "users" ,"user_id");

	

if ($_POST['refund_status1'] =="Approve") {
	$o2->refund = "Approved";
	$o1->status = "Approve";
	$o4->amount_balance = $o4->amount_balance - $o2->amount;
	$o5->admin_refund_amount = $o5->admin_refund_amount + $o2->amount;
	
	$result['status'] = "approved_refundlist.php";

}else{ 
$o1->status = "Reject";	
	$o2->refund = "Rejected";
	$result['status'] = "reject_refundlist.php";

}
$o1->refund_date = todaysDate();
$o1->refund_id = $updater->update_object($o1, "refund");
$o2->wallet_id = $updater->update_object($o2, "wallet");
$o4->user_id = $updater->update_object($o4, "users");
$o5->user_id = $updater->update_object($o5, "users");

$notification = "Refund has been ".$o2->refund."  ";
insert_notifications($o4->user_id,$notification , "refund");
$result['error']="1";
$result['error_msg'] ="refund responded Accordingly";

}else{
	$result['error']="0";
}
echo json_encode($result);
?>