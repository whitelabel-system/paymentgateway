<?php
session_start();
include"include.php";
include"session.php";
$page_name="card_process";
if(isset($_GET['aid'])){
$user_id = $_GET['aid'];
}
if ($user_id>"0") {

}else{
	$user_id="0";
}

$sql_card = "Select * from user_card_process Where user_id ='".$user_id."' "; 
$res_card= getXbyY($sql_card);
$row_card = count($res_card);
$sql = "Select * from credit_card_processor  where is_active='1' order by processor_name";
$res = getXbyY($sql);
$rows = count($res);	

include "includes/header.php";
include "html/card_process.php";
include "includes/footer.php";
include "js/card_process.js";
?>