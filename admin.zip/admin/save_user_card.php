<?php

session_start();
include "include.php";
include "session.php";

if ($_POST['updte'] ==1) {

	$user=$_POST['id'];
	$credit_card_processor_id=$_POST['credit_card_processor_id'];
	$status=$_POST['status'];
	$sql="Select * from user_card_process where user_id='".$user."' ";
	$res=getXbyY($sql);
	$row = count($res);
	if ($row =="0" ) {
		$o2->user_id = $user;
		$sql_services = "Select * from credit_card_processor where is_active=1";
		$res_services = getXbyY($sql_services);
		$rows_services = count($res_services);
		for ($i=0; $i < $rows_services; $i++) { 

			$o2->credit_card_processor_id = $res_services[$i]['credit_card_processor_id'];
			$o2->processor_name = $res_services[$i]['processor_name'];
			$o2->status = 'No';
			$o2->is_active = '1';
			$o2->created_at = todaysDate();
			$o2->updated_at = todaysDate();
			$o2->user_service_id = $insertor->insert_object($o2, "user_card_process");
		} 
	}else{

       for ($i=0; $i < $row; $i++) { 
       	if($status != 'No'){
       		 	$o3 = $factory->geT_object($res[$i]['user_card_process_id'],"user_card_process","user_card_process_id");
       	$o3->status = 'No';
       	$o3->user_card_process_id = $updater->update_object($o3,"user_card_process");
       	}
      
      
       
       }



	}

	$sql_update="update user_card_process set status='".$status."' where user_id='".$user."' and credit_card_processor_id='".$credit_card_processor_id."' ";
	$res_update=setXbyY($sql_update);
	
	

	$result['error']=1;
	

} else {

	$result['error']=0;
	
}

echo json_encode($result);