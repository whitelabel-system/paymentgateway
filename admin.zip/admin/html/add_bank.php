<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php if ($o1->bank_id > 0) { ?> Edit <?php } else { ?> Add <?php } ?> Bank Details</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-7">
                    <form name="ra" id="ra" method="post" action="save_bank.php?aid=<?= $o1->bank_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
                        <div class="row">
                            <div class="col-md">
                                <label>Account Name</label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?= $o1->name; ?>"    />
                            </div>
                            <div class="col-md">
                                <label>Company Address</label>
                                <input type="text" class="form-control" name="company_address" id="company_address" placeholder="Company Address" value="<?= $o1->company_address; ?>"    />
                            </div>
                        </div> <br/>
                        <div class="row">
                            <div class="col-md">
                                <label>Account Number</label>
                                <input type="text" class="form-control" name="account_number" id="account_number" placeholder="Account Number" value="<?= $o1->account_number; ?>"    />
                            </div>
                            <div class="col-md">
                                <label>IFSC Code</label>
                                <input type="text" class="form-control" name="ifsc_code" id="ifsc_code" placeholder="IFSC Code" value="<?= $o1->ifsc_code; ?>"    />
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md">
                                <label>Bank Address</label>
                                <input type="text" class="form-control" name="bank_address" id="bank_address1" placeholder="Bank Address" value="<?= $o1->bank_address; ?>"    />
                            </div>
                            <div class="col-md">
                                <label>Bank Contact Number</label>
                                <input type="text" class="form-control" name="bank_number" id="bank_number" placeholder="Bank Number" value="<?= $o1->bank_number; ?>"    />
                            </div>
                        </div><br>
                        <div class="row" >
                            <div class="col-md" >
                                <label>SWIFT/BIC Code</label>
                                <input type="text" class="form-control" name="swift_code" id="swift_code"  placeholder="Enter SWIFT/BIC Code" >
                            </div>
                            <div class="col-md" >
                                <label>IBAN</label>
                                <input type="text" class="form-control" name="iban" id="iban"  placeholder="Enter IBAN" >
                            </div>
                            <div class="col-md" >
                                <label>ABA Routing Number</label>
                                <input type="text" class="form-control" name="aba_number" id="aba_number"  placeholder="Enter ABA Number" >
                            </div>
                        </div>​
                        <br/>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Status</label>
                                <select name="is_active" id="is_active" class="form-control">
                                    <option value="1" <?php if ($o1->is_active == 1) { ?> selected="selected" <?php } ?>>Active</option>
                                    <option value="0" <?php if ($o1->is_active == 0) { ?> selected="selected" <?php } ?>>Blocked</option>
                                </select>
                            </div>
                        </div>

<!--                    <div class="col-md-4">
                        <label>Bank Name</label>
                        <input type="text" class="form-control" name="bank_name" id="bank_name" placeholder="Bank Name" value="<?= $o1->bank_name; ?>"    />
                    </div>
                    <div class="col-md-4">
                        <label>Branch</label>
                        <input type="text" class="form-control" name="branch" id="branch" placeholder="Branch" value="<?= $o1->branch; ?>"    />
                    </div>-->
<!--                    <div class="col-md-4">
                        <label>Address</label>
                        <input type="text" class="form-control" name="address" id="address" placeholder="Address" value="<?= $o1->address; ?>"    />
                    </div>
                    <div class="col-md-4">
                        <label>City</label>
                        <input type="text" class="form-control" name="city" id="city" placeholder="City" value="<?= $o1->city; ?>"    />
                    </div>-->
<!--                    <div class="col-md-4">
                        <label>District</label>
                        <input type="text" class="form-control" name="district" id="district" placeholder="District" value="<?= $o1->district; ?>"    />
                    </div>-->
<!--                    <div class="col-md-4">
                        <label>State</label>
                        <input type="text" class="form-control" name="state" id="state" placeholder="State" value="<?= $o1->state; ?>"    />
                    </div>-->
<!--                    <div class="col-md-4">
                        <label>RTGS</label>
                        <input type="text" class="form-control" name="rtgs" id="rtgs" placeholder="RTGS" value="<?= $o1->rtgs; ?>"    />
                    </div>
                    <div class="col-md-4">
                        <label>Contact</label>
                        <input type="text" class="form-control" name="contact" id="contact" placeholder="Contact" value="<?= $o1->contact; ?>"    />
                    </div>
                    <div class="col-md-4">
                        <label>Bank Code</label>
                        <input type="text" class="form-control" name="bank_code" id="bank_code" placeholder="Bank Code" value="<?= $o1->bank_code; ?>"    />
                    </div>-->



                    <hr/>
           <!--      <div class="alert alert-warning" role="alert">
                    Activating this bank account will deactivate all other bank accounts !
                </div> -->
                <div class="row top_margin_10">
                    <div class="col-md-12">
                          <input type="hidden" name="user_id" id="user_id" value="<?= $user_id; ?>" />
                        <input type="hidden" name="bank_id" id="bank_id" value="<?= $o1->bank_id; ?>" />
                        <input type="hidden" name="updte" id="updte" value="1" />
                        <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
                        <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-5">
           <span id="bank_details"></span> 
       </div>
   </div>
</div>
</div>
</div>
<!-- /.container-fluid