<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3 row" style="margin-left:0px;margin-right: 0px">
            <span class="col-md-2 h6 m-0 font-weight-bold text-primary">All tickets</span>
            <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="add_ticket.php">Add New </a>
    </div>
            
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0" cellpadding="10">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>#</th>
                                    <th>Subject</th>
                                    <th>Priority</th>
                                    <th>Department</th>
                                    <th>Message</th>
                                    <th>Ticket-No.</th>
                                    <th>Date</th>
                                    <th>Ticket-Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody style="text-align: start;">
                                <?php for ($i = 0; $i < $row; $i++) { ?>
                                    <tr>
                                        <td><?= ($i + 1) ?></td>
                                        <td><?= ucfirst($res[$i]['subject']); ?></td>
                                        <td><?= ucfirst($res[$i]['priority']); ?></td>
                                        <td><?= ucfirst($res[$i]['department']); ?></td>
                                        <td><?= ucfirst($res[$i]['message']); ?></td>
                                        <td><?= $res[$i]['ticket_number']; ?></td>
                                        <td><?= $res[$i]['created_at'] ?> </td>
                                        <td><?= $res[$i]['status'] ?></td>
                                        <td>
                                            <a href="ticket_reply.php?aid=<?= $res[$i]['ticket_id'] ?>">
                                                <button class="btn btn-success">Reply</button>
                                            </a>
                                            <?php if ($res[$i]['status']=="Closed") {?>
                                             <a href="#" onclick="open_ticket(<?= $res[$i]['ticket_id'] ?>)"><button class="btn btn-success">Closed</button></a>
                                         <?php }else{ ?>
                                             <a href="#" onclick="close_ticket(<?= $res[$i]['ticket_id'] ?>)" ><button class="btn btn-success">Close</button></a>
                                         <?php } ?>
                                         
                                     </td>
                                 </tr>
                             <?php } ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 </div>
</div>