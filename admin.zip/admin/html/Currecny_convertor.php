   <!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->
 
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Currency Convertor</h6>
    </div>
    <div class="card-body">
      <form name="ra" id="ra" method="post" >
   <div class="col-md-12" >     
 <div class="col-md-12 row" style="background-color: #fdbe2a;padding:2px;color: #fff;margin-bottom: 10px">     
    <h4 class="col-md-6">Default Currency</h4>   
      <h4 class="col-md-6" style="align-items: right">Manual Currency</h4>
    </div>
    <div class="row">

          <div class="col-md-6 row">
          <div class="col-md-5">
            <?php for($i=0 ;$i< $row ;$i++){?>
               <div class="row">
          <div class="col-md-1"> <input type="radio" name="Currency" id="<?= $res[$i]['currency_name'] ?>" value="<?= $res[$i]['currency_name'] ?>" onChange="get_cuval(this.value)"/>  </div>
           <div class="col-md-10"> <label for="<?= $res[$i]['currency_name'] ?>"><?= $res[$i]['currency_name'] ?></label>  </div></div><br>
          <?php } ?></div>
    
          <div class="col-md-6">
          <label>Enter <span id="curval">USD</span> Value</label>
              <input type="text" name="Default_currencyva" id="Default_currencyva" value=""/>
          </div>  </div>
    
      
          <div class="col-md-6">
            <ul>
           <?php for($i=0 ;$i< $row ;$i++){?>
           
            <li>
              <?= $res[$i]['currency_name'] ?>       <input type="text" name="<?= $res[$i]['currency_name'] ?>_val" id="<?= $res[$i]['currency_name'] ?>_val" value=""/>
            </li>
             
               <br>
          <?php } ?>
        </ul>
        
          </div>
    
       
          <div class="col-md-6 mt-4">
            <input type="hidden" name="updte" id="updte" value="1" />
            <input type="submit" name="save" id="save" value="Convert" class="btn btn-primary" />
          
                </div> </div></div>
       
      </form>
    </div>
  </div>
</div>
<!-- /.container-fluid -->