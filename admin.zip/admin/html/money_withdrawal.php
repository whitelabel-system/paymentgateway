<div class="container-fluid">
   <div class="row">
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"> Add Settlement</h6>
                </div>

                <div class="card-body">
                    <div id="user_info">
                        <form name="money_withdrawal" id="money_withdrawal" method="post" action="request_money_withdrawal.php" onsubmit="return false;"  enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <label>Select User</label>
                                    <select name="user_id" id="user_id" class="form-control  select2_single " required onchange="get_userbalance(this.value)">
                                        <option value="">Select User</option>
                                        <?=user_list_dropdown($user_id)?>
                                    </select>

                                </div>
                                <div class="col-md-6">
                                    <label>Withdrawal Amount</label>
                                    <input type="number" class="form-control" min="1" name="amount" id="amount" placeholder="Amount in Rs" value="" required="required" step="0.01" />

                                </div>
                                
                            </div>
                            <div class="row">
                                
                                <div class="col-md-6">
                                    <label>Select Country</label>
                                    <select name="country_id" id="country_id" class="form-control" >
                                        <?=country_list($o1->country_id)?>
                                    </select>
                                </div>
                                 <div class="col-md-4" id="balnce_div" style="border-radius: 12px;
    margin-right: 2px;padding: 10px; margin-top: 20px;
    border: 1px dashed; margin-left: 14px; display: none">
                                    <label>User Balance:</label>
                              
                                  <span id="bal_uu"></span>
                                 </div>
                            
                            </div>
                            <div class="row top_margin_10">
                                <div class="col-md-12">
                                    <input type="hidden" name="updte" id="updte" value="1" />
                                    <button type="submit" name="save" id="save"  class="btn btn-primary"  >Add Settlement</button>
                                    <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="window.history.back();" />
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div id="processing" style="display:none;" class="text-center">
                    <?php include "html/processing.php"; ?>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div id="send_money_direct">
                
            </div>
        </div>
    </div>

</div>
<div class="modal fade" id="send_money_confirm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Are You Sure?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">Select Send below if you are ready to Send Money</div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" onclick="submit_send_money()" style="color: #fff;" >Send</a>
        </div>
    </div>
</div>
</div>

<!-- /.container-fluid -->