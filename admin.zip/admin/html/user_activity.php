<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <span class="h6 m-0 font-weight-bold text-primary">User Activity</span>
            
            
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" cellpadding='10' id="dataTable" width="100%" cellspacing="0">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>Sr.No.</th>
                                    <th>User Details</th>
                                    <th> User Type </th>
                                    <th>Activity</th>
                                    <th>Amount</th>
                                    <th> Transactions Details </th>
                                    <th>Activity Time</th> 
                                    <th>Ip Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for ($i = 0; $i < $row; $i++) {  ?>
                                    <tr>
                                        <td><?= ($i + 1) ?></td>
                                         <td><?=get_user_fund_name($res[$i]['a_user_id'])?></td>
                                          <td><?=get_user_type($res[$i]['a_user_id'])?></td>
                                        <td><?= $res[$i]['activity_name'] ?></td>
                                        <td><?= $res[$i]['amount'] ?></td>
                                          <td><?= $res[$i]['transaction_details'] ?></td>
                                        <td><?= $res[$i]['activity_time'] ?> </td>
                                        <td><?= $res[$i]['ip_address'] ?></td>
                                       
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>