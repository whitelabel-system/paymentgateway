<div class="container-fluid">

    <div class="row"></div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Users</h6>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>Sr.no</th>
                                    <th>Name</th>
                                    <th>Email & Mobile</th>
                                    <th>Created at</th>
                                    <th>Status</th>
                                    <th>Authentication</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for ($i = 0; $i < $row; $i++) { ?>
                                    <tr>
                                        <td><?= ($i + 1) ?></td>
                                        <td><?= ucfirst($res[$i]['name']) ?> <br/>  <span style="color:green"> <?= $res[$i]['user_name'] ?></span> <br/> (<?= $res[$i]['company_type'] ?>)</td>
                                        <td> <?= $res[$i]['email'] ?> <span>
                                                <?php if ($res[$i]['email_verified'] == "Yes") { ?>
                                                    <i class=" fa fa-check   fa_verified"></i>
                                                <?php } ?>
                                            </span><br/><?= $res[$i]['mobile'] ?>
                                            <?php if ($res[$i]['mobile_verified'] == "Yes") { ?>
                                                <i class="fa fa-check  fa_verified"></i>
                                            <?php } ?>  </td>
                                        <td><?= format_date($res[$i]['created_at']) ?></td>
                                        <td><?= status($res[$i]['is_active']) ?></td>
                                        <td> <label class="switch">
        <input type="checkbox" name="status_<?=$i?>" id="status_<?=$i?>";
<?php  if($res[$i]['otp_enabled']=='Yes'){?>
        
             checked="checked";
       <?php } ?>  

          onclick="save_user_auth(<?=$res[$i]['user_id']?>,<?=$i?>)"  value="Yes">
        <span class="slider round span_margin">Yes</span>
        </label> </td>
                                    </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

