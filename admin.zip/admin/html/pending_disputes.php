<div class="container-fluid">
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Pending Disputes</h6>
        </div>

        <div class="card-body">
            <form name="search_txn" id="search_txn" method="post"  action="dispute_list.php" onsubmit="return false;" >
                <div class="row">
                    <div class="col-md-3">
                        <label>User Name</label>
                        <select name="user_id" id="user_id" class="form-control select2_single" required="">
                            <option value="0">Select User </option>
			    <?= user_list_dropdown(0); ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label>From</label>
                        <input type="date" class="form-control" name="from_date" id="from_date" placeholder="From Date" value="<?= format_date_without_time($dd); ?>" />
                    </div>
                    <div class="col-md-3">
                        <label>To</label>
                        <input type="date" class="form-control" name="to_date" id="to_date" placeholder="To Date" value="<?= format_date_without_time($dd) ?>"  />
                    </div>
		    <input type="hidden" name="Status" id="Status" value="<?= $status ?>">
                    <div class="col-md-3">
                        <label>&nbsp;</label>
                        <input type="submit" name="search_result" id="search_result" class="form-control btn btn-primary" value="Search Records" />
                    </div>

                </div>
            </form>
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" cellpadding='10' id="pending_dispute_list" width="100%" cellspacing="0">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
				    <th>Sr.no</th>
                                    <th>Transaction Type</th>
                                    <th>User Detail</th>
                                    <th>Transaction Number</th>
                                    <th>Total Amount</th>
                                    <th>Payment Amount</th>
                                    <th>Dispute Date</th>
                                    <th>Status</th>
				    <th>Action</th>
                                </tr>
                            </thead>

                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<div  id="dispute_modal"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Dispute</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body" id="dispute_details">
		<form name="dispute_response" id="dispute_response" method="post" onsubmit="return false;" >
		    <div class="row">
			<div class="col-md-8">
			    <label>Remarks</label>
			    <input type="text" name="dispute_resolution" id="dispute_resolution" class="form-control" >
			</div>
		    </div>
		    <div class="row top_margin_10" >
			<div class="col-md-12">
			    <input type="hidden" id="dispute_status1" name="dispute_status1" >
			    <input type="hidden" id="dispute_id" name="dispute_id" >
			    <input type="hidden" id="updte" name="updte" value="1">
			    <button type="submit" name="save_button" id="save_button" class="btn btn-primary"> Save </button>
			    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
			</div>
		    </div>
		</form>

            </div>

        </div>


    </div>
</div>
<div  id="disputereasonadd_modal"class="modal  bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Dispute Reason</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" id="dissmiss">&times;</span>
                </button>

            </div>
            <div class="modal-body" id="dispute_details">
		<form name="dispute_add" id="dispute_add" method="post" onsubmit="return false;" >
		    <div class="row">
			<div class="col-md-8">
			    <label>Reason</label>
			    <input type="text" name="dispute_reason" id="dispute_reason" class="form-control" >
			</div>
		    </div>
		    <div class="row top_margin_10" >
			<div class="col-md-12">
			    <input type="hidden" id="dispute_status2" name="dispute_status2" >
			    <input type="hidden" id="adispute_id" name="adispute_id" >
			    <input type="hidden" id="updte" name="updte" value="1">
			    <button type="submit" name="save_button1" id="save_button1" class="btn btn-primary"> Save </button>
			    <button class="btn btn-secondary" type="button" data-dismiss="modal" id="dissmiss1">Cancel</button>
			</div>
		    </div>
		</form>

            </div>

        </div>


    </div>
</div>