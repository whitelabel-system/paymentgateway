<!-- Begin Page Content -->
<div class="container-fluid">
    <form name="profile" id="profile" method="post"  enctype="multipart/form-data" onsubmit="return false" >
	<div class="row">
	    <div class="col-md-8">
		<div class="card shadow mb-4">
		    <div class="card-header py-3">
			<div class="row">
			    <div class="col-md-4"> <h6 class="m-0 font-weight-bold text-primary">Edit Profile</h6></div>

			</div>
		    </div>
		    <div class="card-body">
			<div class="row">
			    <div class="col-md-4">
				<label>Name</label>
				<input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?= $o->name; ?>" required="required" />
			    </div>   

			    <div class="col-md-4">
				<label>Email</label>
				<input type="text" name="email" id="email" class="form-control" required="required"  value="<?= $o->email; ?>" placeholder="Enter Email" />
			    </div>                
			    <div class="col-md-4">
				<label>Mobile Number</label>
				<input type="text" name="mobile" id="mobile" class="form-control"  required="required" value="<?= $o->mobile; ?>" placeholder="Enter Mobile No" />
			    </div>
			    <div class="col-md-4">
				<label>Alternative Number</label>
				<input type="text" name="mobile_1" id="mobile_1" class="form-control" value="<?= $o->mobile_1; ?>" placeholder="Alternative Mobile No" />
			    </div>
			    <div class="col-md-4">
				<label>URL</label>
				<input type="text" name="url" id="url" class="form-control" value="<?= $o->url; ?>" placeholder="URL" />
			    </div>
			    <div class="col-md-4">
				<label>Company Name</label>
				<input type="text" name="company_name" id="company_name" class="form-control" placeholder="Company Name" value="<?= $o->company_name; ?>" />
			    </div>
			    <div class="col-md-4">
				<label>2F Authentication</label>
				<select name="otp_enabled" id="otp_enabled" class="form-control" required>
				    <option value="Yes" <?php if ($o1->otp_enabled == "Yes") { ?> selected="selected" <?php } ?>>Yes</option>
				    <option value="No" <?php if ($o1->otp_enabled == "No") { ?> selected="selected" <?php } ?>>No</option>
				</select>
			    </div>
			    <hr/>
			    <div class="col-md-12 mt-2">
				<div class="card-header py-3">
				    <h6 class="m-0 font-weight-bold text-primary">Address Details</h6>
				</div>
			    </div>

			    <div class="col-md-4">
				<label>Address</label>
				<input type="text" name="user_address" id="user_address" class="form-control" placeholder="User Address" value="<?= $o->user_address; ?>" />
			    </div>
			    <div class="col-md-4">
				<label>District</label>
				<input type="text" name="district" id="district" class="form-control" placeholder="District" value="<?= $o->district; ?>" />
			    </div>
			    <div class="col-md-4">
				<label>State</label>
				<input type="text" name="state" id="state" class="form-control" placeholder="State" value="<?= $o->state; ?>" />
			    </div>
			    <div class="col-md-4">
				<label>Pincode</label>
				<input type="text" name="pincode" id="pincode" class="form-control" placeholder="pincode" value="<?= $o->pincode; ?>" />
			    </div>
			    <div class="col-md">
				<label>Country</label>
				<select name="country_id" id="country_id" class="form-control">
				    <?= country_list($o->country_id) ?>
				</select> 
			    </div>
			    <div class="col-md">
				<label>TimeZone</label>

				<?= select_Timezone($o->timeZone) ?>
			    </div>
			    <hr/>
			    <div class="col-md-12">
				<div class="row top_margin_10">
				    <div class="col-md-12">
					<input type="hidden" name="user_id" id="user_id" value="<?= $o->user_id; ?>" />
					<input type="hidden" name="updte" id="updte" value="1" />
					<input type="submit" name="save" id="save" value="Save" class="btn btn-primary" />
					<input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

				    </div>
				</div>
			    </div>
			</div>
		    </div>
		</div>
	    </div>
	    <div class="col-md-4">
		<div class="col-md-12">
		    <div class="card shadow mb-4">
			<div class="card-header py-3">
			    <h6 class="m-0 font-weight-bold text-primary">Profile Image & Logo</h6>
			</div>
			<div class="card-body">
			    <div class="row">
				<div class="col-md-12">
				    <label>Profile Pic</label>
				    <input type="file" name="profile_pic" id="profile_pic" class="form-control" />
				</div>
				<?php if ($o->profile_pic != "") { ?>
    				<div class="col-md-12 pt-3">
    				    <img src="<?= $o->profile_pic; ?>"  width="50%"  />
    				</div>
				<?php } ?>
			    </div>
			    <div class="row">
				<div class="col-md-12">
				    <label>Logo</label>
				    <input type="file" name="logo" id="logo" class="form-control" />
				</div>
				<?php if ($o->logo != "") { ?> 
    				<div class="col-md-12 pt-3">
    				    <img src="../img/<?= $o->logo; ?>"  width="45%"  />
    				</div>
				<?php } ?> 
			    </div>
			</div>
		    </div>
		</div>
	    </div>
	</div>
    </form>
</div>
<div class="container-fluid">
    <form name="ra" id="ra" method="post" action="save_bank.php?aid=<?= $o1->bank_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
	<div class="row">
	    <div class="card shadow mb-4">
		<div class="card-header py-3">
		    <div class="row">
			<div class="col-md-4"> <h6 class="m-0 font-weight-bold text-primary">Billing Details</h6></div>
		    </div>
		</div>
		<div class="card-body row col-md-12">
		    <div class="col-md-8">
			<div class="row">
			    <div class="col-md-6">
                                <label>Account Name</label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?= $o1->name; ?>"    />
                            </div> 
			    <div class="col-md-6">
				<label>Account Number</label>
                                <input type="text" size="1000" class="form-control" name="account_number" id="account_number" placeholder="Account Number" value="<?= $o1->account_number; ?>"    />
			    </div>
			    <div class="col-md-6">
				<label>Company Address</label>
                                <input type="text" size="1000" class="form-control" name="company_address" id="company_address" placeholder="Company Address" value="<?= $o1->company_address; ?>"    />
			    </div>                
			   
			    <div class="col-md-6">
				<label>Bank Address</label>
                                <input type="text" class="form-control" name="bank_address" id="bank_address1" placeholder="Bank Address" value="<?= $o1->address; ?>"    />
			    </div>
			    <div class="col-md-6">
				<label>Bank Contact Number</label>
                                <input type="number" class="form-control" name="bank_number" id="bank_number" placeholder="Bank Number" value="<?= $o1->contact; ?>"    />
			    </div>   
			    <div class="col-md-6">
				<label>SWIFT/BIC Code</label>
                                <input type="text" class="form-control" name="swift_code" id="swift_code"  placeholder="Enter SWIFT/BIC Code"  value="<?= $o1->swift_code; ?>"   >
			    </div>   
			</div>
		    </div>
		    <div class="col-md-4">
			<div class="col-md-12">
			    <div class="row">
				<div class="col-md-12">
				    <label>ABA Routing Number</label>
				    <input type="text" class="form-control" name="aba_number" id="aba_number"  placeholder="Enter ABA Number" value="<?= $o1->aba_number ?>" >
				</div>
			    </div>
			    <div class="row">
				<div class="col-md-12">
				    <label>IBAN</label>
				    <input type="text" class="form-control" name="iban" id="iban"  placeholder="Enter IBAN" value="<?= $o1->iban ?>" >
				</div>
			    </div>
			    <div class="row">
				<div class="col-md-12">
				    <label>IFSC Code</label>
				    <input type="text" class="form-control" name="ifsc_code" id="ifsc_code" placeholder="IFSC Code" value="<?= $o1->ifsc_code; ?>"    />
				</div>
			    </div>
			</div>
		    </div>
		    <hr/>
		    <div class="col-md-12">
			<div class="row top_margin_10">
			    <div class="col-md-12">
				<input type="hidden" name="bank_id" id="bank_id" value="<?= $o1->bank_id; ?>" />
				<input type="hidden" name="user_id" id="user_id" value="<?= $o->user_id; ?>" />
				<input type="hidden" name="updte" id="updte" value="1" />
				<button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
				<input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

			    </div>
			</div>
		    </div>
		</div>
	    </div>
	</div>
    </form>
</div>