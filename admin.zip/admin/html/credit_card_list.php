<!-- Begin Page Content -->
<div class="container-fluid">
   
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <div class="col-md-12 text-left ">
              All Payment List
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="10">
                        <thead style="color:#fff;background-color:#6162d8;">
                            <tr>
                               <th>Sr.no</th>
                                    <th>Transaction Type</th>
                                    <th>user Detail</th>
                                    <th>Transaction Number</th>
                                    <th>Total Amount</th>
                                    <th>Payment Amount</th>
                                    <th>Status</th>
                                    <th>Created at</th>
                                    <th>Action</th>
                               
                            </tr>
                        </thead>
                        <tbody style="text-align: start;">
                            <?php for ($i = 0; $i < $row; $i++) { ?>
                                <tr>
                                        <td ><?= ($i + 1) ?></td>
                                        <td><?=$res[$i]['transaction_type']?></td>

                                        <td> <?= get_user_fund_name($res[$i]['user_id']) ?> </td>
                                        <td> <?= $res[$i]['ref_number'] ?> </td>
                                        <td> <?= $res[$i]['total_amount'] ?> </td>
                                         <td><?= $res[$i]['amount'] ?></td>
                                         <td><?= $res[$i]['status']?>  </td>
                                        <td><?= format_date($res[$i]['created_at']) ?></td>
                                     <td><a href="#" onclick="chargeback(<?=$res[$i]['wallet_id']?>)"><i style="color: #ffb544;" class="fas fa-gavel fa-fw"></i></a></td>
                                    </tr>
                            <?php } ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 
<div  id="chargeback_modal"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">

        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Chargeback</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body" id="chargeback_details">
            <form name="chargeback_response" id="chargeback_response" method="post" onsubmit="return false;" >
                <div class="row">
                    <div class="col-md-12">
                        <label>Remarks</label>
                        <input type="text" name="chargeback_resolution" id="chargeback_resolution" class="form-control" >
                    </div>
                </div>
                <div class="row top_margin_10" >
                <div class="col-md-12">
                <input type="hidden" id="chargeback_status1" name="chargeback_status1" >
                <input type="hidden" id="wallet_id" name="wallet_id" >
                <input type="hidden" id="updte" name="updte" value="1">
                <button type="submit" name="save_button" id="save_button" class="btn btn-primary"> Save </button>
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            </div>
            </div>
            </form>

            </div>

        </div>


    </div>
</div>