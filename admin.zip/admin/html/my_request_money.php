<?php for ($i = 0; $i < $row_request_money; $i++) {?>
    <a class="dropdown-item d-flex align-items-center"href="#">
        <div>
            <div class="small text-gray-500"><?=format_date_without_br($res_request_money[$i]['request_date']);?></div>
            
                <span class="font-weight-bold"><?=get_user_name_id($res_request_money[$i]['user_id'])." Requeted Amount Of ".$res_request_money[$i]['amount'].""?></span>
            
        </div>
    </a>
<?php }?>
<a class="dropdown-item text-center small text-gray-500" href="#">See All Requests</a>