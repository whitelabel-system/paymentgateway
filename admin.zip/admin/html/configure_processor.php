<!-- Begin Page Content --> 
<div class="container-fluid"> 
    <!-- Page Heading -->
    
    <!-- DataTales Example -->
    <form name="ra" id="ra" method="post" action="configure_processor.php" enctype="multipart/form-data" >
        <div class="row">
        <div class="col-md-12" >
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Configure Processor</h6>
                </div>
                <div class="card-body" style="padding: 14px;">
     <div class="row">
      <div class="col-md-4">
        <label>Merchant Number</label>
        <input type="text" class="form-control" name="merchant_number" id="merchant_number" placeholder="Enter Merchant Number" value="<?= $o2->merchant_number; ?>" required="required" />
      </div>      

    <div class="col-md-4">
      <label>Terminal Number</label>
      <input type="text" name="terminal_number" id="terminal_number" class="form-control" required="required"  value="<?= $o2->terminal_number; ?>" placeholder="Enter Terminal Number" />
    </div>                
    <div class="col-md-4">
      <label>Check Digit</label>
      <input type="text" name="check_digit" id="check_digit" class="form-control"  required="required" value="<?= $o2->check_digit; ?>" placeholder="Enter Check Digit" />
    </div>
    <div class="col-md-4">
      <label>Device Identification</label>
      <input type="text" name="device_identification" id="device_identification" class="form-control" value="<?= $o2->device_identification; ?>" placeholder="Device Identification" />
    </div>
   <hr/>
  <!-- <div class="col-md-12 mt-2">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Merchant Category Code</h6>
    </div>
  </div>
 -->
<!-- <div class="col-md-4">
    <label>Search MCC</label>
    <input type="text" name="mcc" id="mcc" class="form-control" placeholder="Search MCC" value="<?= $o2->mcc; ?>" />
  </div> -->
<!-- <div class="col-md-4">
    <label>Category</label>
<select name="top_category" id="top_category"class="form-control select2_single" >
    <option value="">Select MCC Category</option>
     <?= get_mccCategory( $o2->device_identification) ?>
</select>
  </div>
  <div class="col-md-4">
    <label>Merchant Category Code</label>
<select name="merchant_category" id="merchant_category" class=" select2_single form-control" >
    <option value="">Select MCC Codes</option>
    <?= get_mccCodes( $o2->device_identification) ?>
</select>
  </div>
 -->
  <hr/>
  <div class="col-md-12 mt-2">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Account Classification</h6>
    </div>
  </div>

  <div class="col-md-6 mt-2">
    <label>Classification</label><br/>
    <select name="account_type[]" id="account_type"class="form-control" multiple >
    <!-- <option value="">Select Classification</option> -->
    <option value="Ecommerce">Ecommerce</option>
    <option value="Retail">Retail</option>
    <option value="MOTO">MOTO</option>
    <option value="Echeck">Echeck</option>
</select>
  </div>
   <hr/>
  <div class="col-md-12 mt-2">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Technologies/Payment Modes</h6>
    </div>
  </div>
        <div class="row top_margin_10  col-md-12">
            <?php for($i=0;$i<$rows_services;$i++) {  ?>
        <div class="col-md-6">
        <span><?=$res_services[$i]['service_name']?> </span>
        </div>
        <div class="col-md-6">
            <label class="switch">
         <input type="checkbox" name="status_<?=$i?>" id="status_<?=$i?>"
          <?php for ($j=0; $j <$row_user_service; $j++) {  ?>
          <?php if ($res_user_service[$j]['status']=="Yes" && $res_services[$i]['service_id']==$res_user_service[$j]['service_id'] ){?>
             
             checked="checked";
          <?php } ?>
        

          <?php } ?>

        onclick="save_user_rights(<?=$res_services[$i]['service_id']?>,<?=$i?>,<?=$user_id ?>)"  value="Yes">
        <span class="slider round span_margin">Yes</span>
        </label>
        </div>
    <?php } ?>
 </div>

  <hr/>
  
<div class="col-md-12">
 <div class="row top_margin_10">
   <div class="col-md-12">
    <input type="hidden" name="user_id" id="user_id" value="<?= $user_id; ?>" />
    <input type="hidden" name="updte" id="updte" value="1" />
    <input type="submit" name="save" id="save" value="Save" class="btn btn-primary" />
    <a type="button" name="save" id="save" value="Back" class="btn btn-primary" href="card_process.php?aid=<?=$user_id?>" >Back</a>
 <a type="button" name="save" id="save" value="Next" class="btn btn-success" style="width: auto;" href="choose_user_plan.php?aid=<?=$user_id?>" >Next</a>
    <!-- <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" /> -->

  </div>
</div>
</div>

</div>

</div>
            </div>
        </div>
        
</div>
</form>
</div>
<!-- /.container-fluid