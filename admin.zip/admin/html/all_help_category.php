<!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="row">
    <div class="col-md-6">
      <h1 class="h3 mb-2 text-gray-800">Help Category</h1>
    </div>
    <div class="col-md-6 text-right">
      <a class="btn btn-primary" href="help_category.php">Add New Help Category</a>
    </div>
  </div>
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">List of Help Category</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>S.No</th>
              <th>Category</th>
              <th>Category Icon</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
          <tr>
            <th>S.No</th>
            <th>Category</th>
              <th>Category Icon</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
          </tfoot>
          <tbody style="text-align: start;">
            <?php for ($i = 0; $i < $rows; $i++) {?>
            <tr >
              <td style="padding-left: 10px"><?=$i + 1;?></td>
              <td style="padding-left: 10px">
                <?=$res[$i]['category_name'];?>
              </td>
            <td style="padding-left: 10px">
            <img src="../img/<?=$res[$i]['other']?>"  style= "height:35px;">
            </td>
              <td style="padding-left: 10px">
                <?=status($res[$i]['is_active']);?>
              </td>
              <td style="padding-left: 10px">
                <a href="help_category.php?aid=<?=$res[$i]['help_category_id'];?>" ><i class="fa fa-pen-square fa-fw"></i></a>|
                <a href="add_category_question.php?aid=<?=$res[$i]['help_category_id'];?>" ><i class="fa fa-plus-square fa-fw"></i></a>
              </td>
            </tr>
            <?php }?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid -->