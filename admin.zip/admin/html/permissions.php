<!-- Begin Page Content --> 
<div class="container-fluid">
  <!-- Page Heading -->
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary"> Permissions </h6>
    </div>
    <div class="card-body">
      <form name="ra" id="ra" method="post" action="save_users.php?aid=<?= $o1->user_setting_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
        <div class="row">
          <div class="row col-md-12 " >
            <div class="col-md-6">
              <label>Permissions</label>
              <input name="permission_name" id="permission_name" class="form-control" required="" type="text" value="<?= $o1->permission_name ?>">
              
            </div>
            <div class="col-md-6">
              <label>Status</label>
              <select name="is_active" id="is_active" class="form-control" required   >
                <option value="1" <?php if ($o1->is_active == 1) { ?> selected="selected" <?php } ?>>Active</option>
                <option value="0" <?php if ($o1->is_active == 0) { ?> selected="selected" <?php } ?>>Blocked</option>
              </select>
            </div>
          </div>
          <div class="row col-md-12 " >
            <p style="width: 100%; margin: 8px;"> Merchants </p>
            <div class="col-md-3">
              <!-- <label>Gateway transaction fees</label> -->
              <input type="checkbox" name="create_merchants" id="create_merchants" <?php if($o1->create_merchants == 'Yes'){ ?> checked <?php } ?> value="Yes" />
              <label for="create_merchants"> Create </label>
            </div>
            <div class="col-md-3">
             <input type="checkbox" name="edit_merchants" id="edit_merchants" <?php if($o1->edit_merchants == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
             <label for="edit_merchants"> Edit </label>
           </div>
           <div class="col-md-3">
             <input type="checkbox" name="delete_merchants" id="delete_merchants" <?php if($o1->delete_merchants == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
             <label for='delete_merchants'> Delete </label>
           </div>
         </div>
         <div class="row col-md-12">
          <p style="width: 100%; margin: 8px;">Affiliate</p>
          <div class="col-md-3">
            <!-- <label>Gateway transaction fees</label> -->
            <input type="checkbox" name="create_affiliate" id="create_affiliate" <?php if($o1->create_affiliate == 'Yes'){ ?> checked <?php } ?> value="Yes" />
            <label for="create_affiliate"> Create </label>
          </div>
          <div class="col-md-3">
           <input type="checkbox" name="edit_affiliate" id="edit_affiliate" <?php if($o1->edit_affiliate == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
           <label for="edit_affiliate"> Edit </label>
         </div>
         <div class="col-md-3">
           <input type="checkbox" name="delete_affiliate" id="delete_affiliate" <?php if($o1->delete_affiliate == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
           <label for='delete_affiliate'> Delete </label>
         </div>
       </div>
       <div class="row col-md-12 " >
        <p style="width: 100%; margin: 8px;"> Transactions </p>

        <div class="col-md-3">
          <input type="checkbox" name="view_transactions" id="view_transactions" <?php if($o1->view_transactions == 'Yes'){ ?> checked <?php }  ?> value="Yes"/>
          <label for='view_transactions'> View Transactions </label>
        </div>

      </div>
      <div class="row col-md-12 " >
        <p style="width: 100%; margin: 8px;">Settlements</p>
        <div class="col-md-3">
          <!-- <label>Gateway transaction fees</label> -->
          <input type="checkbox" name="add_settlement" id="add_settlement" <?php if($o1->add_settlement == 'Yes'){ ?> checked <?php } ?> value="Yes" />
          <label for="add_settlement"> Add New</label>
        </div>
        <div class="col-md-3">
         <input type="checkbox" name="pending_settlement" id="pending_settlement" value="Yes" <?php if($o1->pending_settlement == 'Yes'){ ?> checked <?php } ?>/>
         <label for="pending_settlement"> Pending </label>
       </div>
       <div class="col-md-3">
         <input type="checkbox" name="approve_settlememt" id="approve_settlememt" <?php if($o1->approve_settlememt == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
         <label for='approve_settlememt'> Approve </label>
       </div>
       <div class="col-md-3">
         <input type="checkbox" name="reject_settlememt" id="reject_settlememt" value="Yes" <?php if($o1->reject_settlememt == 'Yes'){ ?> checked <?php } ?>/>
         <label for='reject_settlememt'> Reject </label>
       </div>
     </div>
     <div class="row col-md-12 " >
      <p style="width: 100%; margin: 8px;" >Disputes</p>

      <div class="col-md-3">
        <!-- <label>Gateway transaction fees</label> -->
        <input type="checkbox" name="add_dispute" id="add_dispute" value="Yes"  <?php if($o1->add_dispute == 'Yes'){ ?> checked <?php }  ?>/>
        <label for="add_dispute"> Add New</label>
      </div>
      <div class="col-md-3">
       <input type="checkbox" name="pending_dispute" id="pending_dispute" <?php if($o1->pending_dispute == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
       <label for="pending_dispute"> Pending </label>
     </div>
     <div class="col-md-3">
       <input type="checkbox" name="approve_dispute" id="approve_dispute" value="Yes" <?php if($o1->approve_dispute == 'Yes'){ ?> checked <?php } ?>/>
       <label for='approve_dispute'> Approve </label>
     </div>
     <div class="col-md-3">
       <input type="checkbox" name="reject_dispute" id="reject_dispute" <?php if($o1->reject_dispute == 'Yes'){ ?> checked <?php }  ?> value="Yes"/>
       <label for='reject_dispute'> Reject </label>
     </div>
   </div>
   <div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Chargeback</p>
   
      <!-- <label> PCI compliance Fee Type</label> -->
      <div class="col-md-3">
       <input type="checkbox" name="view_chargeback" id="view_chargeback" <?php if($o1->view_chargeback == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
       <label for='view_chargeback'> View </label>
     </div>
  

 </div>
 <div class="row col-md-12 " >
  <p style="width: 100%; margin: 8px;">Refunds</p>
  <div class="col-md-3">
    <!-- <label>Gateway transaction fees</label> -->
    <input type="checkbox" name="add_refund" id="add_refund" <?php if($o1->add_refund == 'Yes'){ ?> checked <?php } ?> value="Yes" />
    <label for="add_refund"> Add Refund </label>
  </div>
  <div class="col-md-3">
   <input type="checkbox" name="pending_refund" id="pending_refund" <?php if($o1->pending_refund == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
   <label for="pending_refund"> Pending </label>
 </div>
 <div class="col-md-3">
   <input type="checkbox" name="approve_refund" id="approve_refund" <?php if($o1->approve_refund == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
   <label for='approve_refund'> Approve </label>
 </div>
 <div class="col-md-3">
  <input type="checkbox" name="reject_refund" id="reject_refund" <?php if($o1->reject_refund == 'Yes'){ ?> checked <?php } ?> value="Yes"/>
  <label for='reject_refund'> Reject </label>
</div>
</div>
</div>
<hr/>
<div class="row top_margin_10">
  <div class="col-md-12">
    <input type="hidden" name="permission_id" id="permission_id" value="<?= $o1->permission_id; ?>" />
    <input type="hidden" name="updte" id="updte" value="1" />
    <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
    <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

  </div>
</div>
</form>
</div>
</div>




<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">All Permissions </h6>
  </div>

  <div class="card-body">
    <div class="row">
      <div class="col-md-12 ">
        <div id="tabled_data" style="overflow-x: scroll;"> 
          <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
            <thead style="color:#fff;background-color:#6162d8;">
              <tr>
                <th>Sr.No</th>
                <!-- <th>User Name</th> -->
                <th>Permission Name</th>
                <th>Merchants Create</th>
                <th>Merchants Edit</th>
                <th>Merchants Delete</th>
                <th>Affilate Create </th>
                <th>Affilate Edit</th>
                <th>Affilate Delete</th>
                <th>View Transactions </th>
                                <!-- <th>Transaction Edit</th>
                                  <th>Transaction Delete</th> -->
                                  <th>Settlements Add New</th>
                                  <th>Settlements Pending</th>
                                  <th>Settlements Approve </th>
                                  <th>Settlements Reject </th>
                                  <th>Add Dispute</th>
                                  <th>Pending Dispute</th>
                                  <th>Approve Dispute </th>
                                  <th>Reject Dispute </th>


                                  <th>View Chargeback</th>
                                  <th>Add Refund </th>
                                  <th>Pending Refund </th>
                                  <th>Approve Refund </th>
                                  <th>Reject Refund</th>


                                  <th>Status</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php for ($i = 0; $i < $rows; $i++) { ?>
                                  <tr>
                                    <td><?= ($i + 1) ?></td>
                                    <!-- <td> <?= get_user_fund_name($res[$i]['user_id']) ?> </td> -->
                                    <td><?=$res[$i]['permission_name']?></td>
                                    <td><?=$res[$i]['create_merchants']?></td>
                                    <td><?=$res[$i]['edit_merchants']?></td>
                                    <td> <?= $res[$i]['delete_merchants'] ?> </td>
                                    <td> <?= $res[$i]['create_affiliate'] ?> </td>
                                    <td><?= $res[$i]['edit_affiliate'] ?></td>
                                    <td><?= $res[$i]['delete_affiliate'] ?></td>
                                    <td><?= $res[$i]['view_transactions'] ?></td>
                                    <td><?= $res[$i]['add_settlement'] ?></td>
                                    <td><?= $res[$i]['pending_settlement'] ?></td>
                                    <td><?= $res[$i]['approve_settlememt'] ?></td>
                                    <td><?= $res[$i]['reject_settlememt'] ?></td>
                                    <td><?= $res[$i]['add_dispute'] ?></td>
                                    <td><?= $res[$i]['pending_dispute'] ?></td>
                                    <td><?= $res[$i]['approve_dispute'] ?></td>
                                    <td><?= $res[$i]['reject_dispute'] ?></td>
                                    <td><?= $res[$i]['view_chargeback'] ?></td>
                                    <td><?= $res[$i]['add_refund'] ?></td>
                                    <td><?= $res[$i]['pending_refund'] ?></td>
                                    <td><?= $res[$i]['approve_refund'] ?></td>
                                    <td><?= $res[$i]['reject_refund'] ?></td>
                                    <td><?= status($res[$i]['is_active'])?>  </td>
                                    <td><a class="fa_edit" href="permissions.php?aid=<?= $res[$i]['permission_id']?>"><i class="fa fa-edit" title="Edit"></i></a></td>

                                  </tr>
                                <?php } ?>

                              </tbody>
                            </table>
                          </div>

                        </div>
                      </div>
                    </div>
                  </div>




                </div>
                <div  id="view_image"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog modal-lg">

                    <div class="modal-content">

                      <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel2">Photo</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                        </button>

                      </div>
                      <div class="modal-body" id="div_image">

                      </div>

                    </div>


                  </div>
                </div>