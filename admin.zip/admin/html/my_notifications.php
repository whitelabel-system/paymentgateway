<?php for ($i = 0; $i < $row_notifications; $i++) {?>
    <?php if ($res_notifications[$i]['notification_type']=="chargeback") {
                            $page ="chargeback.php";
                        }elseif ($res_notifications[$i]['notification_type']=="transaction") {
                            $page  ="ledger.php";
                        }elseif ($res_notifications[$i]['notification_type']=="dispute") {
                            $page  ="disputes.php";
                        }elseif ($res_notifications[$i]['notification_type']=="ticket") {
                           $page  ="all_tickets.php";
                        }elseif ($res_notifications[$i]['notification_type']=="refund") {
                           $page  ="refund_list.php";
                        }else{
                            $page ="#";
                        } ?>
    <a class="dropdown-item d-flex align-items-center" href="<?=$page?>">
        <div>
            <div class="small text-gray-500"><?=format_date_without_br($res_notifications[$i]['notification_date']);?></div>
            <?php if ($res_notifications[$i]['is_read'] == "No") {?>
                <span class="font-weight-bold"><?=$res_notifications[$i]['notification'];?></span>
            <?php } else {?>
                <?=$res_notifications[$i]['notification'];?>
            <?php }?>
        </div>
    </a>
<?php }?>
<a class="dropdown-item text-center small text-gray-500" href="#" onclick="clear_notifications()">Clear All Alerts</a>