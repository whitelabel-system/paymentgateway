<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php if ($o1->ticket_id > 0) { ?> Edit <?php } else { ?> Add <?php } ?> Ticket Details</h6>
        </div>
        <div class="card-body">
            <form name="ticket" id="ticket" method="post" action="save_ticket.php?aid=<?= $o1->ticket_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
                <div class="row">
                    <div class="col-md-6">
                        <label>Select Merchant/Affiliate</label>
                        <select name="user_id" id="user_id" class="select2_single form-control" >
                        <!-- <input type="text" class="form-control" required name="user_id" id="user_id"/> -->
                        <?= user_list_dropdown($user_id)?>
                        </select>
                    </div>
                </div> <br/>
                <div class="row">
                    <div class="col-md-6">
                        <label>Assign to</label>
                        <select name="assign_to" id="assign_to" class="select2_single form-control" >
                        <!-- <input type="text" class="form-control" required name="user_id" id="user_id"/> -->
                        <?= staff_list_dropdown($o1->assign_to)?>
                        </select>
                    </div>
                </div> <br/> 
                <div class="row">
                    <div class="col-md-6">
                        <label>Subject</label>
                        <input type="text" class="form-control" required name="subject" id="subject" value="<?= ucfirst($o1->subject); ?>"/>
                    </div>
                </div> <br/>
                 <div class="row">
                    <div class="col-md-6">
                        <label>Priority</label>
                        <select name="priority" id="priority" required class="form-control">
                            <option value="">Select Priority</option>
                            <option value="Low">Low</option>
                            <option value="Normal">Normal</option>
                            <option value="High">High</option>
                        </select>
                    </div>
                </div> <br/>
                <div class="row">
                    <div class="col-md-6">
                        <label>Department</label>
                        <select name="department" id="department" required class="form-control">
                            <option value="">Select Department</option>
                            <option value="Finance">Finance</option>
                            <option value="Compliance">Compliance</option>
                            <option value="Documents Related">Documents Related</option>
                            <option value="Chargeback Related">Chargeback Related</option>
                            <option value="Transactions Related">Transactions Related</option>
                            <option value="Settlement Related">Settlement Related</option>
                            <option value="Despute Related">Despute Related</option>
                            <option value="Affilliated Related">Affilliated Related</option>
                            <option value="Tech Support">Tech Support</option>
                            <option value="Account Activation">Account Activation</option>
                            <option value="Request Account Change">Request Account Change</option>
                        </select>
                    </div>
                </div> <br/>
                <div class="row">
                    <div class="col-md-6">
                        <label>Message</label>
                        <textarea class="form-control"  id="text_message" name ="text_message" rows="8"><?= ucfirst($o1->message); ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div id="att" >
                    <div class="col-md-6" style="max-width: 100%" >
                        <label>Attachment</label>
                       <input type="file" name="attachment[]" id="attachment" class="form-control" >
                    </div>
                    </div>
                    <div class="col-md-3">
                        <label>&nbsp;</label>
                       <input type="button"  id="add_more"  value="Add More" class="btn btn-secondary form-control " >
                    </div>
                </div>
                <div class="row" id="exta_att" >
                    
                </div>
                <hr/>
                <div class="row top_margin_10">
                    <div class="col-md-12">
                        <input type="hidden" name="ticket_id" id="ticket_id" value="<?= $o1->ticket_id; ?>" />
			<input type="hidden" name="dispute_id" id="dispute_id" value="<?=$dispute_id?>" />
                       <input type="hidden" name="wallet_id" id="wallet_id" value="<?=$wallet_id?>" />
			<input type="hidden" name="withdrawal_request_id" id="withdrawal_request_id" value="<?=$withdrawal_request_id?>" />
                        <input type="hidden" name="updte" id="updte" value="1" />
                        <input type="hidden" name="message" id="message" >
                        <input type="hidden" name="ticket_type" id="ticket_type" value="Enquiry">
                        <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
                        <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid