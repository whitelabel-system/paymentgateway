 <!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->
 
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <!-- <h6 class="m-0 font-weight-bold text-primary">Choose the merchant's primary credit card processor from the list below:</h6> -->
   <h6 class="m-0 font-weight-bold text-primary">Acquirers list:</h6>

    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
          <tbody>
            <?php for ($i = 0; $i < $rows; $i++) {?>
            <tr >
              <td><?=$i + 1;?></td>
              <td>
                <?=$res[$i]['processor_name'];?>
              </td>
            <td>
            	 <label class="switch">
        <input type="checkbox" name="status_<?=$i?>" id="status_<?=$i?>"
        <?php for ($j=0; $j <$row_card ; $j++) { ?>
<?php  if($res_card[$j]['status']=='Yes' && $res[$i]['credit_card_processor_id']==$res_card[$j]['credit_card_processor_id'] ){?>
        
             checked="checked";
       <?php } ?>  
<?php } ?>
          onclick="save_user_card(<?=$user_id?>,<?=$i?> ,<?= $res[$i]['credit_card_processor_id']?>)"  value="Yes">
        <span class="slider round span_margin">Yes</span>
        </label>
            </td>
            </tr>
            <?php }?>
          </tbody>
        </table>
      </div>
      <div class="row top_margin_10" >
                <div class="col-md-4">
                <input type="hidden" id="updte" name="updte" value="1">
                      <a type="button" name="save" id="save" value="Back" class="btn btn-primary" href="add_merchant.php?aid=<?=$user_id?>" >Back</a>
                     <a type="button" name="save" id="save" value="Next" class="btn btn-success" style="width: auto;" href="configure_processor.php?aid=<?=$user_id?>" >Next</a>
                    
                <!-- <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button> -->
            </div>
            </div>

    </div>
  </div>
</div>
<!-- /.container-fluid -->