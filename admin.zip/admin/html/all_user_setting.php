<div class="container-fluid">
   
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">All User Setting</h6>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 ">
                            <div id="tabled_data" style="overflow-x: scroll;"> 
                                <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0" cellpadding="10">
                                    <thead style="color:#fff;background-color:#6162d8;" >
                                        <tr>
                                            <th>Sr.no</th>
                                            <!-- <th>User Name</th> -->
                                            <th>Pricing Name</th>
                                            <th>Fee Type</th>

                                            <th>Gateway transaction fee</th>
                                            <th>Monthly maintenance fee</th>
                                            <th>Annual maintenance fee</th>
                                            <th>MID setup fee</th>
                                            <th>Virtual terminal</th>
                                            <th>PCI compliance</th>
                                            <th>Refund fee</th>
                                            <th>Chargeback fee</th>
                                            <th>Rolling Reserve</th>
                                            <th>Discount Fee</th>
                                            <th>Wire Transfer</th>
                                            <th>Fee AVS</th>
                                            <th>Fraud Scrub Fee</th>
                                            <th>Call Verification Fee</th>
                                            <th>Integration Fee</th>
                                            <th>Maximun Amount</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody style="text-align: start;">
                                        <?php for ($i = 0; $i < $rows; $i++) { ?>
                                            <tr>
                                                <td><?= ($i + 1) ?></td>
                                                <!-- <td> <?= get_user_fund_name($res[$i]['user_id']) ?> </td> -->
                                                <td><?=$res[$i]['pricing_name']?></td>
                                                <td><?=$res[$i]['fee_type']?></td>
                                                <td><?=$res[$i]['gateway_transaction_fees']?></td>
                                                <td> <?= $res[$i]['monthly_maintaince_fees'] ?> </td>
                                                <td> <?= $res[$i]['annual_maintaince_fees'] ?> </td>
                                                <td><?= $res[$i]['mid_setup_fees'] ?></td>
                                                <td><?= $res[$i]['virtual_terminal'] ?></td>
                                                <td><?= $res[$i]['pci_compliance'] ?></td>
                                                <td><?= $res[$i]['refund_fee'] ?></td>
                                                <td><?= $res[$i]['charge_back_fee'] ?></td>
                                                <td><?= $res[$i]['rolling_reserve'] ?></td>
                                                <td><?= $res[$i]['discount_fees'] ?></td>
                                                <td><?= $res[$i]['wire_transfer'] ?></td>
                                                 <td><?= $res[$i]['avs_fees'] ?></td>
                                                <td><?= $res[$i]['fraud_fees'] ?></td>
                                                <td><?= $res[$i]['call_verification_fee'] ?></td>
                                                <td><?= $res[$i]['integration_fee'] ?></td>
                                                <td><?= $res[$i]['other'] ?></td>
                                                <td><?= status($res[$i]['is_active'])?>  </td>
                                                <td><a class="fa_edit" href="user_setting.php?aid=<?= $res[$i]['user_setting_id']?>"><i class="fa fa-edit" title="Edit"></i></a></td>

                                            </tr>
                                        <?php } ?>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div  id="view_image"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg">

                <div class="modal-content">

                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel2">Photo</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <div class="modal-body" id="div_image">

                    </div>

                </div>


            </div>
        </div>