<div class="container-fluid">

    <!--        <div class="col-md-6 text-right">
                <a class="btn btn-primary" href="add_users.php">Add New User</a>
            </div>-->

    <!-- DataTales Example -->
    <div class="row"></div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Approved Disputes</h6>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" cellpadding="10" id="dataTable" width="100%" cellspacing="0">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>Sr. No</th>
                                    <th>Transaction Type</th>
                                    <th>user Detail</th>
                                    <th>Transaction Number</th>
                                    <th> Amount</th>
                                    <th>Dispute Reason</th>
                                    <th>Dispute Resolution</th>
                                    <th>Disputed at</th>
                                    <th>Resolved at</th>
                                </tr>
                            </thead>
                        <tbody style="text-align: start;">
                            
                                <?php for ($i = 0; $i < $rows; $i++) { ?>
                                    <?php $wallet_detail = get_wallet_detail($res[$i]['wallet_id']);?>
                                    <tr>
                                        <td><?= ($i + 1) ?></td>
                                        <td><?=$wallet_detail[0]['transaction_type']?></td>

                                        <td> <?= get_user_fund_name($res[$i]['user_id']) ?> </td>
                                        <td> <?= $res[$i]['transaction_number'] ?> </td>
                                        <td> <?= $wallet_detail[0]['amount'] ?> </td>
                                        <td> <?= $res[$i]['dispute'] ?> </td>
                                        <td> <?= $res[$i]['dispute_resolution']?>  </td>
                                        <td> <?= format_date($res[$i]['dispute_date']) ?></td>
                                        <td> <?= format_date($res[$i]['resolution_date']) ?></td>
                                     </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

