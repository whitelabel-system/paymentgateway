
<div class="container-fluid">
  <!-- Page Heading -->
  <!-- <div class="row">
    <div class="col-md-6">
      <h1 class="h3 mb-2 text-gray-800">Users Applications</h1>
    </div>

  </div> -->
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">List of Document(s)</h6>
    </div>
    <div class="card-body">
            <!-- <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>User Name</th>
                            <th>KYC Document Type</th>
                            <th>KYC Document</th>
                            <th>Address Document Type</th>
                            <th>Address Document</th>
                            <th>Company Document Type</th>
                            <th>Company Document</th>
                            <th>Company Address Document Type</th>
                            <th>Company Address Document</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php for ($i = 0; $i < $rows; $i++) { ?>
                            <tr >
                                <td><?= $i + 1; ?></td>
                                <td><?= get_username_from_id($res[$i]['user_id']) ?></td>
                                <td>
                                    <?= $res[$i]['kyc_doc_type']; ?> 
                                </td>
                                <td>

                                </td>
                                <td>
                                    <?= $res[$i]['personal_address_doc_type']; ?> 
                                </td>
                                <td>

                                </td>
                                <td>
                                    <?= $res[$i]['company_doc_type']; ?> 
                                </td>
                                <td>
                                    <span class="cursor" onclick="show_document('<?=$res[$i]['company_doc'];?>')">View Document</span>
                                </td>
                                <td>
                                    <?= $res[$i]['company_address_doc_type']; ?> 
                                </td>
                                <td>

                                </td>
                                <td>
                                 <?=$res[$i]['status']?>
                             </td>
                             <td>
                                <?php if ($res[$i]['is_active'] == 0) { ?>
                                    <a href="verify_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-check" title="Mark it Verified"></i></a> |  <a href="delete_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-times" title="Delete It"></i></a>
                                <?php }else {?>
                                    <a href="delete_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-times" title="Delete It"></i></a>
                                    <a href="card_process.php?aid=<?=$res[$i]['user_id']?>"  class="btn btn-light" >Next</a>
                                <?php } ?>
                                <a href="add_ticket.php?uid=<?=$res[$i]['user_id']?>" class="btn btn-primary">Ticket</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
          </div> -->
           <div class="table-responsive">
                <table class="table " id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                          <th>#</th>
                            <th>User Name</th>
                            <th>KYC Document </th>
                            <th>Address Document</th>
                            <th>Company Document</th>
                            <th>Company Address Document</th>
                            <th>Domain Ownership</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php for ($i = 0; $i < $rows; $i++) { ?>
                            <tr >
                              <th><?= ($i+1) ?></th>
                                <td>   <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#user_detail<?=$i?>" style="margin: 10px"  ><?=get_username_from_id($res[$i]['user_id'])?></button>  <div id="user_detail<?=$i?>" class="collapse" style="margin-top:5px;" >
                  <p><?=get_user_type($res[$i]['user_id'])?><br><?=get_user_email($res[$i]['user_id'])?><br><?=get_user_mobile($res[$i]['user_id'])?> <br><?=get_user_country($res[$i]['user_id'])?><br> <?=get_user_company_name($res[$i]['user_id'])?><br><?=get_user_name_id($res[$i]['user_id'])?></p>
                </div> </td>
                                <td>
                                   <button  style="margin: 10px" type="button" class="btn btn-info" data-toggle="collapse" data-target="#kyc<?=$i?>">KYC Documents</button>             
               <div id="kyc<?=$i?>" class="collapse" style="margin-top:5px;">
                <ul style="list-style: none;padding-left: 9px;" >
                  <?php for ($j=1; $j<=5; $j++) { ?>
                    <li class="mt-1"> <div id="kyc_doc<?=$j?>" ><a  style="font-size: 15px;"  class="cursor" href="../img/<?=$res[$i]['kyc_file'.$j.''];?>" target="_blank"><u><?= $res[$i]['kyc_doc'.$j.'']; ?></u></a>
                     
                    </div>
                    </li>
                    <?php } ?>
                      <form id="kyc_form<?=$i?>" name="kyc_form" onsubmit="return false;">
                      <li class="mt-1">
                    <!-- <input type="text" name="kyc_note" id="kyc_note" class="form-control" placeholder="Note" > -->
                    <select name="kyc_note" id="kyc_note" class="form-control">
                     <option value="Passport">Passport</option>
                      <option  value="Driving Licence">Driving Licence</option>
                       <option value="Voter Card">Voter Card</option>
                        <option value="Additional Document">Additional Document</option>
                   </select>
                  </li>
                  <li class="mt-1">
                   <input type="file" name="other_kyc_doc" id="other_kyc_doc" class="form-control" style="font-size: 13px;">
                   
                 </li>   
                 <li class="mt-1">
                  <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
                   <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit" onClick="save_kYc(<?= $i ?>)">
                 </li>  
                 </form>
               </ul>

             </div>
                                </td>
                                <td>
 <button style="margin: 10px" type="button" class="btn btn-info" data-toggle="collapse" data-target="#address<?=$i?>">Address Documents</button>             
             <div id="address<?=$i?>" class="collapse" style="margin-top:5px;">
              <ul style="list-style: none;padding-left: 9px;" >

               <li class="mt-1">         <u>     <a  target="_blank" class="cursor" href="../img/<?=$res[$i]['address_file'];?>"><?= $res[$i]['address_doc']; ?></a>
 </u>  
               </li>
               <?php for ($k=1; $k <=3 ; $k++) {  ?>
                 <li class="mt-1">             <u>    <a style="font-size: 15px;"  target="_blank" class="cursor" href="../img/<?=$res[$i]['address_file'.$k.''];?>"><?= $res[$i]['address_doc'.$k.'']; ?></a>
                 </u>  

                 </li>
               <?php } ?>  
               <form name="address_form" id="address_form<?=$i?>" onsubmit="return false" >
               <li class="mt-1">
                 <!-- <input type="text" name="address_note" id="address_note" class="form-control" placeholder=" Note" > -->
                 <select name="address_note" id="address_note" class="form-control" style="font-size: 13px;" >
                     <option value="Bank Statement">Bank Statement</option>
                      <option  value="Utillity Bill">Utillity Bill</option>
                       <option value="Insurance">Insurance</option>
                        <option value="Additional Document">Additional Document</option>
                   </select>
               </li> 
               <li class="mt-1">
                 <input type="file" name="other_address_doc" id="other_address_doc" class="form-control" style="font-size: 13px;" >
               </li>  
               <li class="mt-1">
              <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
                 <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit" onClick="save_address(<?= $i ?>)">
               </li>    
               </form>
             </ul>

           </div>
                                </td>
                                <td>
                                     <button style="margin: 10px"  type="button" class="btn btn-info" data-toggle="collapse" data-target="#company<?=$i?>">Company Documents</button>             
           <div id="company<?=$i?>" class="collapse" style="margin-top:5px;" style="margin-top:5px;">
             <ul style="list-style: none;padding-left: 9px;" >
               <li class="mt-1">              <u>   <a  target="_blank" style="font-size: 15px;"   class="cursor" href="../img/<?=$res[$i]['company_file'];?>"><?= $res[$i]['company_doc']; ?></a></u>
               
               </li>
               <?php for ($m=0; $m <=5 ; $m++) { ?>
                <li>              <u>   <a style="font-size: 15px;" target="_blank"   class="cursor" href="<?=$res[$i]['company_file'.$m.''];?>"><?= $res[$i]['company_doc'.$m.'']; ?></a></u>
                  
                </li>
              <?php } ?>   
              <form id="company_form<?=$i?>" name="company_form"  onsubmit="return false;">
              <li class="mt-1">
               <!-- <input type="text" name="company_note" id="company_note" class="form-control"  placeholder="Company Note" > -->
 <select name="company_note" id="company_note" class="form-control" style="font-size: 13px;" >
                     <option value="Incorporation">Incorporation</option>
                      <option  value="MOA">MOA</option>
                       <option value="AOA">AOA</option>
                       <option value="PAN">PAN</option>
                         <option value="GST">GST</option>
                           
                        <option value="Any licenses">Any licenses</option></select>
             </li>
             <li class="mt-1">
               <input type="file" name="other_company_doc" id="other_company_doc" class="form-control" style="font-size: 13px;" >
             </li> 
             <li class="mt-1">
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
               <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit" onClick="save_Company(<?= $i ?>)">
             </li> 
             </form>
           </ul>


         </div>
                                </td>
                                <td>
 <button style="margin: 10px"  type="button" class="btn btn-info" data-toggle="collapse" data-target="#company_address<?=$i?>">Company Address Documents</button>             
         <div id="company_address<?=$i?>" class="collapse" style="margin-top:5px;">
          <ul style="list-style: none;padding-left: 9px;" >
           <li > <u><a class="cursor" style="font-size: 15px;" target="_blank"   href="../img/<?=$res[$i]['company_address_file'];?>"><?= $res[$i]['company_address_doc']; ?> </u></a>
  
           </li>
           <?php for ($n=0; $n <=5 ; $n++) { ?>
            <li class="mt-1"> <u><a style="font-size: 15px;"  target="_blank" class="cursor" href="../img/<?=$res[$i]['company_address_file'.$n.''];?>"><?= $res[$i]['company_address_doc'.$n.'']; ?></a></u>

            </li>
          <?php } ?>   
          <form name="company_address_form" id="company_address_form<?=$i?>" onsubmit="return false;">
          <li class="mt-1">
           <!-- <input type="text" name="company_address_note" id="company_address_note" class="form-control"  placeholder="Company Address Note" > -->
<select name="company_address_note" id="company_address_note" class="form-control" style="font-size: 13px;" >
                     <option value="Bank Statement">Bank Statement</option>
                      <option  value="Cancel Check">Cancel Check</option>
                       <option value="Sample Invoice">Sample Invoice</option>
                       <option value="Rental Agreement">Rental Agreement</option>
                         <option value="Utillity Bill">Utillity Bill</option>
                           <option value="Additional Document">Additional Document</option>
                        </select>
         </li>
         <li class="mt-1">
           <input type="file" name="other_company_adress_doc" id="other_company_adress_doc" class="form-control" style="font-size: 13px;" >
         </li> 
         <li class="mt-1">
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
           <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit" onclick="save_CompanyAddress(<?= $i ?>)">
         </li>
         </form>  
       </ul>

     </div>
                                </td>
                                <td>
                                     <button style="margin: 10px"  type="button" class="btn btn-info" data-toggle="collapse" data-target="#domain<?=$i?>">Domain Ownership</button>             
     <div id="domain<?=$i?>" class="collapse" style="margin-top:5px;">
       <ul style="list-style: none;padding-left: 9px;" >
         <li>      <u>    <a style="font-size: 15px;" target="_blank" class="cursor" href="../img/<?=$res[$i]['domain_doc'];?>"><?= $res[$i]['domain_type']; ?></a> </u>
   
         </li> 
         <li class="mt-1">        <u>   <a style="font-size: 15px;"  target="_blank" class="cursor" href="../img/<?=$res[$i]['processing_statement'];?>"><?= $res[$i]['processing_statement_doc']; ?></a> </u>
              
          </li> 
         <form onsubmit="return false;" name="domain_form" id="domain_form<?=$i?>">  
         <li class="mt-1">      
          <!-- <input type="text" name="domain_note" id="domain_note" placeholder="Domain Note" class="form-control" > -->
    <select name="domain_note" id="domain_note" class="form-control" style="font-size: 13px;" >
                     <option value="Domain Ownership">Domain Ownership</option>
                      <option  value="Processing statement">Processing statement</option>
                       
                   </select>
        </li>   
         <li class="mt-1">
           <input type="file" name="other_doamin_doc" id="other_doamin_doc" class="form-control" style="font-size: 13px;" >
     
         </li> 
         <li class="mt-1">
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
           <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit" onclick="save_domain(<?= $i ?>)">
         </li>  
         </form>
       </ul>

     </div>
                                </td>
                                <td>
                                   <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#action<?=$i?>" <?php if ($res[$i]['status']=="Approved") {?> style="background-color: green;border: green;" <?php }elseif ($res[$i]['status']=="Pending") {?> style="background-color: #FFEB3B;border: #FFC107;"  <?php }elseif ($res[$i]['status']=="Rejected") {?> style="background-color:#ff3b3b;
    border:#ff3b3b" <?php } ?> >Action</button>             
     <div id="action<?=$i?>" class="collapse" style="margin-top:5px;">
      <ul style="list-style: none;padding-left: 9px;" >
       <li>   
         <?=$res[$i]['status']?>
       </li>   
       <li>
         <?php if ($res[$i]['is_active'] == 0) { ?>
          <a href="verify_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-check" title="Mark it Verified"></i></a> |  <a href="delete_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-times" title="Delete It"></i></a>
        <?php }else {?>
          <a href="delete_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-times" title="Delete It"></i></a><br>
          <a href="card_process.php?aid=<?=$res[$i]['user_id']?>"  class="btn btn-light" >Next</a>
        <?php } ?>        
      </li>
      <li>
        <a href="add_ticket.php?uid=<?=$res[$i]['user_id']?>" class="btn btn-primary">Ticket</a>         
      </li>
      <li>
        <a href="remove_kyc_document.php?aid=<?=$res[$i]['kyc_id']?>" class="btn btn-secondary">Delete</a>         
      </li>
    </ul>
    <br>


  </div>
                                </td>
                               
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
          </div> 
           <!-- <div class="row col-md-12 " >
            <?php for ($i = 0; $i < $rows; $i++) { ?>
              <div class="row top_margin_10 " >
                <div class="col-md" style="max-width:15%;min-width:15%;" >
                 <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#user_detail<?=$i?>" style="max-width: 86%;min-width: 86%;"  ><?=get_username_from_id($res[$i]['user_id'])?></button>             
                 <div id="user_detail<?=$i?>" class="collapse" style="margin-top:5px;" >
                  <p><?=get_user_type($res[$i]['user_id'])?><br><?=get_user_email($res[$i]['user_id'])?><br><?=get_user_mobile($res[$i]['user_id'])?> <br><?=get_user_country($res[$i]['user_id'])?><br> <?=get_user_company_name($res[$i]['user_id'])?><br><?=get_user_name_id($res[$i]['user_id'])?></p>
                </div>
              </div>
              <div class="col-md" style="max-width:15%;min-width:15%;">
               <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#kyc<?=$i?>">KYC Documents</button>             
               <div id="kyc<?=$i?>" class="collapse" style="margin-top:5px;">
                <ul style="list-style: none;padding-left: 9px;" >
                  <?php for ($j=1; $j<=5; $j++) { ?>
                    <li> <div id="kyc_doc<?=$j?>" ><span class="cursor" onclick="show_document('<?=$res[$i]['kyc_file'.$j.''];?>')"><?= $res[$i]['kyc_doc'.$j.'']; ?></span>
                      <?php if ($res[$i]['kyc_doc'.$j.'']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('kyc_doc', '<?=$j?>','<?=$res[$i]['kyc_doc'.$j.''];?>')" ></i></span>
                    <?php } ?>
                    </div>
                    </li>
                    <?php } ?>
                      <form id="kyc_form<?=$i?>" name="kyc_form" onsubmit="return false;">
                      <li>
                    <input type="text" name="kyc_note" id="kyc_note" class="form-control" placeholder="Note" >
                  </li>
                  <li>
                   <input type="file" name="other_kyc_doc" id="other_kyc_doc" class="form-control">
                 </li>   
                 <li>
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
                   <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit">
                 </li>  
                 </form>
               </ul>

             </div>
           </div>
           <div class="col-md" style="max-width:15%;min-width:15%;">
             <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#address<?=$i?>">Address Documents</button>             
             <div id="address<?=$i?>" class="collapse" style="margin-top:5px;">
              <ul style="list-style: none;padding-left: 9px;" >

               <li>              <span class="cursor" onclick="show_document('<?=$res[$i]['address_file'];?>')"><?= $res[$i]['address_doc']; ?></span>
<?php if ($res[$i]['address_file']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['address_file'];?>')" ></i></span>
                    <?php } ?>
               </li>
               <?php for ($k=1; $k <=3 ; $k++) {  ?>
                 <li>              <span class="cursor" onclick="show_document('<?=$res[$i]['address_file'.$k.''];?>')"><?= $res[$i]['address_doc'.$k.'']; ?></span>
                  <?php if ($res[$i]['address_file'.$k.'']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['address_file'.$k.''];?>')" ></i></span>
                    <?php } ?>

                 </li>
               <?php } ?>  
               <form name="address_form" id="address_form" onsubmit="return false" >
               <li>
                 <input type="text" name="address_note" id="address_note" class="form-control" placeholder=" Note" >
               </li> 
               <li>
                 <input type="file" name="other_address_doc" id="other_address_doc" class="form-control">
               </li>  
               <li>
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
                 <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit">
               </li>    
               </form>
             </ul>

           </div>
         </div>
         <div class="col-md"style="max-width:15%;min-width:15%;" >
           <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#company<?=$i?>">Company Documents</button>             
           <div id="company<?=$i?>" class="collapse" style="margin-top:5px;" style="margin-top:5px;">
             <ul style="list-style: none;padding-left: 9px;" >
               <li>                 <span class="cursor" onclick="show_document('<?=$res[$i]['company_file'];?>')"><?= $res[$i]['company_doc']; ?></span>
                <?php if ($res[$i]['company_file']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['company_file'];?>')" ></i></span>
                    <?php } ?>
               </li>
               <?php for ($m=0; $m <=5 ; $m++) { ?>
                <li>                 <span class="cursor" onclick="show_document('<?=$res[$i]['company_file'.$m.''];?>')"><?= $res[$i]['company_doc'.$m.'']; ?></span>
                   <?php if ($res[$i]['company_file'.$m.'']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['company_file'.$m.''];?>')" ></i></span>
                    <?php } ?>
                </li>
              <?php } ?>   
              <form id="company_form" name="company_form"  onsubmit="return false;">
              <li>
               <input type="text" name="company_note" id="company_note" class="form-control"  placeholder="Company Note" >

             </li>
             <li>
               <input type="file" name="other_company_doc" id="other_company_doc" class="form-control">
             </li> 
             <li>
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
               <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit">
             </li> 
             </form>
           </ul>


         </div>
       </div>
       <div class="col-md"style="max-width:15%; min-width:15%;min-width:15%;" >
         <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#company_address<?=$i?>">Company Address Documents</button>             
         <div id="company_address<?=$i?>" class="collapse" style="margin-top:5px;">
          <ul style="list-style: none;padding-left: 9px;" >
           <li><span class="cursor" onclick="show_document('<?=$res[$i]['company_address_file'];?>')"><?= $res[$i]['company_address_doc']; ?></span>
   <?php if ($res[$i]['company_address_file']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['company_address_file'];?>')" ></i></span>
                    <?php } ?>
           </li>
           <?php for ($n=0; $n <=5 ; $n++) { ?>
            <li><span class="cursor" onclick="show_document('<?=$res[$i]['company_address_file'.$n.''];?>')"><?= $res[$i]['company_address_doc'.$n.'']; ?></span>
  <?php if ($res[$i]['company_address_file'.$n.'']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['company_address_file'.$n.''];?>')" ></i></span>
                    <?php } ?>
            </li>
          <?php } ?>   
          <form name="company_address_form" id="company_address_form" onsubmit="return false;">
          <li>
           <input type="text" name="company_address_note" id="company_address_note" class="form-control"  placeholder="Company Address Note" >

         </li>
         <li>
           <input type="file" name="other_company_adress_doc" id="other_company_adress_doc" class="form-control">
         </li> 
         <li>
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
           <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit">
         </li>
         </form>  
       </ul>

     </div>
   </div>
   <div class="col-md" style="max-width:15%;min-width:15%;">
     <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#domain<?=$i?>">Domain Ownership</button>             
     <div id="domain<?=$i?>" class="collapse" style="margin-top:5px;">
       <ul style="list-style: none;padding-left: 9px;" >
         <li>          <span class="cursor" onclick="show_document('<?=$res[$i]['domain_doc'];?>')"><?= $res[$i]['doamin_type']; ?></span>
     <?php if ($res[$i]['domain_doc']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['domain_doc'];?>')" ></i></span>
                    <?php } ?>
         </li> 
         <li>          <span class="cursor" onclick="show_document('<?=$res[$i]['processing_statement_doc'];?>')"><?= $res[$i]['processing_statement']; ?></span>
                <?php if ($res[$i]['processing_statement']!="") {?><span><i class="fa fa-trash del_fa" onclick="remove_document('<?=$res[$i]['processing_statement'];?>')" ></i></span>
                    <?php } ?>
          </li> 
         <form onsubmit="return false;" name="domain_form" id="domain_form">  
         <li>       <input type="text" name="domain_note" id="domain_note" placeholder="Domain Note" class="form-control" ></li>   
         <li>
           <input type="file" name="other_doamin_doc" id="other_doamin_doc" class="form-control">
         </li> 
         <li>
          <input type="hidden"  name="kyc_id" id="kyc_id" value="<?=$res[$i]['kyc_id']?>">
           <input type="submit" name="submit" id="submit" class="form-control btn-primary" value="Submit">
         </li>  
         </form>
       </ul>

     </div>
   </div>
   <div class="col-md"style="max-width:10%;min-width:10%;" >
     <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#action<?=$i?>" <?php if ($res[$i]['status']=="Approved") {?> style="background-color: green;border: green;" <?php }elseif ($res[$i]['status']=="Pending") {?> style="background-color: #FFEB3B;border: #FFC107;"  <?php }elseif ($res[$i]['status']=="Rejected") {?> style="background-color:#ff3b3b;
    border:#ff3b3b" <?php } ?> >Action</button>             
     <div id="action<?=$i?>" class="collapse" style="margin-top:5px;">
      <ul style="list-style: none;padding-left: 9px;" >
       <li>   
         <?=$res[$i]['status']?>
       </li>   
       <li>
         <?php if ($res[$i]['is_active'] == 0) { ?>
          <a href="verify_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-check" title="Mark it Verified"></i></a> |  <a href="delete_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-times" title="Delete It"></i></a>
        <?php }else {?>
          <a href="delete_kyc.php?aid=<?= $res[$i]['kyc_id']; ?>"><i class="fa fa-times" title="Delete It"></i></a><br>
          <a href="card_process.php?aid=<?=$res[$i]['user_id']?>"  class="btn btn-light" >Next</a>
        <?php } ?>        
      </li>
      <li>
        <a href="add_ticket.php?uid=<?=$res[$i]['user_id']?>" class="btn btn-primary">Ticket</a>         
      </li>
      <li>
        <a href="remove_kyc_document.php?aid=<?=$res[$i]['kyc_id']?>" class="btn btn-secondary">Delete</a>         
      </li>
    </ul>
    <br>


  </div>
</div>

</div>

<?php } ?>
</div>  -->
  <!-- <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">Simple collapsible</button>
  <div id="demo" class="collapse">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit,
    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
  </div> -->
</div>
</div>
</div>
<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog" aria-labelledby="defaultModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="defaultModalLabel">Document</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body" id="img_div">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- /.container-fluid