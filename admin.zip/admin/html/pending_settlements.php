<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->

    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <div class="col-md-12 text-left ">
                Pending 
            </div>
        </div>
        <div class="card-body">
            <div class="row" id="hide_div">
                <div class="col-md-12 ">
                    <table class="table table-bordered table-responsive" id="datatable-buttons" cellpadding="10" width="100%" cellspacing="0">
                        <thead style="color:#fff;background-color:#6162d8;">
                            <tr>
                                <th>Sr.no</th>
                                <th>User Detail</th>
                                <th>Bank Details</th>
                                <th>Balance</th>
                                <th>Remittance Request</th>
                                <th>Status</th>
                                <th>Created at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody style="text-align: start;"  >
			    <?php for ($i = 0; $i < $rows; $i++) { ?>
    			    <tr>
    				<td ><?= ($i + 1) ?></td>
    				<td> <?= get_user_fund_name($res[$i]['user_id']) ?> </td>
    				<td><?= get_user_bank_detail($res[$i]['user_id']) ?></td>
    				<td> <?= $res[$i]['amount_balance'] ?> </td>
    				<td> <?= $res[$i]['amount'] ?> </td>
    				<td><?= $res[$i]['status'] ?>  </td>
    				<td><?= format_date($res[$i]['created_at']) ?></td>
    				<td>
    				    <Select class="form-control" onchange="update_status(this.value,<?= $res[$i]['withdrawal_request_id'] ?>)" >
    					<option>Select Action</option>
    					<option value="Approve">Approve</option>
    					<option value="Reject">Reject</option>
    					<option value="Ticket">Ticket</option>
    				    </select> |
				    <?php if($res[$i]['ticket_status'] != ""){ ?>
				    <span class="btn btn-info btn-sm"> <?=$res[$i]['ticket_status'] ?></span>
				    <?php } ?>
    				   <!--  <i class="fa fa-check" aria-hidden="true"  title="Approve"  onclick="update_status('Approve',<?= $res[$i]['withdrawal_request_id'] ?>)" style=" cursor: pointer; border: 1px solid green;background: #008000a6;color: #fff; border-radius: 3px;" ></i>|<i class="fa fa-ban" aria-hidden="true" title="Reject" onclick="update_status('Reject',<?= $res[$i]['withdrawal_request_id'] ?>)" style="  border: 1px solid red;background: #ff000094;color: #fff; cursor: pointer;border-radius: 3px;" ></i> -->

    				</td>
    			    </tr>
			    <?php } ?>

                        </tbody>
                    </table>
                </div>
            </div>
	    <div class="row" style="display:none" id="processing">
    <div class="col-md-12 text-center">        
        <img src="../img/rings.svg" width="300" />
    </div>
</div>
        </div>
    </div>
</div>
<div  id="settlement_modal"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog ">

        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Pending Settlement</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body" id="dispute_details">
                <form name="settlement_response" id="settlement_response" method="post" onsubmit="return false;" >
                    <div class="row">
                        <div class="col-md-12">
                            <label>UTR Number</label>
                            <input type="text" name="utr_number" id="utr_number" class="form-control"  placeholder="UTR Number" >
                        </div>
                        <div class="col-md-12">
                            <label>Remark</label>
                            <input type="text" name="dispute_resolution" id="dispute_resolution" class="form-control" placeholder="Remarks (Optional)" >
                        </div>
                    </div>
                    <div class="row top_margin_10" >
			<div class="col-md-12" > 
			    <input type="hidden" id="status" name="status" >
			    <input type="hidden" id="updte" name="updte" value="1" >
			    <input type="hidden" id="withdrawal_request_id" name="withdrawal_request_id" >
			    <button type="submit" name="save_button" id="save_button" class="btn btn-primary"> Save </button>
			    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
			</div>
		    </div>
                </form>
            </div>

        </div>


    </div>
</div>