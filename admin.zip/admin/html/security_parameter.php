<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <form name="ra" id="ra" method="post" action="save_user_security.php?aid=<?= $o1->user_security_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
        <div class="row">
            <div class="col-md-12" >
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary"><?php if ($o1->user_security_id > 0) { ?> Edit <?php } else { ?> Add <?php } ?>  Security Parameters </h6>
                    </div>
                    <div class="card-body">

		  <div class="row" >

                            <div class="col-md-6 ">
 <label>Select Merchant/Affiliate</label>
                        <select name="user_id" id="user_id" class="select2_single form-control" >
                        <?= user_list_dropdown($user_id)?>
                        </select>
                            </div>
                        </div>
<br/>
                        <div class="row" id="ip_div">

                            <div class="col-md-6 ">

                                <label>IP Block</label>
                                <input type="text" class="form-control"   name="block_ip_address[]" id="block_ip_address" placeholder="IP Block" value="<?= $o1->block_ip_address ?>"    />
                            </div>
                        </div>
                        <div class="col-md-3 " style="float: right;    top: -25px;" >
                            <input type="button" class="form-control btn btn-primary "  value="Add More" onclick="add_more('ip')"  />
                        </div>
                        <div class="row" id="ip_add_div" >

                        </div>
<br/>
                        <div class="row" id="card_div" >

                            <div class="col-md-6">
                                <label>Card Block</label>
                                <input type="text" class="form-control" name="block_card[]" id="block_card" placeholder="Card Block" value="<?= $o1->block_card; ?>" />
                            </div>
                        </div>
                            <div class="col-md-3 " style="float: right;    top: -25px;" >
                                <input type="button" class="form-control btn btn-primary "  value="Add More" onclick="add_more('card')"  />
                            </div>
                            <div class="row" id="card_add_div" >

                            </div>
<br/>
                        <div class="row" id="country_div" >
                            <div class="col-md-6">
                                <label>Country Block</label>
                                <select name="block_country_id[]" id="block_country_id[]" class="form-control">
                                   <option value="">Select Country</option>
                                   <?=country_list($o1->block_country_id)?>
                               </select>
                           </div>
                           </div> 
                           <div class="col-md-3 " style="float: right;    top: -25px;" >
                                <input type="button" class="form-control btn btn-primary "  value="Add More" onclick="add_more('country')"  />
                            </div>
                            <div class="row" id="country_add_div" >

                            </div>
                       <br/>
                       <div class="row" id="email_div">

                        <div class="col-md-6">
                            <label>E-mails</label>
                            <input type="email" class="form-control" name="email[]" id="email" placeholder="E-mail" value="<?= $o1->email; ?>" />
                        </div>
                        </div>
                        <div class="col-md-3 " style="float: right;    top: -25px;" >
                                <input type="button" class="form-control btn btn-primary "  value="Add More" onclick="add_more('email')"  />
                            </div>
                            <div class="row" id="email_add_div" >

                            </div>
                    <br/>
                    <div class="row" id="digit_div"> 
                        <div class="col-md-6">
                            <label>Card Digits</label>
                            <input type="number" class="form-control" name="card_digit[]" id="card_digit" placeholder="Card Digits" value="<?= $o1->card_digit; ?>" />
                        </div>
                         </div>
                         <div class="col-md-3 " style="float: right;    top: -25px;" >
                                <input type="button" class="form-control btn btn-primary "  value="Add More" onclick="add_more('digit')"  />
                            </div>
                            <div class="row" id="digit_add_div" >

                            </div>
                   <br/>
                    <div class="row" id="domain_div" >
                        <div class="col-md-6">
                            <label>Domain</label>
                            <input type="text" class="form-control" name="domain[]" id="domain" placeholder="Domain" value="<?= $o1->domain; ?>" />
                        </div>
                        </div>
                        <div class="col-md-3 " style="float: right;    top: -25px;" >
                                <input type="button" class="form-control btn btn-primary "  value="Add More" onclick="add_more('domain')"  />
                            </div>
                            <div class="row" id="domain_add_div" >

                            </div>

                     <br/>
                    <div class="row">
                        <div class="col-md">
                            <label>Maximum Transaction Amount Per Day</label>
                            <input type="text" class="form-control" name="transaction_amount_limit" id="transaction_amount_limit" placeholder="Maximum Transaction Amount Per Day" value="<?= $o1->transaction_amount_limit; ?>" />
                        </div>
                        <div class="col-md">
                            <label>No. Of Transaction Per Day</label>
                            <input type="text" class="form-control" name="transaction_per_day" id="transaction_per_day" placeholder="Transaction Limits Per Day" value="<?= $o1->transaction_per_day; ?>" />
                        </div>


                    </div><br/>


                    <hr/>
                    <div class="row top_margin_10">
                        <div class="col-md-12">
                            <input type="hidden" name="user_security_id" id="user_security_id" value="<?= $o1->user_security_id; ?>" />
                            <input type="hidden" name="updte" id="updte" value="1" />

                            <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
                            <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</form>
</div>
<!-- /.container-fluid