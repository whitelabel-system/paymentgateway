<div class="container-fluid">

    <!--        <div class="col-md-6 text-right">
                <a class="btn btn-primary" href="add_users.php">Add New User</a>
            </div>-->

    <!-- DataTales Example -->
    <!--  <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Filters</h6>
        </div>
        <div class="card-body">
            
        </div>
    </div> -->
    <div class="row"></div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Transactions</h6>
        </div>

        <div class="card-body">
            <form name="search_txn" id="search_txn" method="post"  action="payment_list.php" onsubmit="return false;" >
                <div class="row">
                    <div class="col-md-3">
                        <label>User Name</label>
                        <select name="user_id" id="user_id" class="form-control select2_single ">
                            <option value="0">Select User </option>
                            <?=user_list_dropdown(0);?>
                        </select>
                    </div>
		     <div class="col-md-3">
                        <label>Transaction Number</label>
                        <input type="text" class="form-control" name="ref_number" id="ref_number" placeholder="Transaction Number" value=""  />
                    </div>                    
                    <div class="col-md-2">
                        <label>From</label>
                        <input type="date" class="form-control" name="from_date" id="from_date" placeholder="From Date" value="<?=format_date_without_time($dd);?>" />
                    </div>
                    <div class="col-md-2">
                        <label>To</label>
                        <input type="date" class="form-control" name="to_date" id="to_date" placeholder="To Date" value="<?=format_date_without_time($dd)?>"  />
                    </div>
               
                    <div class="col-md-2">
                        <label>&nbsp;</label>
                        <input type="submit" name="search_result" id="search_result" class="form-control btn btn-primary" value="Search Records" />
                    </div>

                </div>
            </form>
	</div> 
<!--    </div>
     <div class="card shadow mb-4">-->
	<div class="card-body p-4">
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" id="payment_list" width="100%" cellspacing="0">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>Sr.no</th>
                                    <th>Transaction Type</th>
                                    <th>User Detail</th>
                                    <th>Transaction Number</th>
                                    <th>Total Amount</th>
                                    <th>Payment Amount</th>
                                    <th>Created at</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                           
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<div  id="view_image"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Photo</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body" id="div_image">

            </div>

        </div>


    </div>
</div>