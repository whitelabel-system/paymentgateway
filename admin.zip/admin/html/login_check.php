<?php

session_start();
include "include.php";


if (isset($_POST['mobile']) && isset($_POST['password'])) {
    $password = cpassword($_POST['password']);

    $sql = "select * from users where user_type != 'Admin'  and (mobile ='" . $_POST['mobile'] . "' or email ='" . $_POST['mobile'] . "') and password='" . $password . "'";
    $res = getXbyY($sql);
    $row = count($res);
    if ($row == '1') {
        $o1->user_id=$res[0]['user_id'];
        $o1->activity_name="Login";
        $o1->activity_time = todaysDate();
        $o1->is_active='1';
        $o1->user_activity_id = $insertor->insert_object($o1, "user_activity");


        if ($res[0]['is_active'] == "1") {
            $_SESSION['user_id'] = $res[0]['user_id'];
            $result['error'] = '0';
            $result['error_msg'] = "Logged in Successfully";
        } else {
            $result['error'] = '1';
            $result['error_msg'] = "User blocked.";
        }
    } else {
        $result['error'] = '1';
        $result['error_msg'] = "Email/Password may be incorrect";
    }
} else {
    $result['error'] = '1';
    $result['error_msg'] = "Something Went Wrong";
}


echo json_encode($result);
?>