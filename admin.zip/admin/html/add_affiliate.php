<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <form name="ra" id="ra" method="post" action="save_users.php?aid=<?= $o1->user_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
        <div class="row">
        <div class="col-md-8" >
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php if ($o1->user_id > 0) { ?> Edit <?php } else { ?> Add <?php } ?> Affiliate Details</h6>
                </div>
                <div class="card-body">

                    <div class="row">

                        <div class="col-md">
                            <label>Name</label>
                            <input type="text" class="form-control"  required name="name" id="name" placeholder="Name" value="<?= ucfirst($o1->name); ?>"    />
                        </div>


                        <div class="col-md">
                            <label>Mobile</label>
                            <input type="tel" class="form-control" name="mobile" id="mobile" placeholder="Mobile" value="<?= $o1->mobile; ?>" required/>
                        </div>
                    </div> <br/>
                    <div class="row">

                        <div class="col-md">
                            <label>E-mail</label>
                            <input type="email" class="form-control" name="email" id="email" placeholder="E-mail" value="<?= $o1->email; ?>" required/>
                        </div>
                        <div class="col-md">
                            <label>Password</label>
                            <input type="text" class="form-control" name="password" id="password" placeholder="Password" value="<?= $o1->mobile; ?>" />
                        </div>
                         <div class="col-md">
                            <label>Address</label>
                            <input type="text" class="form-control" name="user_address" id="user_address" placeholder="User Address" value="<?= $o1->user_address; ?>" required/>
                        </div>
                    </div> <br/>
                    <div class="row">
                        <div class="col-md">
                            <label>Company Name</label>
                            <input type="text" class="form-control" name="company_name" id="company_name" placeholder="Company Name" value="<?= $o1->company_name; ?>" />
                        </div>
                        <div class="col-md">
                            <label>Company Type</label>
                            <select name="company_type" id="company_type" class="form-control" required>
                                <option value="Proprietor" <?php if ($o1->company_type == "Proprietor") { ?> selected="selected" <?php } ?>>Proprietor</option>
                                <option value="Individual" <?php if ($o1->company_type == "Individual") { ?> selected="selected" <?php } ?>>Individual</option>
                                <option value="Private Limited" <?php if ($o1->company_type == "Private Limited") { ?> selected="selected" <?php } ?>>Private Limited</option>
                                <option value="Partnership" <?php if ($o1->company_type == "Partnership") { ?> selected="selected" <?php } ?>>Partnership</option>
                                <option value="Other" <?php if ($o1->company_type == "Other") { ?> selected="selected" <?php } ?>>Other</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label>Country</label>
                            <select name="country_id" id="country_id" class="form-control">
                                <?=country_list($o1->country_id)?>
                            </select> 
                        </div>

                    </div><br/>
                    <div class="row" >
                        <div class="col-md-4">
                            <label>URL</label>
                            <input type="text" name="url" id="url" class="form-control" value="<?=$o1->url?>" placeholder="URL">
                        </div>
                        <div class="col-md-4">
                            <label>2F Authentication</label>
                            <select name="otp_enabled" id="otp_enabled" class="form-control" required>
                                <option value="Yes" <?php if ($o1->otp_enabled == "Yes") { ?> selected="selected" <?php } ?>>Yes</option>
                                <option value="No" <?php if ($o1->otp_enabled == "No") { ?> selected="selected" <?php } ?>>No</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label>Status</label>
                            <select name="is_active" id="is_active" class="form-control" required>
                                <option value="1" <?php if ($o1->is_active == 1) { ?> selected="selected" <?php } ?>>Active</option>
                                <option value="0" <?php if ($o1->is_active == 0) { ?> selected="selected" <?php } ?>>Blocked</option>
                            </select>
                        </div>
                          <div class="col-md-4">
                            <label>Minimum Withdrawal</label>
                            <input type="text" name="minimum_withdrawal_amount" id="minimum_withdrawal_amount" class="form-control" value="<?=$o1->minimum_withdrawal_amount?>" placeholder="Minimum Threshold" required>
                        </div>
                        <div class="col-md-4">
                            <label>Secure Amount</label>
                            <input type="text" name="secure_amount" id="secure_amount" placeholder="Secure Amount" class="form-control" value="<?=$o1->secure_amount?>" required>
                        </div>
                    </div>

                    <hr/>
                    <div class="row top_margin_10">
                        <div class="col-md-12">
                            <input type="hidden" name="user_id" id="user_id" value="<?= $o1->user_id; ?>" />
                            <input type="hidden" name="updte" id="updte" value="1" />
                            <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
                            <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-4" >
         <div class="col-md-12">
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Profile Image </h6>
          </div>
          <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                
                  <input type="file" name="profile_pic" id="profile_pic" class="form-control" />
              </div>
               <?php if ($o1->profile_pic !="") { ?> -
              <div class="col-md-12">
                <img src="<?= $o1->profile_pic; ?>"  width="70%"  />
            </div>
             <?php } ?> -


        </div>
       


      </div>
  </div>
</div>
</div>
</div>
</div>
</form>
</div>
<!-- /.container-fluid