<div class="container-fluid">
  
<!-- DataTales Example -->
<div class="row"></div>
<div class="card shadow mb-4">

        <div class="card-header py-3 row" style="margin-right:0px!important ; margin-left: 0px!important">
        <h6 class="m-0 col-md-2 font-weight-bold text-primary">All Users</h6>
         <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="add_users.php">Add New User</a>
    </div>

    </div>
    

    <div class="card-body">
        <div class="row">
            <div class="col-md-12 ">
                <div id="tabled_data"> 
                    <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0" cellpadding="10">
                        <thead style="color:#fff;background-color:#6162d8;">
                            <tr>
                                <th>Sr.no</th>
                                <th>Permission</th>
                                <th>Name</th>
                                <th>Plan</th>
                                <th>Email & Mobile</th>
                                <th>Amount</th>

                                <th>Created at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody style="text-align: start;">
                            <?php for ($i = 0; $i < $row; $i++) { ?>
                                <tr>
                                    <td ><?= ($i + 1) ?></td>
                                    <td><?= get_permission_name($res[$i]['permissions'])?> </td>
                                    <td><?= ucfirst($res[$i]['name']) ?> <br/>  <span style="color:green"> <?= $res[$i]['user_name'] ?></span> <br/> (<?= $res[$i]['company_type'] ?>)</td>
                                    <td><?= get_user_planName($res[$i]['plan_id']) ?></td>
                                    <td> <?= $res[$i]['email'] ?> <span>
                                        <?php if ($res[$i]['email_verified'] == "Yes") { ?>
                                            <i class=" fa fa-check   fa_verified"></i>
                                        <?php } ?>
                                        </span><br/><?= $res[$i]['mobile'] ?>
                                        <?php if ($res[$i]['mobile_verified'] == "Yes") { ?>
                                            <i class="fa fa-check  fa_verified"></i>
                                            <?php } ?>  </td>
                                            <td><?= $res[$i]['amount_balance'] ?></td>
                                            <td><?= format_date($res[$i]['created_at']) ?></td>
                                            <td><?= status($res[$i]['is_active']) ?><br/> &nbsp;  <a class="fa_edit" href="add_users.php?aid=<?= $res[$i]['user_id'] ?>">  <i class="fa fa-edit" title="Edit"></i></a>
                                                <a onclick="delete_user(<?=$res[$i]['user_id']?>)" href="#" title="Delete User"><i class="fa fa-trash fa-fw "></i></a>
                                            </td>
                                        </tr>
                                    <?php } ?>

                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <div  id="view_image"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">

            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel2">Photo</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                    </button>

                </div>
                <div class="modal-body" id="div_image">

                </div>

            </div>


        </div>
    </div>
    <div id="user_rights_status" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
             <h4 class="modal-title">Manage User Service</h4>
             <button type="button" class="close" data-dismiss="modal">&times;</button>

         </div>
         <form  id="update_status" method="POST" class="form-horizontal form-label-left input_mask" onsubmit="return false">

             <div class="modal-body">
               <div class="row" id="user_service_rights">


               </div>
           </div>
           <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary">Save</button>
            <input type="hidden" name="updte" id="updte" value="1" />

        </div>
    </form>

</div>

</div>
</div>
</div>