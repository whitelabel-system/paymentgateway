<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
  
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <div class="col-md-12 text-left ">
                Approved 
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <table class="table table-bordered table-responsive" cellpadding="10" id="datatable-buttons" width="100%" cellspacing="0">
                        <thead style="color:#fff;background-color:#6162d8;">
                            <tr>
                                <th>Sr.no</th>
                                <th>User Detail</th>
                                <th>Bank Details</th>
                                 <th>Balance</th>
                                <th>Remittance Request</th>
                                <th>Status</th>
                                <th>Approved at</th>
                               
                            </tr>
                        </thead>
                        <tbody style="text-align: start;">
                            <?php for ($i = 0; $i < $rows; $i++) { ?>
                                <tr>
                                    <td ><?= ($i + 1) ?></td>
                                    <td> <?= get_user_fund_name($res[$i]['user_id']) ?> </td>
                                    <td><?=get_user_bank_detail($res[$i]['user_id'])?></td>
                                    <td> <?= $res[$i]['total_amount'] ?> </td>
                                    <td> <?= $res[$i]['amount'] ?> </td>
                                    <td><?= $res[$i]['status']?>  </td>
                                    <td><?= format_date($res[$i]['updated_at']) ?></td>
                               
                                </tr>
                            <?php } ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>