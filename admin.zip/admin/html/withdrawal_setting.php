<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tax Setting</h6>
        </div>
        <div class="card-body">
            <form name="withdrawal_setting" id="withdrawal_setting" method="post" action="save_withdrawal_setting.php" enctype="multipart/form-data" onsubmit="return false" >
                <div class="row">
                    <div class="col-md-4">
                        <label>Select Country</label>
                        <select name="country_id" id="country_id" class="form-control" required>
                            <option value="">Select Country</option>
                            <?=country_list($o1->country_id)?>
                        </select>  
                    </div>
                    <div class="col-md-4">
                        <label>Surcharge Type</label>
                        <select name="commission_type" id="commission_type" class="select2_single form-control" value="<?=$o1->commission_type?>" >
                            <option value="0">Select Commission Type</option>
                            <option value="percentage" <?php if ($o1->commission_type=="percentage") {?> selected <?php } ?> >Percentage</option>
                            <option value="flat"  <?php if ($o1->commission_type=="flat") {?> selected <?php } ?> >Flat</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>Surcharge Value</label>
                        <input type="number" name="surcharge" id="surcharge" class="form-control" value="<?=$o1->surcharge?>" >
                    </div>
                     <div class="col-md-4">
                        <label>TDS</label>
                        <select name="tds" id="tds" class="form-control" value="<?=$o1->tds?>" >
                            <option value="Yes" <?php if ($o1->tds=="Yes") {?> selected <?php } ?> >Yes</option>
                            <option value="No" <?php if ($o1->tds=="No") {?> selected <?php } ?>>No</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>TDS Value</label>
                        <input type="number" name="tds_value" id="tds_value" class="form-control" placeholder="Value in Percentage" >
                    </div>
                    <div class="col-md-4">
                        <label>GST</label>
                        <select name="gst" id="gst" class="form-control" value="<?=$o1->gst?>" >
                            <option value="Yes" <?php if ($o1->gst=="Yes") {?> selected <?php } ?> >Yes</option>
                            <option value="No" <?php if ($o1->gst=="No") {?> selected <?php } ?>>No</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>GST Value</label>
                        <input type="number" name="gst_value" id="gst_value" class="form-control" placeholder="Value in Percentage" >
                      
                    </div>
                </div>
                
                </div>                   
                    
                     <br/>
                
              

                
                <hr/>
                <div class="row top_margin_10 mb-2 ml-2">
                    <div class="col-md-12">
                        <input type="hidden" name="updte" id="updte" value="1" />
                        <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
                        <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

                    </div>
                </div>
            </form>
        </div>
   
   
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Tax Setting</h6>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>Sr.no</th>
                                    <th>Country Name</th>
                                    <th>Surcharge Type</th>
                                    <th>Surcharge Value</th>
                                    <th>TDS</th>
                                    <th>GST</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for ($i = 0; $i < $row; $i++) { ?>
                                    <tr>
                                        <td><?= ($i + 1) ?></td>
                                        <td><?=$res[$i]['name'].'-'.$res[$i]['sortname']?></td>
                                        <td> <?= $res[$i]['commission_type'] ?> </td>
                                        <td> <?= $res[$i]['surcharge'] ?> </td>
                                         <td><?= $res[$i]['gst'] ?></td>
                                         <td><?= $res[$i]['tds']?> </td>                                     
                                         <td><a href="withdrawal_setting.php?aid=<?= $res[$i]['country_id']?>"><i class="fa fa-edit" ></i></a> </td>                                     
                                    </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div> </div>
<!-- /.container-fluid