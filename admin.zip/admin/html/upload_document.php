<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Add Documents </h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <form name="fa" id="fa" method="post" action="kyc.php" enctype="multipart/form-data" >
                       <div class="row">
                        <p style="width: 100%; margin-bottom: 0.5rem;"  >Personal KYC</p>

                        <div class="col-md-6">
                            <label>Passport</label>
                            <input type="hidden" name="kyc_doc1" id="kyc_doc1" value="Passport">
                            <input type="file" name="kyc_file1" id="kyc_file1" class="form-control"   />
                        </div>
                        <div class="col-md-6">
                            <label>Driving Licence</label>
                            <input type="hidden" name="kyc_doc2" id="kyc_doc2" value="Driving Licence">
                            <input type="file" name="kyc_file2" id="kyc_file2" class="form-control"   />
                        </div>
                        <div class="col-md-6">
                            <label>Voter Card</label>
                            <input type="hidden" name="kyc_doc3" id="kyc_doc3" value="Voter Card">
                            <input type="file" name="kyc_file3" id="kyc_file3" class="form-control"   />
                        </div>
                        <div class="col-md-6">
                            <label>TAX</label>
                            <input type="hidden" name="kyc_doc4" id="kyc_doc4" value="TAX">
                            <input type="file" name="kyc_file4" id="kyc_file4" class="form-control"   />
                        </div>
                        <div class="col-md-6">
                            <label>Additional Document</label>
                            <input type="hidden" name="kyc_doc5" id="kyc_doc5" value="Additional Document">
                            <input type="file" name="kyc_file5" id="kyc_file5" class="form-control"   />
                        </div>
                    </div>
                    <div class="row top_margin_10">
                        <p style="width: 100%; margin-bottom: 0.5rem;" >Personal Address Proof</p>

                        <div class="col-md-6">
                            <label>Bank Statement</label>
                            <input type="hidden" name="address_doc" value="Bank Statement">
                            <input type="file" name="address_file" id="address_file" class="form-control" value=""  />


                        </div>

                        <div class="col-md-6">
                            <label>Utillity Bill</label>
                            <input type="hidden" name="address_doc1" value="Utillity Bill" >
                            <input type="file" name="address_file1" id="address_file1" class="form-control"/>
                        </div>
                        <div class="col-md-6">
                            <label>Insurance</label>
                            <input type="hidden" name="address_doc2" value="Insurance" >
                            <input type="file" name="address_file2" id="address_file2" class="form-control"   />
                        </div>
                        <div class="col-md-6">
                            <label>Additional Document</label>
                            <input type="hidden" name="address_doc3" value="Addition Document" >
                            <input type="file" name="address_file3" id="address_file3" class="form-control"  />
                        </div>
                    </div>
                    <div class="row top_margin_10">
                        <p style="width: 100%; margin-bottom: 0.5rem;" >Company Proof</p>
                        <div class="col-md-6">
                            <label>Incorporation</label>
                            <input type="hidden" name="company_doc" id="company_doc" value="Incorporation">
                            <input type="file" name="company_file" id="company_file" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>MOA</label>
                            <input type="hidden" name="company_doc1" id="company_doc1" value="MOA">
                            <input type="file" name="company_file1" id="company_file1" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>AOA</label>
                            <input type="hidden" name="company_doc2" id="company_doc2" value="AOA">
                            <input type="file" name="company_file2" id="company_file2" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>PAN</label>
                            <input type="hidden" name="company_doc3" id="company_doc3" value="PAN">
                            <input type="file" name="company_file3" id="company_file3" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>GST</label>
                            <input type="hidden" name="company_doc4" id="company_doc4" value="GST">
                            <input type="file" name="company_file4" id="company_file4" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Any licenses</label>
                            <input type="hidden" name="company_doc5" id="company_doc5" value="Any licenses">
                            <input type="file" name="company_file5" id="company_file5" class="form-control" />
                        </div>
                    </div>
                    <div class="row top_margin_10">
                        <p style="width: 100%; margin-bottom: 0.5rem;" >Company Address Proof</p>

                        <div class="col-md-6">
                            <label>Bank Statement</label>
                            <input type="hidden" name="company_address_doc" id="company_address_doc" value="Bank Statement">
                            <input type="file" name="company_address_file" id="company_address_file" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Cancel Check</label>
                            <input type="hidden" name="company_address_doc1" id="company_address_doc1" value="Cancel Check">
                            <input type="file" name="company_address_file1" id="company_address_file1" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Sample Invoice</label>
                            <input type="hidden" name="company_address_doc2" id="company_address_doc2" value="Sample Invoice">
                            <input type="file" name="company_address_file2" id="company_address_file2" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Rental Agreement</label>
                            <input type="hidden" name="company_address_doc3" id="company_address_doc3" value="Rental Agreement">
                            <input type="file" name="company_address_file3" id="company_address_file3" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Utillity Bill</label>
                            <input type="hidden" name="company_address_doc4" id="company_address_doc4" value="Utillity Bill">
                            <input type="file" name="company_address_file4" id="company_address_file4" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label>Additional Document</label>
                            <input type="hidden" name="company_address_doc5" id="company_address_doc5" value="Additional Document">
                            <input type="file" name="company_address_file5" id="company_address_file5" class="form-control" />
                        </div>
                    </div>
                    <div class="row top_margin_10">
                        <p style="width: 100%; margin-bottom: 0.5rem;" >Doamin Ownership <br> <small style="color: red;" >Domain Purchase receipt or Dashboard screenshot</small> </p>
                        

                        <div class="col-md-6">
                            <label>Domain Ownership</label>
                            <input type="hidden" name="domain_type" id="domain_type" value="Domain Ownership">
                            <input type="file" name="domain_doc" id="domain_doc" class="form-control" />
                        </div>
                       
                    </div>
                    <div class="row top_margin_10">
                        <p style="width: 100%; margin-bottom: 0.5rem;" >Processing statement  <br>  <small style="color: red;" >If you have any current processing statement for 3-6 Months</small></p>
                        

                        <div class="col-md-6">
                            <label>Processing statement</label>
                            <input type="hidden" name="processing_statement" id="processing_statement" value="Processing statement">
                            <input type="file" name="processing_statement_doc" id="processing_statement_doc" class="form-control" />
                        </div>
                       
                    </div>
                    
                    <div class="row top_margin_10">
                        <div class="col-md-8">
                            <input type="hidden" name="kyc_updte" id="kyc_updte" value="1" />
                            <input type="hidden" name="user_id" id="user_id" value="<?=$user_id?>">
                            <input type="submit" name="save_kyc" id="save_kyc" value="Upload Document" class="btn btn-primary" />
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
</div>
<!-- /.container-fluid