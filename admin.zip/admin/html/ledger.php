<div class="container-fluid">


    <div class="row"></div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Ledger</h6>
        </div>

        <div class="card-body">
            <form name="search_txn" id="search_txn" method="post"  action="ledger_list.php" onsubmit="return false;" >
                <div class="row">
                    <div class="col-md-3">
                        <label>User Name</label>
                        <select name="user_id" id="user_id" class="form-control select2_single" required="">
                            <option value="0">Select User </option>
                            <?=user_list_dropdown(0);?>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label>From</label>
                        <input type="date" class="form-control" name="from_date" id="from_date" placeholder="From Date" value="<?=format_date_without_time($dd);?>" />
                    </div>
                    <div class="col-md-3">
                        <label>To</label>
                        <input type="date" class="form-control" name="to_date" id="to_date" placeholder="To Date" value="<?=format_date_without_time($dd)?>"  />
                    </div>
               
                    <div class="col-md-3">
                        <label>&nbsp;</label>
                        <input type="submit" name="search_result" id="search_result" class="form-control btn btn-primary" value="Search Records" />
                    </div>

                </div>
            </form>
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" id="ledger_list" width="100%" cellspacing="0" cellpadding="10">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>Transaction Date</th>
                                    <th>User Detail</th>
                                    <th>Transaction Detail</th>
                                    <th>Transaction Type</th>
                                    <th>User Opening Balance</th>
                                    <th>Amount</th>
                                    <th>User Closing Balance</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

