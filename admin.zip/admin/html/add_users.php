<!-- Begin Page Content -->  
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php if ($o1->user_id > 0) { ?> Edit <?php } else { ?> Add <?php } ?> User Details</h6>
        </div>
        <div class="card-body">
            <form name="ra" id="ra" method="post" action="save_users.php?aid=<?= $o1->user_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
                <div class="row">


                    <div class="col-md">
                        <label>Name</label>
                        <input type="text" class="form-control"  required name="name" id="name" placeholder="Name" value="<?= ucfirst($o1->name); ?>"    />
                    </div>
                    
                    
                    <div class="col-md">
                        <label>Mobile</label>
                        <input type="tel" class="form-control" name="mobile" id="mobile" placeholder="Mobile" value="<?= $o1->mobile; ?>" required/>
                    </div>
                    <div class="col-md">
                        <label>E-mail</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="E-mail" value="<?= $o1->email; ?>" required/>
                    </div>
                </div> <br/>
                <div class="row">

                    <div class="col-md">
                        <label>Password</label>
                        <input type="text" class="form-control" name="password" id="password" placeholder="Password" value="<?= $o1->password; ?>" />
                    </div>

                   <!--  <div class="col-md">
                        <label>Date of Birth</label>
                        <input type="date" class="form-control" name="dob" id="dob" placeholder="Date of Birth" value="<?= $o1->dob; ?>" required/>
                    </div> -->
                    <div class="col-md">
                        <label>Gender</label>
                        <select name="gender" id="gender" class="form-control">
                            <option value="Male" <?php if ($o1->gender == "Male") { ?> selected="selected" <?php } ?>>Male</option>
                            <option value="Female" <?php if ($o1->gender == "Female") { ?> selected="selected" <?php } ?>>Female</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                            <label>2F Authentication</label>
                            <select name="otp_enabled" id="otp_enabled" class="form-control" required>
                                <option value="Yes" <?php if ($o1->otp_enabled == "Yes") { ?> selected="selected" <?php } ?>>Yes</option>
                                <option value="No" <?php if ($o1->otp_enabled == "No") { ?> selected="selected" <?php } ?>>No</option>
                            </select>
                        </div>
                </div> <br/>
                <div class="row">
                <div class="col-md-4">
                            <label>Permissions</label>
                            <select name="permissions" id="permissions" class="form-control" required>
                                <option value="">Choose Permission </option>
                                <?php for ($i=0; $i <$row ; $i++) { ?>
                                    <option value="<?=$res[$i]['permission_id'] ?>" <?php if ($o1->permissions == $res[$i]['permission_id']) { ?> selected="selected" <?php } ?>><?=$res[$i]['permission_name'] ?></option>
                                <?php } ?>
                                
                            
                            </select>
                        </div> 
                   <div class="col-md-4">
                    <label>Status</label>
                    <select name="is_active" id="is_active" class="form-control" required>
                        <option value="1" <?php if ($o1->is_active == 1) { ?> selected="selected" <?php } ?>>Active</option>
                        <option value="0" <?php if ($o1->is_active == 0) { ?> selected="selected" <?php } ?>>Blocked</option>
                    </select>
                </div>
            </div>

            <hr/>
            <div class="row top_margin_10">
                <div class="col-md-12">
                    <input type="hidden" name="user_id" id="user_id" value="<?= $o1->user_id; ?>" />
                    <input type="hidden" name="updte" id="updte" value="1" />
                    <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button>
                    <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

                </div>
            </div>
        </form>
    </div>
</div>
</div>
<!-- /.container-fluid