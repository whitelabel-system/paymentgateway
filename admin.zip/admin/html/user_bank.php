<div class="container-fluid">
   


    <div class="card shadow mb-4 mt-3">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Bank Details</h6>
            <a href="add_bank.php?uid=<?=$user_id?>" style="float: right;" class="btn btn-primary"> Add Bank </a>
        </div>
            
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 ">
                    <div id="tabled_data"> 
                        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
                            <thead style="color:#fff;background-color:#6162d8;">
                                <tr>
                                    <th>Sr.no</th>
                                     <th>Name</th>
                                    <th>Account number</th>
                                   
                                    <th>Address</th>
									<?php if($o1->user_type != 'Affiliate'){?>
                                    <th>Bank Details</th>
                                    <?php } ?>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for ($i = 0; $i < $row; $i++) { ?>
                                    <tr>
                                        <td><?= ($i + 1) ?></td>
                                        <td><?= get_username_from_id($res[$i]['user_id']) ?> </td>
                                        <td><?= $res[$i]['name'] ?> <span style="color: green"><?= $res[$i]['bank_name'] ?> </span><br/> <?= $res[$i]['account_number'] ?></td>
                                       
                                        <td> <?= $res[$i]['address'] ?>  <?= $res[$i]['city'] ?>  <?=$res[$i]['district'] ?> <?= $res[$i]['state'] ?>  </td>
                                  	<?php if($o1->user_type != 'Affiliate'){?>
                                        <td><?= ($res[$i]['branch']) ?> <br/> <?= ($res[$i]['ifsc_code']) ?> <br/> <?= ($res[$i]['bank_code']) ?> </td>
										   <?php } ?>
                                        <td><?= status($res[$i]['is_active']) ?> </td>
                                    </tr>
                                <?php } ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>

<div  id="view_image"class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">

        <div class="modal-content">

            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel2">Photo</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>

            </div>
            <div class="modal-body" id="div_image">

            </div>

        </div>


    </div>
</div>