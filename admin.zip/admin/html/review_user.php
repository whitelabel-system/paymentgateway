<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->

    <div class="row">
        <div class="col-md-12" >
            <div class="card shadow mb-4">
                <div class="card-header py-3 row" style="margin-right: 0px;
    margin-left: 0px;">
                    <h6 class="col-md-2  m-0 font-weight-bold text-primary">Merchant Detail</h6>
                     <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="add_merchant.php?aid=<?= $o1->user_id ?>">Edit</a>
    </div>
                </div>
                <div class="card-body">

                    <div class="row">

                        <div class="col-md-6">
                            Gateway ID
                        </div>

                        <div class="col-md-6">
                            <?=$o1->user_name_id?>
                        </div>
                        <div class="col-md-6">
                            Company
                        </div>
                        <div class="col-md-6">
                            <?=$o1->company_name?>
                        </div>
                        <div class="col-md-6">
                            Address
                        </div>
                        <div class="col-md-6">
                            <?=$o1->user_address?><br><?=$o1->district?> , <?=$o1->state?> , <?=get_country_name($o1->country_id)?>
                        </div>
                        <div class="col-md-6">
                            Website
                        </div>
                        <div class="col-md-6">
                            <?=$o1->url?>

                        </div>
                    </div> 
                </div>

            </div>
            <div class="card shadow mb-4">
                 <div class="card-header py-3 row" style="margin-right: 0px;
    margin-left: 0px;">
                    <h6 class="col-md-2  m-0 font-weight-bold text-primary">Company Contact</h6>
                     <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="add_merchant.php?aid=<?= $o1->user_id ?>">Edit</a>
    </div>
                </div>
                <div class="card-body">

                    <div class="row">

                        <div class="col-md-6">
                            Contact Name
                        </div>

                        <div class="col-md-6">
                            <?=$o1->name?>
                        </div>
                        <div class="col-md-6">
                            Phone Number
                        </div>
                        <div class="col-md-6">
                            <?=$o1->mobile?>
                        </div>
                        <div class="col-md-6">
                            E-mail
                        </div>
                        <div class="col-md-6">
                            <?=$o1->email?>    </div>

                        </div> 
                    </div>

                </div>
                <div class="card shadow mb-4">
                     <div class="card-header py-3 row" style="margin-right: 0px;
    margin-left: 0px;">
                        <h6 class="col-md-2  m-0 font-weight-bold text-primary">Account Imformation</h6>
                         <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="add_merchant.php?aid=<?= $o1->user_id ?>">Edit</a>
    </div>
                    </div>
                    <div class="card-body">

                        <div class="row">

                            <div class="col-md-6">
                                User Name
                            </div>

                            <div class="col-md-6">
                                <?=$o1->user_name?>
                            </div>
                            <div class="col-md-6">
                                Password
                            </div>
                            <div class="col-md-6">
                                *******
                            </div>
                            <div class="col-md-6">
                                E-mail
                            </div>
                            <div class="col-md-6">
                                <?=$o1->email?>    </div>

                            </div> 
                        </div>

                    </div><br>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 row" style="margin-right: 0px;
    margin-left: 0px;">
                            <h6 class="col-md-2 m-0 font-weight-bold text-primary">Processing Services</h6>
                            <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="card_process.php?aid=<?= $o1->user_id ?>">Edit</a>
    </div>
                        </div>
                        <div class="card-body">

                         <div class="table-responsive">
                            <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
                              <thead>
                                <tr>
                                  <th>Credit Card</th>
                                  <th>Status</th>
                                  <th>Action</th>

                              </tr>
                          </thead>
                          <tbody style="text-align: left !important;padding-left: 10px">
                            <?php for ($i = 0; $i < 1; $i++) {?>
                                <tr >
                                  <td class="p-2">
                                    <?=$res[$i]['processor_name'];?>
                                </td>
                                <td class="p-2">
                                    Pending
                                </td>
                                <td class="p-2">
                                    <a href="card_process.php?aid=<?=$res[$i]['user_id'];?>" ><i class="fa fa-pen-square fa-fw"></i></a>
                                </td>
                            </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3 row" style="margin-right: 0px;
    margin-left: 0px;">
            <h6 class="col-md-2  m-0 font-weight-bold text-primary">Services</h6>
            <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="configure_processor.php?aid=<?= $o1->user_id  ?>">Edit</a>
    </div>
        </div>
        <div class="card-body">

         <div class="table-responsive">
            <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Service</th>
                  <th>Status</th>
                  <th>Action</th>

              </tr>
          </thead>
          <tbody style="text-align: left !important;">
            <?php for ($i = 0; $i < $row_ser; $i++) {?>
                <tr >
                  <td class="p-2">
                    <?=$res_ser[$i]['service_name'];?>
                </td>
                <td class="p-2">
                    <?=$res_ser[$i]['status']?>
                </td>
                <td class="p-2">
                    <a href="configure_processor.php?aid=<?=$res_ser[$i]['user_id'];?>" ><i class="fa fa-pen-square fa-fw"></i></a>
                </td>
            </tr>
        <?php }?>
    </tbody>
</table>
</div>

</div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3 row" style="margin-right: 0px;
    margin-left: 0px;">
        <h6 class="col-md-2 m-0 font-weight-bold text-primary">Fee Schedule (<?=$o2->pricing_name?>)</h6>
        <div class="col-md-10 text-right">
        <a class="btn btn-primary" href="choose_user_plan.php?aid=<?= $o1->user_id ?>">Edit</a>
    </div>
    </div>
    <div class="card-body">

     <div class="table-responsive">
        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Transaction Type</th>
              <th>Charge Type</th>
              <th>Amount</th>

          </tr>
      </thead>
      <tbody style="text-align: left !important;">
        <tr>
          <td class="p-2">
            Gateway Transaction
        </td>
        <td class="p-2">
            <?=$o2->gateway_fee_type?>
        </td>
        <td class="p-2">
         <?=$o2->gateway_transaction_fees?>
     </td>
 </tr>
 <tr>
  <td class="p-2">
     Monthly Maintenance 
 </td >
 <td class="p-2">
    <?=$o2->monthly_fee_type?>
</td>
<td class="p-2">
 <?=$o2->monthly_maintaince_fees?>
</td>
</tr>
<tr>
  <td class="p-2">
     Annualy Maintenance 
 </td>
 <td class="p-2">
    <?=$o2->annual_fee_type?>
</td>
<td class="p-2">
 <?=$o2->annual_maintaince_fees?>
</td>
</tr>
<tr>
  <td class="p-2">
    MID Setup 
 </td>
 <td class="p-2">
    <?=$o2->mid_fee_type?>
</td>
<td class="p-2">
 <?=$o2->mid_setup_fees?>
</td>
</tr>

<tr>
  <td class="p-2">
    PCI Compliance
 </td>
 <td class="p-2">
    <?=$o2->pci_fee_type?>
</td>
<td class="p-2">
 <?=$o2->pci_compliance?>
</td>
</tr>

<tr>
  <td class="p-2">
    Refund 
 </td>
 <td>
    <?=$o2->refund_fee_type?>
</td>
<td class="p-2">
 <?=$o2->refund_fee?>
</td>
</tr>
<tr>
  <td class="p-2">
    ChargeBack 
 </td>
 <td class="p-2">
    <?=$o2->chargeback_fee_type?>
</td>
<td class="p-2">
 <?=$o2->charge_back_fee?>
</td>
</tr>
<tr>
  <td class="p-2">
    Rolling Reserve 
 </td>
 <td class="p-2">
    <?=$o2->rolling_fee_type?>
</td>
<td class="p-2">
 <?=$o2->rolling_reserve?>
</td>
</tr>
<tr>
  <td class="p-2">
    Discount 
 </td>
 <td class="p-2">
    <?=$o2->discount_fee_type?>
</td>
<td class="p-2">
 <?=$o2->discount_fee?>
</td>
</tr>
<tr>
  <td class="p-2">
    Wire Transfer 
 </td>
 <td class="p-2">
    <?=$o2->wire_fee_type?>
</td>
<td class="p-2">
 <?=$o2->wire_transfer?>
</td>
</tr>
<tr>
  <td class="p-2">
    Fraud 
 </td>
 <td class="p-2">
    <?=$o2->fraud_fee_type?>
</td>
<td class="p-2">
 <?=$o2->fraud_fee?>
</td>
</tr>
<tr>
  <td class="p-2">
    Call Verification 
 </td>
 <td class="p-2">
    <?=$o2->call_fee_type?>
</td>
<td class="p-2">
 <?=$o2->call_verification_fee?>
</td>
</tr>
<tr>
  <td class="p-2">
    Integration 
 </td>
 <td class="p-2">
    <?=$o2->integration_fee?>
</td>
<td class="p-2">
 <?=$o2->integration_fee_type?>
</td>
</tr>
</tbody>
</table>
</div>

</div>
</div>

</div>
<hr>
<div class="col-md-12" >
    <div class="col-md-6" style="margin: auto;" >
       <a type="button" class="btn btn-primary form-control " href="configure_merchant.php?aid=<?=$o1->user_id?>" >Complete Merchant Creation</a>   
   </div><br>
<!--     <div class="col-md-6" style="margin: auto;" > 
    <a type="button" href="delete_merchant.php?aid=<?=$o1->user_id?>" class="btn btn-primary form-control">Delete Merchant Configuration</a>
        
</div> -->

</div>
</div>
</div>
<!-- /.container-fluid