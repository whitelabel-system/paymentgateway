<!-- Begin Page Content -->
<div class="container-fluid">
 
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3 row" style="margin-left: 0px">
      <h6 class="col-md-2 m-0 font-weight-bold text-primary">List of Acquirers</h6>
      <div class="col-md-12 text-right">
      <a class="btn btn-primary" href="add_credit_card_processor.php">Add New </a>
    </div>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-responsive" id="dataTable" width="100%" cellpadding="10">
          <thead>
            <tr>
              <th>S.No</th>
              <th>Processor Name</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
          <tr>
            <th>S.No</th>
            <th>Service</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
          </tfoot>
          <tbody style="text-align: start;">
            <?php for ($i = 0; $i < $rows; $i++) {?>
            <tr >
              <td style="padding-left: 10px"><?=$i + 1;?></td>
              <td style="padding-left: 10px">
                <?=$res[$i]['processor_name'];?>
              </td>
            
              <td style="padding-left: 10px">
                <?=status($res[$i]['is_active']);?>
              </td>
              <td style="padding-left: 10px">
                <a href="add_credit_card_processor.php?aid=<?=$res[$i]['credit_card_processor_id '];?>" ><i class="fa fa-pen-square fa-fw"></i></a>
              </td>
            </tr>
            <?php }?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /.container-fluid -->