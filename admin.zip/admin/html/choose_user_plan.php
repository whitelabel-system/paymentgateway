<!-- Begin Page Content --> 
<div class="container-fluid">
	<!-- Page Heading -->
	<!-- DataTales Example -->
	<form name="ra" id="ra" method="post" action="save_users.php?aid=<?= $o1->user_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
		<div class="row">
			<div class="col-md-12" >
				<div class="card shadow mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-primary">Choose User Plan</h6>
					</div>
					<div class="card-body">

						<div class="row">

							<div class="col-md">
								<label>User plan</label>
								<select name="plan_id" id="plan_id" class=" select2_single form-control" onchange="custom_plan()" >
									<option value="0">Select Plan</option>
									<?= user_plans_dropdown($o1->plan_id); ?>
									<option value="custom">Customize Plan</option>
								</select>
							</div>

							<div class="col-md">
								<label>User Affiliate</label>
								<select name="parent_id" id="parent_id" class=" select2_single form-control">
									<option value="0">Select Affiliate</option>
									<?= affiliate_list_dropdown($o1->parent_id); ?>
								</select>
							</div>
							<div class="col-md">
								<label>Prefered Currency</label>
								
        <div class="row" >
        <div class="col-md-6">
        <span> INR </span>
        </div>
        <div class="col-md-6">
            <label class="switch">
         <input type="checkbox" name="status_1" id="status_1"
          <?php for ($j=0; $j <$row; $j++) {  ?>
          <?php if ($res[$j]['status']=="Yes" && $res[$j]['currency']=='INR' ){?>
             
             checked="checked";
          <?php } ?>
        

          <?php } ?>

        onclick="save_user_currency('INR','1',<?=$user_id ?>)"  value="Yes">
        <span class="slider round span_margin">Yes</span>
        </label>
        </div>
        <div class="col-md-6">
        <span> USD </span>
        </div>
        <div class="col-md-6">
            <label class="switch">
         <input type="checkbox" name="status_2" id="status_2"
          <?php for ($j=0; $j <$row; $j++) {  ?>
          <?php if ($res[$j]['status']=="Yes" && $res[$j]['currency']=='USD' ){?>
             
             checked="checked";
          <?php } ?>
        

          <?php } ?>

        onclick="save_user_currency('USD','2',<?=$user_id ?>)"  value="Yes">
        <span class="slider round span_margin">Yes</span>
        </label>
        </div>
        <div class="col-md-6">
        <span> EUR </span>
        </div>
        <div class="col-md-6">
            <label class="switch">
         <input type="checkbox" name="status_3" id="status_3"
          <?php for ($j=0; $j <$row; $j++) {  ?>
          <?php if ($res[$j]['status']=="Yes" && $res[$j]['currency']=='EUR' ){?>
             
             checked="checked";
          <?php } ?>
        

          <?php } ?>

        onclick="save_user_currency('EUR','3',<?=$user_id ?>)"  value="Yes">
        <span class="slider round span_margin">Yes</span>
        </label>
        </div>
         <div class="col-md-6">
        <span> GBP </span>
        </div>
        <div class="col-md-6">
            <label class="switch">
         <input type="checkbox" name="status_4" id="status_4"
          <?php for ($j=0; $j <$row; $j++) {  ?>
          <?php if ($res[$j]['status']=="Yes" && $res[$j]['currency']=='GBP' ){?>
             
             checked="checked";
          <?php } ?>
        

          <?php } ?>

        onclick="save_user_currency('GBP','4',<?=$user_id ?>)"  value="Yes">
        <span class="slider round span_margin">Yes</span>
        </label>
        </div>
   </div>
 
							</div>
						</div> <br/>
						
						<div class="row" id="custom_plan"  style="display: none;" >
							
				 <div class="row col-md-12 " >
                        <div class="col-md-6">
                            <label>Pricing  Name</label>
                            <input type="text" class="form-control"   name="pricing_name" id="pricing_name" placeholder="Pricing Name" value="<?= ucfirst($o1->pricing_name); ?>" />
                        </div>
                  
                    </div>
                    <div class="row col-md-12 " >
                        <p style="width: 100%; margin: 8px;" >Gateway Transaction</p>

                        <div class="col-md-3">
                 
                            <select name="gateway_fee_type" id="gateway_fee_type" class="form-control" onchange="check_type('gateway')" >
                                <option value="Percentage" <?php if ($o1->gateway_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
                                <option value="Flat" <?php if ($o1->gateway_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <!-- <label>Gateway transaction fees</label> -->
                            <input type="text" class="form-control" name="gateway_transaction_fees" id="gateway_transaction_fees" placeholder="Gateway transaction fees" value="<?= $o1->gateway_transaction_fees; ?>" />
                        </div>
                        <div class="col-md-3">
                           <input type="text" class="form-control" name="gateway_max_fee" id="gateway_max_fee" placeholder="Gateway transaction maximum fees" value="<?= $o1->gateway_max_fee ?>"/>
                       </div>
                       <div class="col-md-3">
                           <input type="text" class="form-control" name="gateway_affiliate_fee" id="gateway_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->gateway_affiliate_fee ?>"/>
                       </div>
                   </div>
                   <div class="row col-md-12 " >
                    <p style="width: 100%; margin: 8px;" >Monthly Maintaince</p>
                    <div class="col-md-3">
                        <!-- <label> Monthly maintaince Fee Type</label> -->
                        <select name="monthly_fee_type" id="monthly_fee_type" class="form-control" onchange="check_type('monthly')" >
                            <option value="Percentage" <?php if ($o1->monthly_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
                            <option value="Flat" <?php if ($o1->monthly_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <!-- <label>Monthly  maintaince fees</label> -->
                        <input type="text" class="form-control" name="monthly_maintaince_fees" id="monthly_maintaince_fees" placeholder="Monthly maintaince fees" value="<?= $o1->monthly_maintaince_fees; ?>" />
                    </div>
                    <div class="col-md-3">
                        <!-- <label>Monthly maintaince maximum fees</label> -->
                        <input type="text" class="form-control" name="monthly_max_fee" id="monthly_max_fee" placeholder="Monthly maintaince maximum fees" value="<?= $o1->monthly_max_fee ?>"/>
                    </div>
                    <div class="col-md-3">
                       <input type="text" class="form-control" name="monthly_affiliate_fee" id="monthly_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->monthly_affiliate_fee ?>"/>
                   </div>
               </div>
               <div class="row col-md-12 " >
                <p style="width: 100%; margin: 8px;" >Annual Maintaince</p>
                <div class="col-md-3">
                    <!-- <label> Annual maintaince Fee Type</label> -->
                    <select name="annual_fee_type" id="annual_fee_type" class="form-control" onchange="check_type('annual')" >
                        <option value="Percentage" <?php if ($o1->annual_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
                        <option value="Flat" <?php if ($o1->annual_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <!-- <label>Annual maintaince fees</label> -->
                    <input type="text" class="form-control" name="annual_maintaince_fees" id="annual_maintaince_fees" placeholder="Annual maintaince fees" value="<?= $o1->annual_maintaince_fees; ?>" />
                </div>
                <div class="col-md-3">
                    <!-- <label>Annual maintaince maximum fees</label> -->
                    <input type="text" class="form-control" name="annual_max_fee" id="annual_max_fee" placeholder="Annual maintaince maximum fees" value="<?= $o1->annual_max_fee ?>"/>
                </div>
                <div class="col-md-3">
                   <input type="text" class="form-control" name="annual_affiliate_fee" id="annual_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->annual_affiliate_fee ?>"/>
               </div>
           </div>
           <div class="row col-md-12 " >
            <p style="width: 100%; margin: 8px;" >Mid Setup</p>
            <div class="col-md-3">
                <!-- <label> Mid Setup Fee Type</label> -->
                <select name="mid_fee_type" id="mid_fee_type" class="form-control" onchange="check_type('mid')" >
                    <option value="Percentage" <?php if ($o1->mid_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
                    <option value="Flat" <?php if ($o1->mid_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
                </select>
            </div>

            <div class="col-md-3">
                <!-- <label>Mid setup fees</label> -->
                <input type="text" class="form-control" name="mid_setup_fees" id="mid_setup_fees" placeholder="Mid setup fees" value="<?= $o1->mid_setup_fees; ?>" />
            </div>

            <div class="col-md-3">
                <!-- <label>Mid setup maximum fees</label> -->
                <input type="text" class="form-control" name="mid_max_fee" id="mid_max_fee" placeholder="Mid setup maximum fees" value="<?= $o1->mid_max_fee ?>"/>
            </div>
            <div class="col-md-3">
               <input type="text" class="form-control" name="mid_affiliate_fee" id="mid_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->mid_affiliate_fee ?>"/>
           </div>
       </div>
       <div class="row col-md-12 " >
        <p style="width: 100%; margin: 8px;" >Virtual terminal</p>
        <div class="col-md-3">
            <!-- <label> Virtual terminal Fee Type</label> -->
            <select name="virtual_fee_type" id="virtual_fee_type" class="form-control" onchange="check_type('virtual')">
                <option value="Percentage" <?php if ($o1->virtual_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
                <option value="Flat" <?php if ($o1->virtual_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
            </select>
        </div>
        <div class="col-md-3">
            <!-- <label>Virtual terminal</label> -->
            <input type="text" class="form-control" name="virtual_terminal" id="virtual_terminal" placeholder="Virtual terminal" value="<?= $o1->virtual_terminal; ?>" />
        </div>

        <div class="col-md-3">
            <!-- <label>Virtual terminal maximum fees</label> -->
            <input type="text" class="form-control" name="virtual_max_fee" id="virtual_max_fee" placeholder="Virtual terminal maximum fees" value="<?= $o1->virtual_max_fee ?>"/>
        </div>
        <div class="col-md-3">
           <input type="text" class="form-control" name="virtual_affiliate_fee" id="virtual_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->virtual_affiliate_fee ?>"/>
       </div>
   </div>
   <div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >PCI compliance</p>
    <div class="col-md-3">
        <!-- <label> PCI compliance Fee Type</label> -->
        <select name="pci_fee_type" id="pci_fee_type" class="form-control" onchange="check_type('pci')">
            <option value="Percentage" <?php if ($o1->pci_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->pci_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div>
    <div class="col-md-3">
        <!-- <label>PCI compliance</label> -->
        <input type="text" class="form-control" name="pci_compliance" id="pci_compliance" placeholder="PCI compliance" value="<?= $o1->pci_compliance; ?>" />
    </div>
    <div class="col-md-3">
        <!-- <label>PCI compliance maximum fees</label> -->
        <input type="text" class="form-control" name="pci_max_fee" id="pci_max_fee" placeholder="PCI compliance maximum fees" value="<?= $o1->pci_max_fee ?>"/>
    </div>
    <div class="col-md-3">
       <input type="text" class="form-control" name="pci_affiliate_fee" id="pci_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->pci_affiliate_fee ?>"/>
   </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Wire transfer</p>
    <div class="col-md-3">
        <!-- <label> Wire transfer Fee Type</label> -->
        <select name="wire_fee_type" id="wire_fee_type" class="form-control" onchange="check_type('wire')">
            <option value="Percentage" <?php if ($o1->wire_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->wire_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div>

    <div class="col-md-3">
        <!-- <label>Wire transfer</label> -->
        <input type="text" class="form-control" name="wire_transfer" id="wire_transfer" placeholder="Wire transfer" value="<?= $o1->wire_transfer; ?>" />
    </div>
    <div class="col-md-3">
        <!-- <label>Wire transfer maximum fees</label> -->
        <input type="text" class="form-control" name="wire_max_fee" id="wire_max_fee" placeholder="Wire transfer maximum fees" value="<?= $o1->pci_max_fee ?>"/>
    </div>
    <div class="col-md-3">
       <input type="text" class="form-control" name="wire_affiliate_fee" id="wire_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->wire_affiliate_fee ?>"/>
   </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Refund Fee</p>
    <div class="col-md-3">
        <!-- <label> Refund Fee Type</label> -->
        <select name="refund_fee_type" id="refund_fee_type" class="form-control" onchange="check_type('refund')">
            <option value="Percentage" <?php if ($o1->refund_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->refund_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div>
    <div class="col-md-3">
        <!-- <label>Refund fees</label> -->
        <input type="text" class="form-control" name="refund_fee" id="refund_fee" placeholder="Refund fees" value="<?= $o1->refund_fee; ?>" />
    </div>
    <div class="col-md-3">
        <!-- <label>Refund maximum fees</label> -->
        <input type="text" class="form-control" name="refund_max_fee" id="refund_max_fee" placeholder="Refund maximum fees" value="<?= $o1->refund_max_fee ?>"/>
    </div>
     <div class="col-md-3">
       <input type="text" class="form-control" name="refund_affiliate_fee" id="refund_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->refund_affiliate_fee ?>"/>
   </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Chargeback Fee</p>
    <div class="col-md-3">
        <!-- <label> Chargeback Fee Type</label> -->
        <select name="chargeback_fee_type" id="chargeback_fee_type" class="form-control" onchange="check_type('chargeback')">
            <option value="Percentage" <?php if ($o1->chargeback_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->chargeback_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div>
    <div class="col-md-3">
        <!-- <label>Chargeback fee</label> -->
        <input type="text" class="form-control" name="charge_back_fee" id="charge_back_fee" placeholder="Chargeback fee" value="<?= $o1->charge_back_fee; ?>" />
    </div>
    <div class="col-md-3">
        <!-- <label>Chargeback maximum fees</label> -->
        <input type="text" class="form-control" name="chargeback_max_fee" id="chargeback_max_fee" placeholder="Chargeback maximum fees" value="<?= $o1->chargeback_max_fee ?>"/>
    </div>
  <div class="col-md-3">
       <input type="text" class="form-control" name="chargeback_affiliate_fee" id="chargeback_affiliate_fee" placeholder="Affiliate Fee" value="<?= $o1->chargeback_affiliate_fee ?>"/>
   </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Rolling Reserve</p>
    <div class="col-md-3">
        <!-- <label> Rolling Fee Type</label> -->
        <select name="rolling_fee_type" id="rolling_fee_type" class="form-control"onchange="check_type('rolling')" >
            <option value="Percentage" <?php if ($o1->rolling_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->rolling_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div>   
    <div class="col-md-3">
        <!-- <label>Rolling reserve</label> -->
        <input type="text" class="form-control" name="rolling_reserve" id="rolling_reserve" placeholder="Rolling reserve" value="<?= $o1->rolling_reserve; ?>" />
    </div>
    <div class="col-md-3">
        <input type="text" class="form-control" name="rolling_max_fee" id="rolling_max_fee" placeholder="Rolling maximum fees" value="<?= $o1->rolling_max_fee ?>"/>
    </div>
    <div class="col-md-3">
        <!-- <label>Rolling maximum fees</label> -->
        <input type="text" class="form-control" name="rolling_affiliate_fee" id="rolling_affiliate_fee" placeholder="Affiliate fees" value="<?= $o1->rolling_affiliate_fee ?>"/>
    </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Discount </p>
    <div class="col-md-3">
        <!-- <label> Discount Fee Type</label> -->
        <select name="discount_fee_type" id="discount_fee_type" class="form-control" onchange="check_type('discount')">
            <option value="Percentage" <?php if ($o1->discount_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->discount_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div>   
    <div class="col-md-3">
        <!-- <label>Discount fees</label> -->
        <input type="text" class="form-control" name="discount_fees" id="discount_fees" placeholder="Discount fees" value="<?= $o1->discount_fees; ?>" />
    </div>
    <div class="col-md-3">

        <input type="text" class="form-control" name="discount_max_fee" id="discount_max_fee" placeholder="Discount maximum fees" value="<?= $o1->discount_max_fee ?>"/>
    </div>
    <div class="col-md-3">
        <!-- <label>Rolling maximum fees</label> -->
        <input type="text" class="form-control" name="discount_affiliate_fee" id="discount_affiliate_fee" placeholder="Affiliate fees" value="<?= $o1->discount_affiliate_fee ?>"/>
    </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Fraud Fee </p>
    <div class="col-md-3">
        <!-- <label> Fraud Fee Type</label> -->
        <select name="fraud_fee_type" id="fraud_fee_type" class="form-control"onchange="check_type('fraud')" >
            <option value="Percentage" <?php if ($o1->fraud_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->fraud_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div>  

    <div class="col-md-3">
        <!-- <label>Fraud fee</label> -->
        <input type="text" class="form-control" name="fraud_fees" id="fraud_fees" placeholder="Fraud fee" value="<?= $o1->fraud_fees; ?>" />
    </div>
    <div class="col-md-3">
        <!-- <label>Fraud maximum fees</label> -->
        <input type="text" class="form-control" name="fraud_max_fee" id="fraud_max_fee" placeholder="Fraud maximum fees" value="<?= $o1->fraud_max_fee ?>" />
    </div>
      <div class="col-md-3">
        <input type="text" class="form-control" name="fraud_affiliate_fee" id="fraud_affiliate_fee" placeholder="Affiliate fees" value="<?= $o1->fraud_affiliate_fee ?>"/>
    </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Call verification </p>

    <div class="col-md-3">
        <!-- <label> Call verification Fee Type</label> -->
        <select name="call_fee_type" id="call_fee_type" class="form-control" onchange="check_type('call')">
            <option value="Percentage" <?php if ($o1->call_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->call_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div> 
    <div class="col-md-3">
        <!-- <label>Call verification fee</label> -->
        <input type="text" class="form-control" name="call_verification_fee" id="call_verification_fee" placeholder="Call verification fee" value="<?= $o1->call_verification_fee; ?>" />
    </div>
    <div class="col-md-3">
        <input type="text" class="form-control" name="call_max_fee" id="call_max_fee" placeholder="Call verification maximum fees" value="<?= $o1->call_max_fee ?>"  />
    </div>
          <div class="col-md-3">
        <input type="text" class="form-control" name="call_affiliate_fee" id="call_affiliate_fee" placeholder="Affiliate fees" value="<?= $o1->call_affiliate_fee ?>"/>
    </div>
</div>
<div class="row col-md-12 " >
    <p style="width: 100%; margin: 8px;" >Integration Fee </p>
    <div class="col-md-3">
        <!-- <label> Integration Fee Type</label> -->
        <select name="integration_fee_type" id="integration_fee_type" class="form-control" onchange="check_type('integration')">
            <option value="Percentage" <?php if ($o1->integration_fee_type == "Percentage") { ?> selected="selected" <?php } ?>>Percentage</option>
            <option value="Flat" <?php if ($o1->integration_fee_type == "Flat") { ?> selected="selected" <?php } ?>>Flat</option>
        </select>
    </div> 
    <div class="col-md-3">
        <!-- <label>Integration fee</label> -->
        <input type="text" class="form-control" name="integration_fee" id="integration_fee" placeholder="Integration fee" value="<?= $o1->integration_fee; ?>" />
    </div>

    <div class="col-md-3">
        <!-- <label>Integration maximum fees</label> -->
        <input type="text" class="form-control" name="integration_max_fee" id="integration_max_fee" placeholder="Integration maximum fees" value="<?= $o1->integration_max_fee ?>" />
    </div>
    <div class="col-md-3">
        <input type="text" class="form-control" name="integration_affiliate_fee" id="integration_affiliate_fee" placeholder="Affiliate fees" value="<?= $o1->integration_affiliate_fee ?>"/>
    </div>
</div>

						</div>
						<hr/>
						<div class="row top_margin_10">
							<div class="col-md-12">
								<input type="hidden" name="user_id" id="user_id" value="<?= $user_id; ?>" />
								<input type="hidden" name="updte" id="updte" value="1" />
								<!-- <button type="submit" name="save_button" id="save_button" class="btn btn-primary" > Save </button> -->
								<input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />
                     <a type="button" name="save" id="save" value="Back" class="btn btn-primary" href="configure_processor.php?aid=<?=$user_id?>" >Back</a>
 <a type="button" name="save" id="save" value="Next" class="btn btn-success" style="width: auto;" href="user_security.php?aid=<?=$user_id?>" >Next</a>
							</div>
						</div>

					</div>
				</div>
			</div>
			
		</div>
	</form>
</div>
<!-- /.container-fluid