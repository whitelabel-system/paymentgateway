<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Esecure Payment | Admin - Dashboard</title>
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!-- Custom fonts for this template-->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../vendor/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">
 <link href="../vendor/select2/dist/css/select2.min.css" rel="stylesheet">
  <link href="../css/sb-admin-2.css" rel="stylesheet">
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">
  <?php if ($tables == 1 || $tables == 4) { ?>
    <!--Datatables condition. These are used to install and implement datatables -->
    <link href="../vendor/datatables/buttons.dataTables.min.css" rel="stylesheet">
    <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <!-- <link href="./vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet"> -->
  <?php } ?>

</head>

<body id="page-top">

  <!-- Page Wrapper --> 
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" onclick="myFunction(event)" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon ">
          <img class="img-profile rounded-circle" src="../img/<?=$res_site[0]['logo']?>" style="height: 50px;" >
        </div>
      <!--   <div class="sidebar-brand-text mx-3">Admin</div> -->
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Dashboard
      </div>
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-home"></i>
          <span>Home</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseuser" aria-expanded="true" aria-controls="collapseuser">
            <i class="fas fa-fw fa-users"></i>
            <span>Merchants</span>
          </a>
          <div  id="collapseuser" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="add_merchant.php">Add Merchant</a>
              <a class="collapse-item" href="users.php?type=Merchant">All Merchants</a>
  

            </div>
          </div>
        </li>
         <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseAffilliate" aria-expanded="true" aria-controls="collapseAffilliate">
            <i class="fas fa-fw fa-users"></i>
            <span>Affilliate</span>
          </a>
          <div  id="collapseAffilliate" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="add_affiliate.php">Add Affilliate</a>
              <a class="collapse-item" href="users.php?type=Affiliate">All Affilliate</a>
  

            </div>
          </div>
        </li>
        <!-- <li class="nav-item active">
          <a class="nav-link" href="users.php">
            <i class="fas fa-fw fa-users"></i>
            <span>Users</span>
          </a>
        </li> -->
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsehistory" aria-expanded="true" aria-controls="collapsehistory">
            <i class="fas fa-fw fa-wallet  "></i>
            <span>Transactions</span>
          </a>
          <div  id="collapsehistory" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="payments.php">All Transactions</a>
              <a class="collapse-item" href="ledger.php">Ledger</a>
            </div>
          </div>
        </li>
        
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsesettlement" aria-expanded="true" aria-controls="collapsesettlement">
            <i class="fas fa-fw fa-chart-line  "></i>
            <span>Settlements</span>
          </a>
          <div  id="collapsesettlement" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="money_withdrawal.php">Add New</a>
              <a class="collapse-item" href="pending_settlements.php">Pending Settlements</a>
              <a class="collapse-item" href="approve_settlements.php">Approved Settlements</a>
              
            </div>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsedispute" aria-expanded="true" aria-controls="collapsedispute">
            <i class="fas fa-fw fa-file-alt"></i>
            <span>Disputes</span>
          </a>
          <div  id="collapsedispute" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="disputes.php?status=All">Add New Disputes</a>
               <a class="collapse-item" href="disputes.php?status=Pending">Pending Disputes</a>
               <a class="collapse-item" href="approve_disputes.php">Approved Disputes</a>
               <a class="collapse-item" href="disputes.php?status=Reject">Rejected Disputes</a>
            </div>
          </div>
        </li>
        <li class="nav-item">
 <a class="nav-link collapsed" href="approve_disputes.php"  aria-expanded="true" aria-controls="collapsechargeback">
            <i class="fas fa-fw fa-credit-card"></i>
            <span> Chargeback</span>
          </a>
         <!--  <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsechargeback" aria-expanded="true" aria-controls="collapsechargeback">
            <i class="fas fa-fw fa-credit-card"></i>
            <span> Chargeback</span>
          </a>
            <div  id="collapsechargeback" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="credit_card_list.php">All Card Payments</a>
              <a class="collapse-item" href="chargeback.php">List Chargeback</a>
            <a class="collapse-item" href="#">Chargeback Results</a> 

            </div>
          </div>-->
        </li>
                <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapserefund" aria-expanded="true" aria-controls="collapserefund">
            <i class="fas fa-fw fa-undo"></i>
            <span> Refunds</span>
          </a>
          <div  id="collapserefund" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="refund_list.php">Add New</a>
          
               <a class="collapse-item" href="approved_refundlist.php">Approved Refunds List</a>
              <a class="collapse-item" href="reject_refundlist.php">Reject Refund List</a>
              <a class="collapse-item" href="pending_refundlist.php">Pending Refunds List</a>
               <!-- <a class="collapse-item" href="refund_list.php">All Refund List</a> -->
              <!-- <a class="collapse-item" href="chargeback.php">List Chargeback</a> -->
              <!-- <a class="collapse-item" href="#">Chargeback Results</a> -->

            </div>
          </div>
        </li>
        
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsesetting" aria-expanded="true" aria-controls="collapsesetting">
            <i class="fas fa-fw fa-cogs"></i>
            <span>Settings</span>
          </a>
          <div  id="collapsesetting" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="withdrawal_setting.php">Tax Setting</a>
              <a class="collapse-item" href="user_setting.php">Fee Plan</a>
              <!-- <a class="collapse-item" href="all_user_setting.php">All Fee Plans</a> -->
              <a class="collapse-item" href="services.php">Payment Technologies</a>
              <a class="collapse-item" href="credit_card_processor.php">All Acquirers</a>
              <a class="collapse-item" href="security_parameter.php">Security Parameter</a>


            </div>
          </div>
        </li>        
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsehelp" aria-expanded="true" aria-controls="collapsehelp">
            <i class="fas fa-ticket-alt "></i>
            <span>Tickets</span>
          </a>
          <div  id="collapsehelp" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="all_tickets.php">View Ticket</a>
              <a class="collapse-item" href="add_ticket.php">Add Ticket</a>
            </div>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsebm" aria-expanded="true" aria-controls="collapsebm">
            <i class="fas fa-ticket-alt "></i>
            <span>Boarding Manager</span>
          </a>
          <div  id="collapsebm" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="user_documents.php">View Applications</a>
            </div>
          </div>
        </li>
        

        <!-- <li class="nav-item active">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsenotice" aria-expanded="true" aria-controls="collapsenotice">
            <i class="fas fa-fw fa-bell "></i>
            <span>Notice Board</span>
          </a>
          <div  id="collapsenotice" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="notice_board.php">Notice Board</a>
            </div>
          </div>
        </li> -->
         <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsehelpq" aria-expanded="true" aria-controls="collapsehelpq">
            <i class="fas fa-fw fa-desktop "></i>
            <span>Help</span>
          </a>
          <div  id="collapsehelpq" class="collapse" aria-labelledby="headingManagement" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <a class="collapse-item" href="all_help_category.php">Help Category</a>
            </div>
          </div>
        </li>
        <!-- Divider -->
        <!--hr class="sidebar-divider"-->

        <!-- Heading -->
      <!--div class="sidebar-heading">
        Interface
      </div>

      
      <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>Components</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Custom Components:</h6>
            <a class="collapse-item" href="buttons.html">Buttons</a>
            <a class="collapse-item" href="cards.html">Cards</a>
          </div>
        </div>
      </li-->

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item active dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
          <!--   <li class="nav-item active dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" onclick="show_request_money()" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <span class="badge badge-danger badge-counter" id="pending_request_money"></span>
              </a> -->
              <!-- Dropdown - Alerts -->
             <!--  <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  Alerts Center
                </h6>
                <div id="my_request_money">

                </div> -->
<!--                 <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-primary">
                      <i class="fas fa-file-alt text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 12, 2019</div>
                    <span class="font-weight-bold">A new monthly report is ready to download!</span>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-warning">
                      <i class="fas fa-exclamation-triangle text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 2, 2019</div>
                    Spending Alert: We've noticed unusually high spending for your account.
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a> -->
            <!--   </div>
            </li> -->

            <!-- Nav Item - Messages -->
            <li class="nav-item active dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" onclick="show_notifications()" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <!-- Counter - Messages -->
                <span class="badge badge-danger badge-counter" id="notifications" ></span>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                  Message Center
                </h6>
                <div id="my_notifications">

                </div>

              </div>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item active dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $o->name?></span>
                <img class="img-profile rounded-circle" src="../img/<?=$o->profile_pic?>">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="change_password.php">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Change Pasword
                </a>
                <a class="dropdown-item" href="notice_board.php">
                  <i class="fas fa-bell fa-sm fa-fw mr-2 text-gray-400"></i>
                  Notice Board
                </a>
                <a class="dropdown-item" href="user_activity.php">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <a class="dropdown-item" href="user_authentication.php">
                  <i class="fas fa-key fa-sm fa-fw mr-2 text-gray-400"></i>
                  2 F Authentication
                </a>
                 <a class="dropdown-item" href="all_users.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  All Users
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->
		
		
		
		
		
		
	<script type="text/javascript">
		function myFunction(e) {
		  if (document.querySelector('#accordionSidebar li.active') !== null) {
			document.querySelector('#accordionSidebar li.active').classList.remove('active');
		  }
		  e.target.className = "active";
		}
	</script>
