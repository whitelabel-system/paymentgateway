
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
       <!--  <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
    </div>

    <!-- Content Row -->
    <div class="row">

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=today" class="text-decoration-none">
                <div class="card border-bottom-success shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-1">Today Payments</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="today_payment" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=month" class="text-decoration-none">
                <div class="card border-bottom-warning shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-2">Monthly Payments</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="monthly_payment" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=year" class="text-decoration-none">
                <div class="card border-bottom-info shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-3">Yearly Payments</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="yearly_payment" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=pending" class="text-decoration-none">
                <div class="card border-bottom-pending shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-4">Pending Payments</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="pending_amount" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=success" class="text-decoration-none">
                <div class="card border-bottom-pending shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-4">Success Payments</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="success_payment" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=failed" class="text-decoration-none">
                <div class="card border-bottom-info shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-3">Failed Payments</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="failed_payment" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=pending" class="text-decoration-none">
                <div class="card border-bottom-warning shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-2">Pending Payments</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="pending1" ></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="payments.php?type=all" class="text-decoration-none">
                <div class="card border-bottom-success shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-1">Total Transaction</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800">&nbsp;<span id="total_transaction" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="users.php?type=all" class="text-decoration-none">
                <div class="card border-bottom-success shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-1">Total User</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-fw fa-users"></i>&nbsp;<span id="total_users" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="users.php?type=Affiliate" class="text-decoration-none">
                <div class="card border-bottom-warning shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-2">Total Affiliate</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-fw fa-users"></i>&nbsp;<span id="total_affiliate" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="users.php?type=Merchant" class="text-decoration-none">
                <div class="card border-bottom-info shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-3">Total Merchant</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-fw fa-users"></i>&nbsp;<span id="total_merchants" >0</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="status.php?type=Success" class="text-decoration-none">
                <div class="card border-bottom-pending shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-4">GST/TDS</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="tds_gst" ></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>
         <div class="col-xl-3 col-md-6 mb-4">
            <a href="#" class="text-decoration-none">
                <div class="card border-bottom-warning shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-2">Total Chargeback Amount</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-fw fa-users"></i>&nbsp;<span id="total_chargeback_amount" ><?=$o->admin_chargeback_amount?></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="#" class="text-decoration-none">
                <div class="card border-bottom-info shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-3">Total Refund Amount</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-fw fa-users"></i>&nbsp;<span id="" ><?=$o->admin_refund_amount?></span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <a href="#" class="text-decoration-none">
                <div class="card border-bottom-pending shadow show_position ">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1 index_show_position color-custom-4">Total Amount Balance</div>
                                <div class="h5 mt-2 mb-0 font-weight-bold text-gray-800"><i class="fas fa-rupee-sign"></i>&nbsp;<span id="" ></span><?= $o->admin_chargeback_amount + $o->admin_refund_amount?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>    
        </div>

    </div>

    <!-- Content Row -->

    <div class="row">

        <!-- Area Chart -->
        <div class="col-xl-4 col-lg-7">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Monthly Settlement</h6>
                    <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Dropdown Header:</div>
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="myAreaChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Area Chart -->
        <div class="col-xl-4 col-lg-7">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Monthly Commission</h6>
                    <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Dropdown Header:</div>
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="DisputesAreaChart"></canvas>
                    </div>
                </div>
            </div>
        </div>


        <!-- Area Chart -->
        <div class="col-xl-4 col-lg-7">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Revenue Sources</h6>
                    <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Dropdown Header:</div>
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="RevenueSourcesAreaChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Row -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h3 class="h3 mb-0 text-gray-800">User Detail</h3>
    </div>
    <div class="row">

        <!-- Pie Chart -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Merchant Payment Month Wise</h6>
                    <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Dropdown Header:</div>
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="merchantPieChart"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="mr-2">
                            <i class="fas fa-circle text-primary"></i> Success
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-success"></i> Pending
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-failed"></i> Failed
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pie Chart -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Affiliates Payment Month Wise</h6>
                    <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Dropdown Header:</div>
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="affiliatesPieChart"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="mr-2">
                            <i class="fas fa-circle text-primary"></i> Success
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-success"></i> Pending
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-failed"></i> Failed
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pie Chart -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Payment Type Payment Month Wise</h6>
                    <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                            <div class="dropdown-header">Dropdown Header:</div>
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2">
                        <canvas id="PaymentTypePieChart"></canvas>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="mr-2">
                            <i class="fas fa-circle text-primary"></i> Payment
                        </span>
                        <span class="mr-2">
                            <i class="fas fa-circle text-commision"></i> Commission
                        </span>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

