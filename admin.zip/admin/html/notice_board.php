<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
   
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 row" style="margin-left: 0px;margin-right: 0px">
            <h6 class="m-0 col-md-2 font-weight-bold text-primary">List of Notice(s)</h6>
            <div class="col-md-10 text-right">
            <a class="btn btn-primary" href="notice_board_details.php">Add New Notice</a>
        </div>
        </div>
        <div class="card-body">
            <!--<div class="table-responsive">-->
                <table class="table table-bordered table-responsive" cellpadding="10" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Notice Type</th>
                            <th>Notice Heading</th>
                            <th>From Date</th>
                            <th>To Date</th>
                            <th>File</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody style="text-align: start;" >
                        <?php for ($i = 0; $i < $rows; $i++) {?>
                            <tr >
                                <td  ><?=$i + 1;?></td>
                                <td>
                                    <?=($res[$i]['notice_type']);?>
                                </td>
                                <td>
                                    <?=$res[$i]['notice_heading'];?>
                                </td>
                                <td>
                                    <?=format_date($res[$i]['notice_date']);?>
                                </td>
                                <td>
                                    <?=format_date($res[$i]['to_date']);?>
                                </td>
                                <td>
                                    <?php if($res[$i]['notice_type'] != "Text"){?>
                                    <a href="../notice_board/<?= $res[$i]['notice_file']?>" target="_blank">View File</a>
                                <?php } ?>

                                </td>
                                <td>
                                    <?=status($res[$i]['is_active']);?>
                                </td>
                                <td>
                                    <a href="notice_board_details.php?aid=<?=$res[$i]['notice_board_id'];?>" ><i class="fa fa-pen-square fa-fw" title="Edit Notice"></i></a> |
                                    <a href="delete_notice.php?aid=<?=$res[$i]['notice_board_id'];?>" ><i class="fa fa-times fa-fw" title="Delete Notice"></i></a>

                                </td>
                            </tr>
                        <?php }?>

                    </tbody>
                </table>
            <!--</div>-->
        </div>
    </div>
</div>
<!-- /.container-fluid -->