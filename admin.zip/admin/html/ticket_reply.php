<!-- Begin Page Content --> 
<div class="container-fluid">
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Ticket: <?= $o1->ticket_number; ?></h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="card" style="width: 100% !important;">
                        <div class="card-header bg-darkblue text-white">
                            <div class="d-flex flex-row justify-content-start">
                                <div class="col">
                                    <div class="my-0">
                                        <b>Ticket Details</b>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless font-weight-bolder table-sm">
                                <tr scope="row">
                                    <td width="30%">Subject:</td>
                                    <td><?= ucfirst($o1->subject); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%">Type:</td>
                                    <td><?= $o1->ticket_type; ?></td>
                                </tr>
                                <tr>
                                    <td width="30%">Ticket-No:</td>
                                    <td><?= $o1->ticket_number; ?></td>
                                </tr>
                                <tr>
                                    <td width="30%">Status:</td>
                                    <td><?= $o1->status; ?></td>
                                </tr>
                                <tr>
                                    <td width="30%">Created on:</td>
                                    <td><?= $o1->created_at; ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <hr/>
                    <div class="card" style="width: 100% !important;">
                        <div class="card-header bg-darkblue text-white">
                            <div class="d-flex flex-row justify-content-start">
                                <div class="col">
                                    <div class="my-0">
                                        <b>User Details</b>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table font-weight-bolder table-borderless table-sm">
                                <tbody>
                                    <tr>
                                        <td>Name:</td>
                                        <td><?= ucfirst($o1->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td>E-mail:</td>
                                        <td><?= $o1->email; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Mobile:</td>
                                        <td><?= $o1->mobile; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <hr/>
                    <div class="card" style="width: 100% !important;">
                        <div class="card-header bg-darkblue text-white">
                            <div class="d-flex flex-row justify-content-start">
                                <div class="col">
                                    <div class="my-0">
                                        <b>Ticket Attachements</b>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless font-weight-bolder table-sm">
                                <?php for ($j=0; $j <$row_attachement; $j++) {  ?>
                              
                                <tr>
                                    <td width="50%"><?= ucfirst($res_attachement[$j]['send_by']); ?></td>
                                    <!--<td> <a onclick="show_document('<?=$res_attachement[$j]['ticket_file']?>')"> <?= $res_attachement[$j]['ticket_file']; ?></a></td>-->
				    <td> <a target="blank" href="../img/<?=$res_attachement[$j]['ticket_file']?>"> <?= $res_attachement[$j]['ticket_file']; ?></a></td>
				    <td><a href="../img/<?=$res_attachement[$j]['ticket_file']?>" download>Download</a></td>
                                </tr>
                            <?php } ?>
                                
                            </table>
                        </div>
                    </div>
                    
                </div>
                <div class="col-md-8">
                    <div class="card" style="width: 100% !important; height: 100%">
                        <div class="card-header bg-darkblue text-white">
                            <div class="d-flex flex-row justify-content-start">
                                <div class="col">
                                    <div class="my-0">
                                        <b>Ticket Reply-box</b>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body bg-lightgrey d-flex flex-column p-0" style="flex: 9 1">
                            <div class="container-fluid message-scroll mt-1" style="flex: 1 1; max-height: 405px;overflow-y: scroll;">
                                
                                <?php
                                for ($i = 0; $i < $rows; $i++) {
                                    if ($res[$i]['sent_by'] == 'Admin') {
                                        ?>
                                        <div class="row justify-content-end">
                                            <div class="card message-card bg-darkblue m-1">
                                                <div class="card-body p-2 text-white">
                                                    <span><b><?= ucfirst($res[$i]['message']) ?></b></span>
                                                    <span class="float-right mx-1 ml-2"><small><?= $res[$i]['created_at'] ?></small></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } else { ?>
                                        <div class="row">
                                            <div class="card message-card m-1">
                                                <div class="card-body p-2">
                                                    <span><b><?= ucfirst($res[$i]['message']) ?></b></span>
                                                    <span class="float-right mx-1 ml-2"><small class="text-muted"><?= $res[$i]['created_at'] ?></small></span>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                            <form name="ticket_reply" class="mt-2 mb-2" id="ticket_reply" method="post" action="save_ticket_reply.php?aid=<?= $o1->ticket_id; ?>" enctype="multipart/form-data" onsubmit="return false" >
                                <div class="input-group  mr-2">
                                   <?php if ($o1->status=="Closed") {?>
                                        <input type="text" class="form-control mx-1" id="" name="" placeholder="" value="This Ticket has been Closed" readonly />

                                    <?php }else{ ?>
                                        <textarea name="text_message" id="text_message" cols="30" rows="5" class="form-control"   ></textarea>
                                       <!--  <input type="text" class="form-control mx-1" id="message" name="message" placeholder="Type your reply here..." /> -->
                                       <input type="hidden" id="message" name="message">
                                       <div class="row col-md-11 ">
                                        <div class="col-md-6" >
                                       <input type="file" name="ticket_attachment" id="ticket_attachment" class="form-control top_margin_10 "  >
                                       </div>
                                       <div class="col-md-6" >
                                       <select name="ticket_status" id="ticket_status" class="form-control top_margin_10 " >
                                           <option value="New">New</option>
                                           <option value="Replied">Replied</option>  
                                           <option value="Pending">Pending</option> 
                                           <option value="Closed">Closed</option>
                                           <option value="Waiting">Waiting</option> 
                                       </select>                                           
                                       </div>

                                       </div>
                                        <button type="submit" name="save_button" id="save_button" class="mx-2 btn btn-sm border-0 bg-white text-primary hover-color-darkblue top_margin_10">
                                            <i class="fab fa-telegram-plane fa-2x"></i>
                                        </button>
                                    <?php } ?>
                                    <input type="hidden" name="ticket_id" id="ticket_id" value="<?= $o1->ticket_id; ?>" />
                                    <input type="hidden" name="updte" id="updte" value="1" />
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog" aria-labelledby="defaultModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="defaultModalLabel">Document</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body" id="img_div">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>