<?php
session_start();
include"include.php";
include"session.php";
$page_name="add_disputes";



include "includes/header.php";
include "html/add_disputes.php";
include "includes/footer.php";
?>