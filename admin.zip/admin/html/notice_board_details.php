<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php if ($o1->notice_board_id > 0) {?> Edit <?php } else {?> Add <?php }?> Notice Board Details</h6> 
        </div>
        <div class="card-body">
            <form name="ra" id="ra" method="post" action="notice_board_details.php?aid=<?=$o1->notice_board_id;?>" enctype= multipart/form-data>
                <div class="row">
                    <div class="col-md-6">
                        <label>Notice Type</label>
                        <select name="notice_type" id="notice_type" class="form-control" required="required">
                            <option value="">Select Notice Type</option>
                            <option value="Image" <?php if ($o1->notice_type == "Image") {?> selected="selected" <?php }?>>Image</option>
                            <option value="Video" <?php if ($o1->notice_type == "Video") {?> selected="selected" <?php }?>>Video</option>
                            <option value="Text" <?php if ($o1->notice_type == "Text") {?> selected="selected" <?php }?>>Text</option>
                        <option value="Document" <?php if ($o1->notice_type == "Document") {?> selected="selected" <?php }?>>Document</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label>User Type</label>
                        <select name="user_type" id="user_type" class="form-control" required="required">
                            <option value="">Select User Type</option>
                            <option value="All" <?php if ($o1->user_type == "All") {?> selected="selected" <?php }?>>All</option>
                            <option value="Merchant" <?php if ($o1->user_type == "Merchant") {?> selected="selected" <?php }?>>Merchant</option>
                        <option value="Affiliate" <?php if ($o1->user_type == "Affiliate") {?> selected="selected" <?php }?>>Affiliate</option>
                            <option value="Staff" <?php if ($o1->user_type == "Staff") {?> selected="selected" <?php }?>>Staff</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label>Notice Heading</label>
                        <input type="text" name="notice_heading" id="notice_heading" class="form-control" placeholder="Notice Heading" value="<?=$o1->notice_heading;?>" >
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label>Notice</label>
                        <textarea name="notice_details" id="notice_details" class="form-control" rows="5"><?=$o1->notice_details;?></textarea>
                    </div>
                </div>
             
                <div class="row">
                    <div class="col-md-6">
                        <label>Upload File</label>
                        <input type="file" name="notice_file" id="notice_file" class="form-control" />
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label>Notice From Date</label>
                        <input type="date" name="notice_date" id="notice_date" class="form-control" value="<?=$o1->notice_date;?>"  />
                    </div>
                    <div class="col-md-6">
                        <label>Notice To Date</label>
                        <input type="date" name="to_date" id="to_date" class="form-control" value="<?=$o1->to_date;?>"  />
                    </div>
                </div>
                <?php if ($o1->notice_file != "") {?>
                    <div class="row">
                        <div class="col-md-6">
                            <img src="../notice_board/<?=$o1->notice_file;?>" class="img-rounded" style="width:100px;" alt="Notice board" />
                        </div>
                    </div>
                <?php }?>
                <div class="row">
                    <div class="col-md-6">
                        <label>Status</label>
                        <select name="is_active" id="is_active" class="form-control">
                            <option value="1" <?php if ($o1->is_active == 1) {?> selected="selected" <?php }?>>Active</option>
                            <option value="0" <?php if ($o1->is_active == 0) {?> selected="selected" <?php }?>>Blocked</option>
                        </select>
                    </div>
                </div>
                <div class="row top_margin_10">
                    <div class="col-md-6">
                        <input type="hidden" name="updte" id="updte" value="1" />
                        <input type="submit" name="save" id="save" value="Save" class="btn btn-primary" />
                        <input type="button" name="cancel" id="cancel" value="Cancel" class="btn btn-secondary" onclick="history.back(-1)" />

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid -->