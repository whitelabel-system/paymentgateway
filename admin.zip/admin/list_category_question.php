<?php
session_start();
include"include.php";
include"session.php";


$tables = 1;

// pt($_POST);pt($_GET);
## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$length = $_POST['length'];

if ($row == "") {
    $row = 0;
}

if ($length == "") {
    $length = 10;
}

$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value
//pt($_POST);

$sql_total = "Select count(help_category_question_id ) as total_transactions from help_category_question where help_category_id  ='".$_SESSION['help_category_id']."'";
$res_total = getXbyY($sql_total);

$sql_transactions = "Select * from help_category_question where help_category_id  ='".$_SESSION['help_category_id']."'  limit $row ,$length";
//$sql_transactions = "Select * from wallet where user_id = ".$o->user_id." order by transaction_date DESC";
$res_transactions = getXbyY($sql_transactions);
$row_transactions = count($res_transactions);

if ($row_transactions > 0) {

    for ($i = 0; $i < $row_transactions; $i++) {
                $data[] = array(
            "sr_no" => ($i+1),
            "category_name" => $res_transactions[$i]['category_name'],
            "question" => $res_transactions[$i]['category_question'],
            "answer" => $res_transactions[$i]['category_answer'],
            "status" => status($res_transactions[$i]['is_active']),
            "action" => '<a class="fa_edit" href="#"  onclick="edit_question('.$res_transactions[$i]["help_category_question_id"].')" >  <i class="fa fa-edit" title="Edit"></i></a>', 
        );
    }
} else {
    $data = array();
}

## Response
$response = array(
    "draw" => intval($draw),
    "iTotalRecords" => $res_total[0]['total_transactions'],
    "iTotalDisplayRecords" => $res_total[0]['total_transactions'],
    "aaData" => $data,
);

echo json_encode($response);


?>