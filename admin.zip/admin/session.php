<?php

if (isset($_SESSION['admin_id'])) {
	$o->user_id = $_SESSION['admin_id'];
	$o = $factory->get_object($o->user_id, "users", "user_id");

	if ($o->profile_pic == "") {
		$o->profile_pic = "../img/avatar.svg";
	} else {
		$o->profile_pic = "../img/" . $o->profile_pic;
	}




$sql ="select * from permissions where permission_id = '".$o->permissions."' ";
$res =getXbyY($sql);
$row = count($res);

if($row > 0){
	if($res[0]['create_merchants'] == "Yes"){
		$create_merchants = "Yes";
	} 
	if($res[0]['edit_merchants'] == "Yes"){
		$edit_merchants = "Yes";
	} 
	if($res[0]['delete_merchants'] == "Yes"){
		$delete_merchants = "Yes";
	} 
	if($res[0]['create_affiliate'] == "Yes"){
		$create_affiliate = "Yes";
	} 

	if($res[0]['edit_affiliate'] == "Yes"){
		$edit_affiliate = "Yes";
	} 
	if($res[0]['delete_affiliate'] == "Yes"){
		$delete_affiliate = "Yes";
	} 
	if($res[0]['view_transactions'] == "Yes"){
		$view_transactions = "Yes";
	} 
	if($res[0]['add_settlement'] == "Yes"){
		$add_settlement = "Yes";
	} 
	if($res[0]['pending_settlement'] == "Yes"){
		$pending_settlement = "Yes";
	} 
	if($res[0]['approve_settlememt	'] == "Yes"){
		$approve_settlememt = "Yes";
	} 

	if($res[0]['reject_settlememt'] == "Yes"){
		$reject_settlememt = "Yes";
	} 
	if($res[0]['add_dispute'] == "Yes"){
		$add_dispute = "Yes";
	} 


	if($res[0]['pending_dispute'] == "Yes"){
		$pending_dispute = "Yes";
	} 
	if($res[0]['approve_dispute'] == "Yes"){
		$approve_dispute = "Yes";
	} 
	if($res[0]['reject_dispute'] == "Yes"){
		$reject_dispute = "Yes";
	} 
	if($res[0]['view_chargeback	'] == "Yes"){
		$view_chargeback = "Yes";
	} 

	if($res[0]['add_refund'] == "Yes"){
		$add_refund = "Yes";
	} 
	if($res[0]['pending_refund'] == "Yes"){
		$pending_refund = "Yes";
	} 

	if($res[0]['approve_refund'] == "Yes"){
		$approve_refund = "Yes";
	} 
	if($res[0]['reject_refund'] == "Yes"){
		$reject_refund = "Yes";
	} 

}




} else {
	if ($ajax_logout == 1) {
		$result['ajax_logout'] = 1;
	} else {
		header("location:login.php?msgid=2");
	}
}
?>