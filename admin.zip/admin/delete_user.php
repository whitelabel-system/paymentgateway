<?php
session_start();
include"include.php";
include"session.php";

if ($_POST['updte']=="1") {
	
$sql="DELETE FROM users WHERE user_id='".$_POST['id']."'  ";
$res = setXbyY($sql);
$result['error']="1";
$result['error_msg']="User deleted successfully";

}else{
	$result['error']="0";
}
echo json_encode($result);
?>