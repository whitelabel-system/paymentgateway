<?php
session_start();
include"include.php";
include"session.php";
$page_name="ledger_list";

$recharge_page = 1;
$tables = 1;

// pt($_POST);pt($_GET);
## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$length = $_POST['length'];

if ($row == "") {
    $row = 0;
}

if ($length == "") {
    $length = 10;
}

$trigger_from_date = "1=1";
$trigger_to_date = "1=1";
$trigger_user_id = "1=1";

if (isset($_SESSION['ledger_search'])) {

    if (isset($_SESSION['ledger_search']['from_date'])) {
$trigger_from_date = "transaction_date >= '" . $_SESSION['ledger_search']['from_date']." 00:00:00'";
    }
    if (isset($_SESSION['ledger_search']['to_date'])) {
$trigger_to_date = "transaction_date <= '" . $_SESSION['ledger_search']['to_date']." 23:59:59'";
    }
    if (isset($_SESSION['ledger_search']['user_id'])) {
        $trigger_user_id = "user_id='".$_SESSION['ledger_search']['user_id']."'  ";
    }
}

$triggers = $trigger_user_id . " and " . $trigger_from_date . " and " . $trigger_to_date;

$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value
//pt($_POST);

$sql_total = "Select count(wallet_id) as total_transactions from wallet where transaction_type !='Commission' and $triggers  ";
$res_total = getXbyY($sql_total);

$sql_transactions = "Select * from wallet where transaction_type !='Commission' and $triggers order by wallet_id ASC limit $row ,$length";
//$sql_transactions = "Select * from wallet where user_id = ".$o->user_id." order by transaction_date DESC";
$res_transactions = getXbyY($sql_transactions);
$row_transactions = count($res_transactions);

if ($row_transactions > 0) {

    for ($i = 0; $i < $row_transactions; $i++) {
        $class = transaction_type($res_transactions[$i]['transaction_type']);
        if ($class == "red") {
            $sign = "-";
        } else {
            $sign = "+";
        }
       
        $ttype=$res_transactions[$i]['transaction_type'];
        $data[] = array(
            "transaction_date" => format_date($res_transactions[$i]['transaction_date']),
            "user_details" => $res_transactions[$i]['user_name'],
            "transaction_detail" => $res_transactions[$i]['transaction_details'],
            "transaction_type" => $res_transactions[$i]['transaction_type'],
 
            // "api" => $res_transactions[$i]['api_name'],
            "user_old_balance" => "<i class='fa fa-rupee-sign'></i> " . $res_transactions[$i]['user_old_balance'],
            "amount" => "<span class=" . $class . ">" . $sign . "<i class='fa fa-rupee-sign'></i> " . $res_transactions[$i]['amount'] . "</span>",
            "user_new_balance" => "<i class='fa fa-rupee-sign'></i> " . $res_transactions[$i]['user_new_balance'],
            "status" => $res_transactions[$i]['status'],
        );
    }
} else {
    $data = array();
}

## Response
$response = array(
    "draw" => intval($draw),
    "iTotalRecords" => $res_total[0]['total_transactions'],
    "iTotalDisplayRecords" => $res_total[0]['total_transactions'],
    "aaData" => $data,
);

echo json_encode($response);


?>