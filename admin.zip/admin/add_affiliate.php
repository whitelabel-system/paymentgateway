 <?php
session_start();
include "include.php";
include "session.php";


if (isset($_GET['aid'])) {
	$o1->user_id = $_GET['aid'];
} else {
	$o1->user_id = 0;
}
if ($o1->user_id > 0) {
	$o1 = $factory->get_object($o1->user_id, "users", "user_id");
} else {
	$o1->is_active = 1;
}



include "includes/header.php";
include "html/add_affiliate.php";
include "includes/footer.php";
include "js/add_affiliate.js";
?>