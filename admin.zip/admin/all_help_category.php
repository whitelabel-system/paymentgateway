<?php
session_start();
include"include.php";
include"session.php";
$page_name="all_help_category";


$tables = '1';

$sql = "select * from help_category  order by category_name ";
$res = getXbyY($sql);
$rows = count($res);

include "includes/header.php";
include "html/all_help_category.php";
include "includes/footer.php";
include 'js/all_help_category.js';
?>