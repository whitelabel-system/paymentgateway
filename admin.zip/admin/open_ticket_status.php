<?php
session_start();
include"include.php";
include"session.php";
$page_name="update_ticket_status";

if ($_POST['updte']=="1") {
	$o1->ticket_id = $_POST['ticket_id'];
	$o1 = $factory->get_object($o1->ticket_id , "tickets" , "ticket_id");
$o1->status="Reply";
	$o1->ticket_id =$updater->update_object($o1 , "tickets");
$result['error_msg']="Ticket Status Opened";
$result['error']="0";
}else{
	$result['error']="1";
	$result['error_msg']="Something went wrong please try again";
}
echo json_encode($result);
?>