<?php
session_start();
include"include.php";
include"session.php";
$page_name="save_user_currency";
 if ($_POST['updte'] ==1) {

	$user=$_POST['id'];
	$currency=$_POST['currency'];
	$status=$_POST['status'];
	$sql="Select * from user_currency where user_id='".$user."' and currency ='".$_POST['currency']."' ";
	$res=getXbyY($sql);
	$row = count($res);
	if ($row =="0" ) {
		$o2->user_id = $user;
		
			$o2->service_id = $res_services[$i]['service_id'];
			$o2->currency = $_POST['currency'];
			$o2->status = 'No';
			$o2->is_active = '1';
			$o2->created_at = todaysDate();
			$o2->updated_at = todaysDate();
			$o2->user_currency_id = $insertor->insert_object($o2, "user_currency");
		
	}
	$sql_update="update user_currency set status='".$status."' where user_id='".$user."' and currency='".$currency."' ";
	$res_update=setXbyY($sql_update);
	$row_update=count($res_update);
	

	$result['error']=1;
	

} else {

	$result['error']=0;
	
}

echo json_encode($result);

?>