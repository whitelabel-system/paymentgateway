<?php
session_start();
include"include.php";
include"session.php";
$page_name="withdrawal_setting";
$tables = '1';
if (isset($_GET['aid'])) {
	$o1->country_id = $_GET['aid'];
}
if ($o1->country_id > "0") {
	$o1 = $factory->get_object($o1->country_id , "countries" , "country_id");
}
// pt($o1);
$sql = "Select * from countries ";
$res = getXbyY($sql);
$row = count($res);
include 'includes/header.php';
include 'html/withdrawal_setting.php';
include 'includes/footer.php';
include 'js/withdrawal_setting.js';
?>