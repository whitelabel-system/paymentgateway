<?php
session_start();

include "include.php";
include "session.php";

if (isset($_POST['kyc_updte'])) {
	$updte = $_POST['kyc_updte'];
} else {
	$updte = 0;
}



if ($updte == 1) {
$user_id = $_POST['user_id'];
	

	if ($_FILES['domain_doc']['name'] != "") {
		$o2->domain_type = $_POST['domain_type'];
		$tmpfile = $_FILES['domain_doc']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['domain_doc']['name']);
		$destination = $user_id . "_" . $o2->domain_type . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->domain_doc = $destination;
		
	}
	if ($_FILES['processing_statement_doc']['name'] != "") {
	$o2->processing_statement = $_POST['processing_statement'];
		$tmpfile = $_FILES['processing_statement_doc']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['processing_statement_doc']['name']);
		$destination = $user_id . "_" . $o2->processing_statement . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->processing_statement_doc = $destination;
		
	}
	$o2->user_id = $user_id;
	$o2->upload_date = todaysDate();
	$o2->is_active = $_POST['is_active'];
	$o2->status = "Pending";
	if ($_FILES['kyc_file1']['name'] != "") {
		$o2->kyc_doc1 = $_POST['kyc_doc1'];
		$tmpfile = $_FILES['kyc_file1']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['kyc_file1']['name']);
		$destination = $user_id . "_" . $o2->kyc_doc1 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->kyc_file1 = $destination;
		
	}
	if ($_FILES['kyc_file2']['name'] != "") {
		$o2->kyc_doc2 = $_POST['kyc_doc2'];
		$tmpfile = $_FILES['kyc_file2']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['kyc_file2']['name']);
		$destination = $user_id . "_" . $o2->kyc_doc2 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->kyc_file2 = $destination;
		
	}
	if ($_FILES['kyc_file3']['name'] != "") {
		$o2->kyc_doc3 = $_POST['kyc_doc3'];
		$tmpfile = $_FILES['kyc_file3']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['kyc_file3']['name']);
		$destination = $user_id . "_" . $o2->kyc_doc2 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->kyc_file3 = $destination;
		
	}
	if ($_FILES['kyc_file4']['name'] != "") {
		$o2->kyc_doc4 = $_POST['kyc_doc4'];
		$tmpfile = $_FILES['kyc_file4']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['kyc_file4']['name']);
		$destination = $user_id . "_" . $o2->kyc_doc2 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->kyc_file4 = $destination;
		
	}
	if ($_FILES['kyc_file5']['name'] != "") {
		$o2->kyc_doc5 = $_POST['kyc_doc5'];
		$tmpfile = $_FILES['kyc_file5']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['kyc_file5']['name']);
		$destination = $user_id . "_" . $o2->kyc_doc2 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->kyc_file5 = $destination;
		
	}

	$o2->address_doc1 = $_POST['address_doc1'];
	$o2->address_doc2 = $_POST['address_doc2'];
	$o2->address_doc3 = $_POST['address_doc3'];

	if ($_FILES['address_file']['name'] != "") {
		$o2->address_doc = $_POST['address_doc'];
		$tmpfile = $_FILES['address_file']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['address_file']['name']);
		$destination = $user_id . "_" . $o2->address_doc . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->address_file = $destination;

	}
	if ($_FILES['address_file1']['name'] != "") {
		$o2->address_doc1 = $_POST['address_doc1'];
		$tmpfile = $_FILES['address_file1']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['address_file1']['name']);
		$destination = $user_id . "_" . $o2->address_doc1 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->address_file1 = $destination;

	}
	if ($_FILES['address_file2']['name'] != "") {
		$o2->address_doc2 = $_POST['address_doc2'];
		$tmpfile = $_FILES['address_file2']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['address_file2']['name']);
		$destination = $user_id . "_" . $o2->address_doc2 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->address_file2 = $destination;

	}
	if ($_FILES['address_file3']['name'] != "") {
		$o2->address_doc3 = $_POST['address_doc3'];
		$tmpfile = $_FILES['address_file3']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['address_file3']['name']);
		$destination = $user_id . "_" . $o2->address_doc3 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->address_file3 = $destination;

	}

	if ($_FILES['company_file']['name'] != "") {
	$o2->company_doc = $_POST['company_doc'];
		$tmpfile = $_FILES['company_file']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_file']['name']);
		$destination = $user_id . "_" . $o2->company_doc . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_file = $destination;

	}
	if ($_FILES['company_file1']['name'] != "") {
	$o2->company_doc1 = $_POST['company_doc1'];
		$tmpfile = $_FILES['company_file1']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_file1']['name']);
		$destination = $user_id . "_" . $o2->company_doc1 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_file1 = $destination;

	}

	if ($_FILES['company_file2']['name'] != "") {
	$o2->company_doc2 = $_POST['company_doc2'];
		$tmpfile = $_FILES['company_file2']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_file2']['name']);
		$destination = $user_id . "_" . $o2->company_doc2 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_file2 = $destination;

	}
	if ($_FILES['company_file3']['name'] != "") {
	$o2->company_doc3 = $_POST['company_doc3'];
		$tmpfile = $_FILES['company_file3']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_file3']['name']);
		$destination = $user_id . "_" . $o2->company_doc3 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_file3 = $destination;

	}
	if ($_FILES['company_file4']['name'] != "") {
	$o2->company_doc4 = $_POST['company_doc4'];
		$tmpfile = $_FILES['company_file4']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_file4']['name']);
		$destination = $user_id . "_" . $o2->company_doc4 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_file4 = $destination;

	}
	if ($_FILES['company_file5']['name'] != "") {
	$o2->company_doc5 = $_POST['company_doc5'];
		$tmpfile = $_FILES['company_file5']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_file5']['name']);
		$destination = $user_id . "_" . $o2->company_doc5 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_file5 = $destination;

	}

	if ($_FILES['company_address_file']['name'] != "") {
$o2->company_address_doc = $_POST['company_address_doc'];
		$tmpfile = $_FILES['company_address_file']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_address_file']['name']);
		$destination = $user_id . "_" . $o2->company_address_doc . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_address_file = $destination;

	}
		if ($_FILES['company_address_file1']['name'] != "") {
$o2->company_address_doc1 = $_POST['company_address_doc1'];
		$tmpfile = $_FILES['company_address_file1']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_address_file1']['name']);
		$destination = $user_id . "_" . $o2->company_address_doc1 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_address_file1 = $destination;

	}
		if ($_FILES['company_address_file2']['name'] != "") {
$o2->company_address_doc2 = $_POST['company_address_doc2'];
		$tmpfile = $_FILES['company_address_file2']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_address_file2']['name']);
		$destination = $user_id . "_" . $o2->company_address_doc2 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_address_file2 = $destination;

	}
		if ($_FILES['company_address_file3']['name'] != "") {
$o2->company_address_doc3 = $_POST['company_address_doc3'];
		$tmpfile = $_FILES['company_address_file3']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_address_file3']['name']);
		$destination = $user_id . "_" . $o2->company_address_doc3 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_address_file3 = $destination;

	}
		if ($_FILES['company_address_file4']['name'] != "") {
$o2->company_address_doc4 = $_POST['company_address_doc4'];
		$tmpfile = $_FILES['company_address_file4']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_address_file4']['name']);
		$destination = $user_id . "_" . $o2->company_address_doc4 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_address_file4 = $destination;

	}
		if ($_FILES['company_address_file5']['name'] != "") {
$o2->company_address_doc5 = $_POST['company_address_doc5'];
		$tmpfile = $_FILES['company_address_file5']['tmp_name'];
		$source = "./img/";
		$file_extension = explode(".", $_FILES['company_address_file5']['name']);
		$destination = $user_id . "_" . $o2->company_address_doc5 . "." . end($file_extension);
		$thumbnail = 0;
		$newsize = "100";
		$watermark = "";

		uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

		$o2->company_address_file5 = $destination;

	}


	$o2->kyc_id = $insertor->insert_object($o2, "kyc");
	
	header("location:index.php");
} else {
	header("location:index.php?msgid=5");
}
?>