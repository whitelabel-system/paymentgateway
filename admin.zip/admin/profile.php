<?php
session_start();
include"include.php";
include"session.php";
$page ="profile";

$sql = "select * from bank where user_id='".$o->user_id."'";
$res=getXbyY($sql);
$row =count($res);
if($row > 0)
{
	$o1->bank_id = $res[0]['bank_id'];
}else{
	$o1->bank_id =0;
}

if ($o1->bank_id > 0) {
	$o1 = $factory->get_object($o1->bank_id, "bank", "bank_id");
} else {
	$o1->is_active = 1;
}


include "includes/header.php";
include "html/profile.php";
include "includes/footer.php";
include"js/profile.js";
?>