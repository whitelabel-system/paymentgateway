
<?php

include "include.php";


if ($_POST['updte'] == '1') {


    $ifsc = $_POST['ifsc'];

    $api_response = fetch_bank_details($ifsc);
    
    
    $result['bank_details']= " <table class='table'>"
            . "<tr><td> Bank : ".$api_response->BANK ."</td></tr>"
            . "<tr><td> BRANCH :".$api_response->BRANCH ."</td></tr>"
            . "<tr><td> DISTRICT :".$api_response->DISTRICT ."</td></tr>"
            . "<tr><td> ADDRESS :".$api_response->ADDRESS ."</td></tr>"
            . "<tr><td> CITY :".$api_response->CITY ." " . $api_response->CENTRE ."</td></tr>"
            . "<tr><td> STATE :".$api_response->STATE ." ( M :".$api_response->CONTACT.") </td></tr>"
            
            . "</table>";

  
}

echo json_encode($result);
?>
