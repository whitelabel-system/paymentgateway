<?php
session_start();
include 'include.php';
include 'session.php';

$tables = '1';

$trigger ="1=1";
if (isset($_GET['type'])) {
	$filter =$_GET['type'];
}
if ($filter == "Merchant") {
$trigger ="user_type='Merchant' ";
}else if ($filter=="Affiliate") {
$trigger ="user_type='Affiliate'";
}
$sql = "select * from users where user_type!='Admin' and $trigger order by user_id Desc";
$res = getXbyY($sql);
$row = count($res);


include "includes/header.php";
include "html/users.php";
include "includes/footer.php";
include "js/users.js";
?>