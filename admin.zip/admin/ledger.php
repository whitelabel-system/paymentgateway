<?php
session_start();
include"include.php";
include"session.php";
$page_name="ledger";
unset($_SESSION['ledger_search']);
$tables = '1';

$sql ="Select sum(total_amount) , transaction_date ,status  from wallet group by date(transaction_date) , status ";
$res =getXbyY($sql);
$row = count($res);

$dd = todaysDate();
include "includes/header.php";
include "html/ledger.php";
include "includes/footer.php";
include "js/ledger.js";
?>