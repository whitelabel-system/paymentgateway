<?php
session_start();
include"include.php";
include"session.php";
$page_name = "user_security";

$user_id = $_GET['aid'];

$sql = "Select * from user_security where user_id ='".$user_id."' ";
$res = getXbyY($sql);
$row = count($res);
if ($row >"0") {
	$o1 = $factory->get_object($res[0]['user_security_id'] , "user_security","user_security_id");
}

include "includes/header.php";
include "html/user_security.php";
include "includes/footer.php";
include "js/user_security.js";
?>