<?php
session_start();
include"include.php";
include"session.php";

$o1->user_id = $_GET['aid'];
$o1= $factory->get_object($o1->user_id , "users","user_id");



    $message = "Congratulations! Your Account on E-secure Payment is active now.  url : http://esecure_payment.in/ <br/> Username: " . $o->mobile . " or " . $o1->email;

        sendmail($email_from, $o1->email,"E-secure Payment  Account is active now." , $message);
    header("location:users.php?type=Merchant");



?>