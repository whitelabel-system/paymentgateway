<?php

session_start();
include "include.php";
include "session.php";


if ($updte == 1) {
    if (isset($_POST['ticket_id'])) {
        $o1->ticket_id = $_POST['ticket_id'];
    } else {
        $o1->ticket_id = 0;
    }
    
    if ($o1->ticket_id > 0) {
        $o1 = $factory->get_object($o1->ticket_id, "tickets", "ticket_id");
    }
    
    $o2->user_id = $o->user_id;
    $o2->name = $o->name;
    $o2->email = $o->email;
    $o2->mobile = $o->mobile;
    $o2->subject = $o1->subject;
    $o2->assigned_user = $o1->name;
    $o2->parent_id = $o1->ticket_id;
    $o2->ticket_number = $o1->ticket_number;
    $o2->message = $_POST['message'];
    $o2->ticket_type = $o1->ticket_type;
    $o2->status = "Reply";
    $o2->is_read = "No";
    $o2->sent_by = $o->user_type;
    $o2->is_active = 1;
    
    $o1->status = $_POST['ticket_status'];
    $o1->is_read = "Yes";
    $o1->assigned_user = $o->name ;
    
  

 


    if ($o1->ticket_id > 0) {
        $o2->created_at = todaysDate();
        $o2->updated_at = todaysDate();
        $o2->ticket_id = $insertor->insert_object($o2, "tickets");
        $o1->updated_at = todaysDate();
        $o1->ticket_id = $updater->update_object($o1, "tickets");
        $result['error_msg'] = "Ticket Updated Successfully";
    }
    // pt($_FILES);
     if ($_FILES['ticket_attachment']['name'] != "") {

$sql = "Select * from  ticket_attachment where ticket_id='".$o1->ticket_id."' ";
$res =getXbyY($sql);
$row = count($res);


$o5->send_by = $o->user_type;
$o5->ticket_id= $o1->ticket_id;
$o5->is_active ='1';
            $ext = explode(".", $_FILES['ticket_attachment']['name']);



            $tmpfile = $_FILES['ticket_attachment']['tmp_name'];

            $source = "../img/";



            $destination = $row."_".$o1->ticket_number . "." . end($ext);

            $thumbnail = 0;

            $newsize = 250;

            $watermark = '';



            uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

            $o5->ticket_file = $destination;
        $o5->ticket_attachment_id = $insertor->insert_object($o5, "ticket_attachment");


        }   
    $result['error'] = 0;
   
} else {
    $result['error'] = 1;
    $result['error_msg'] = "Something went wrong. Please try again";
}

echo json_encode($result);
?>