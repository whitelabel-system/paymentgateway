<?php
session_start();
include"include.php";
include"session.php";
if ($_POST['updte']=="1") {
$o1->wallet_id = $_POST['wallet_id'];
$sql ="select * from chargeback where wallet_id='".$o1->wallet_id."' and is_active='1' ";
$res = getXbyY($sql);
$row = count($res);
if ($row =="0") {


$o1 = $factory->get_object($o1->wallet_id , "wallet" , "wallet_id");
$o2->wallet_id = $o1->wallet_id;
$o3 = $factory->get_object($o1->user_id , "users" , "user_id");
$o2->user_id = $o1->user_id;
$o2->chargeback = $_POST['chargeback_resolution'];
$o2->chargeback_date =todaysDate();
$o2->chargeback_status ="Pending";
$o2->is_active="1";
$o2->transaction_number = $o1->ref_number;
$o2->chargeback_id  = $insertor->insert_object($o2, "chargeback");
$o3->disputed_amount =$o3->disputed_amount + $o1->amount; 
$o3->user_id =$updater->update_object($o3, "users");

insert_notifications($o2->user_id , "Chargeback Added against transaction " .$o2->transaction_number , "chargeback");
$name=$o3->name;

 $email_to = $o3->email;
		$email_from = $o->email;
		$email_subject = "Chargeback Added";
		include '../mails/chargeback_mail.php';
     sendmail($email_from, $email_to, $email_subject, $email_message);	

$result['error']="1";
$result['error_msg']="Chargeback added successfully";	
}else{
	$result['error']="0";
	$result['error_msg']="Chargeback already added for this transaction";
}
}else{
	$result['error']="0";
}



echo json_encode($result);

?>