 <?php
 session_start();
 include"include.php";
 include"session.php";
 $page_name="save_permissions";

 if ($_POST['updte']=="1") {
 	if ($_POST['permission_id ']>"0") {
 		$o1->permission_id  = $_POST['permission_id '];
 		$o1 = $factory->get_object($o1->permission_id,"permissions","permission_id");
 	}else{
 		$o1->permission_id  ="0";
 	}
 	$o1->user_id =$_POST['user_id'];
 	$o1->permission_name =$_POST['permission_name'];
 	$o1->create_merchants = $_POST['create_merchants'];
 	$o1->edit_merchants = $_POST['edit_merchants'];
 	$o1->delete_merchants = $_POST['delete_merchants'];
 	$o1->create_affiliate = $_POST['create_affiliate'];
 	$o1->edit_affiliate = $_POST['edit_affiliate'];
 	$o1->delete_affiliate = $_POST['delete_affiliate'];

 	$o1->view_transactions = $_POST['view_transactions'];
 	$o1->add_settlement = $_POST['add_settlement'];
 	$o1->pending_settlement = $_POST['pending_settlement'];
 	$o1->approve_settlememt = $_POST['approve_settlememt'];
 	$o1->reject_settlememt = $_POST['reject_settlememt'];
 	$o1->add_dispute = $_POST['add_dispute'];
 	$o1->pending_dispute = $_POST['pending_dispute'];
 	$o1->approve_dispute = $_POST['approve_dispute'];
 	$o1->reject_dispute = $_POST['reject_dispute'];
 	$o1->view_chargeback =$_POST['view_chargeback'];
 	$o1->add_refund =$_POST['add_refund'];
 	$o1->pending_refund =$_POST['pending_refund'];
 	$o1->approve_refund = $_POST['approve_refund'];
 	$o1->reject_refund = $_POST['reject_refund'];
 	
 	$o1->is_active=$_POST['is_active'];
 	$o1->other=$_POST['other'];
 	$o1->fee_type=$_POST['fee_type'];
 	if ($o1->permission_id  >"0") {
 		$o1->permission_id  = $updater->update_object($o1, "permissions");
 		$result['error_msg']="Permissions Updated Successfully";
 	}else{
 		$o1->permission_id   = $insertor->insert_object($o1, "permissions");
 		$result['error_msg']="Permissions Added Successfully";
 	}
 	$result['error']="1";

 }else{
 	$result['error']="0";
 }



 echo json_encode($result);
 ?>
