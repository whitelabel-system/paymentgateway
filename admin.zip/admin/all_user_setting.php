<?php
session_start();
include"include.php";
include"session.php";
$page_name = "all_user_setting";
$tables = '1';
$sql="Select * from user_setting ";
$res = getXbyY($sql);
$rows=count($res);

include"includes/header.php";
include"html/all_user_setting.php";
include"includes/footer.php";
?>