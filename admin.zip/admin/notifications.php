<?php

session_start();

include "include.php";
include "session.php";

$ajax_logout = 1;

if($updte == 1){
    $sql = "Select count(notification_id) as notifications from notifications where user_id='".$o->user_id."' and is_active = 1 and is_read = 'No'";
    $res = getXbyY($sql);
    
    $sql_requests = "Select Count(request_money_id) as requests from request_money where requested_user_id='".$o->user_id."' and  is_active = 1 and status = 'Pending'   ";
    $res_request = getXbyY($sql_requests);
    $result['notifications'] = $res[0]['notifications'];
    $result['amount_balance'] = $o->amount_balance;
    $result['pending_request_money'] = $res_request[0]['requests'];
}

echo json_encode($result);
?>

