<?php
session_start();
include 'include.php';
include 'session.php';
//pt($_POST);
if($updte > 0){
	$sql_user = "select amount_balance from users where user_id='".$_POST['uid']."'";
	$res_user =getXbyY($sql_user);
	$row_user =count($res_user);
	if($row_user > 0){
		$result['balance'] = $res_user[0]['amount_balance'];
	}else{
		$result['balance'] = '-';
	}
    $result['error'] = '0';
	$result['error_msg'] = 'User Current Balance';
}else{

	$result['error'] = '1';
	$result['error_msg'] = 'Something Went Wrong';
}



echo json_encode($result);

?>