<?php

session_start();

include "include.php";
include "session.php";
$page_name ="index";
$month1 = date("F") . "-" . date('Y');
$sql_check = "SELECT month_year AS Month, SUM(amount) AS total FROM wallet  where transaction_type = 'New Payment' and status='success'  GROUP BY month_year  ";
$res_1 = getXbyY($sql_check);
$rows_1 = count($res_1);

$txnChartLabels = '[';
$txnChartValues = '[';
for ($i = 0; $i < $rows_1; $i++) {
	$txnChartLabels .= '"' . $res_1[$i]['Month'] . '"';
	$txnChartValues .= '"' . $res_1[$i]['total'] . '"';
	if ($i < ($rows_1 - 1)) {
		$txnChartLabels .= ',';
		$txnChartValues .= ',';
	}
}
$txnChartLabels .= ']';
$txnChartValues .= ']';
 

 $sql_commission="SELECT month_year AS Month, SUM(amount) AS amount , sum(total_amount) as total_amount FROM wallet  where (transaction_type='Commission') and status='success'  GROUP BY month_year ";
$res_commission = getXbyY($sql_commission);
$row_commission = count($res_commission);
$month = '[';
$commission_value = '[';
for ($i = 0; $i < $row_commission; $i++) {
	$month .= '"' . $res_commission[$i]['Month'] . '"';
	$commission_value .= '"' . $res_commission[$i]['amount'] . '"';
	if ($i < ($row_commission - 1)) {
		$month .= ',';
		$commission_value .= ',';
	}
}
$month .= ']';
$commission_value .= ']';
// pt($value);
// pt($txnChartValues);

 $sql_top_revenue = "SELECT sum(amount) as amount ,user_id from wallet where transaction_type='New Payment' and status='Success' GROUP BY user_id order by sum(amount) DESC limit 0,5 ";
$res_top_revenue = getXbyY($sql_top_revenue);
$row_top_revenue = count($res_top_revenue);

$user_detail = '[';
$value = '[';
for ($i = 0; $i < $row_top_revenue; $i++) {
	$user_detail .= '"' .get_user_name_id($res_top_revenue[$i]['user_id']) . '"';
	$value .= '"' . $res_top_revenue[$i]['amount'] . '"';
	if ($i < ($row_top_revenue - 1)) {
		$user_detail .= ',';
		$value .= ',';
	}
}
$user_detail .= ']';
$value .= ']';

$sql_affiliate = "SELECT SUM(A.amount) AS amount , SUM(A.total_amount) AS total_amount , A.status FROM wallet AS A LEFT JOIN users AS B ON(A.user_id = B.user_id) WHERE B.user_type='Affiliate' AND A.month_year='".$month1."' AND A.transaction_type='New Payment' GROUP BY A.status ";
$res_affiliate = getXbyY($sql_affiliate);
$row_affiliate = count($res_affiliate);

$affiliate_status = '[';
$affiliate_value = '[';
for ($i = 0; $i < $row_affiliate; $i++) {



	$affiliate_status .= '"' .$res_affiliate[$i]['status'] . '"';
	$affiliate_value .= '"' . $res_affiliate[$i]['amount'] . '"';
	
	if ($i < ($row_affiliate - 1)) {
		$affiliate_status .= ',';
		$affiliate_value .= ',';
	}
}
$affiliate_status .= ']';
$affiliate_value .= ']';


$sql_merchant = "SELECT SUM(A.amount) AS amount , SUM(A.total_amount) AS total_amount , A.status FROM wallet AS A LEFT JOIN users AS B ON(A.user_id = B.user_id) WHERE B.user_type='Merchant' and A.month_year='".$month1."' AND A.transaction_type='New Payment' GROUP BY A.status ";
$res_merchant = getXbyY($sql_merchant);
$row_merchant = count($res_merchant);

$merchant_status = '[';
$merchant_value = '[';
for ($i = 0; $i < $row_merchant; $i++) {



	$merchant_status .= '"' .$res_merchant[$i]['status'] . '"';
	$merchant_value .= '"' . $res_merchant[$i]['amount'] . '"';
	
	if ($i < ($row_merchant - 1)) {
		$merchant_status .= ',';
		$merchant_value .= ',';
	}
}
$merchant_status .= ']';
$merchant_value .= ']';
// pt($affiliate_value);
 $sql_total_amount ="Select sum(amount) as amount , sum(total_amount) as total_amount  from wallet where transaction_type='New Payment' and month_year='".$month1."' ";
$res_total_amount = getXbyY($sql_total_amount);
$commission_amount = $res_total_amount[0]['total_amount']-$res_total_amount[0]['amount'];
$payment_type = ["Commission","Total Payment" ];	
$payment_value = ['"'.$commission_amount.'"' , '"'.$res_total_amount[0]['amount'].'"'];	

$row_payment_value="2";

$res_pay[0]['name']="Commission";
$res_pay[1]['name']="Total Payment";
$res_pay[0]['val']=$commission_amount;
$res_pay[1]['val']=$res_total_amount[0]['amount'];

$payment_type = '[';
$payment_value = '[';
for ($i = 0; $i < $row_payment_value; $i++) {



	$payment_type .= '"' .$res_pay[$i]['name'] . '"';
	$payment_value .= '"' . $res_pay[$i]['val'] . '"';
	
	if ($i < ($row_payment_value - 1)) {
		$payment_type .= ',';
		$payment_value .= ',';
	}
}
$payment_type .= ']';
$payment_value .= ']';
// pt($payment_value);

include "includes/header.php";
include "html/index.php";
include "includes/footer.php";
include"js/index.js";
?>