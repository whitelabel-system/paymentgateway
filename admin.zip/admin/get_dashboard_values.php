<?php
session_start();
include"include.php";
include"session.php";

if ($_POST['updte']=="1") {
	$date = format_date_without_time(todaysDate());
$month = date("F") . "-" . date('Y');
$year = date('Y');
$sql_today="Select sum(total_amount) as total from wallet where transaction_type='New Payment' and date(transaction_date)='".$date."'  ";
$res_today = getXbyY($sql_today);
if ($res_today[0]['total'] !="") {
$result['today_payment']=$res_today[0]['total'];
}else{
	$result['today_payment']="0";
}


$sql_month="Select sum(total_amount) as total from wallet where transaction_type='New Payment' and month_year='".$month."'  ";
$res_month= getXbyY($sql_month);

if ($res_month[0]['total'] !="") {
$result['monthly_payment'] = $res_month[0]['total'];
}else{
$result['monthly_payment'] ="0";
}
$sql_year = "Select sum(total_amount) as total from wallet where transaction_type='New Payment' and year='".$year."'  ";
$res_year = getXbyY($sql_year);
if ($res_year[0]['total'] !="") {
$result['yearly_payment']=$res_year[0]['total'];
}else{
$result['yearly_payment']="0";
}


$sql_pending = "Select sum(total_amount) as total from wallet where transaction_type='New Payment'  and status='Pending'";
$res_pending = getXbyY($sql_pending);
if ($res_pending[0]['total']!="") {
$result['pending_amount'] = $res_pending[0]['total'];
}else{
$result['pending_amount'] = "0";
}


$sql_total_user="Select count(user_id) as total_users from users where user_type!='Admin' ";
$res_total_user = getXbyY($sql_total_user);

if ($res_total_user[0]['total_users']!="") {
$result['total_users'] = $res_total_user[0]['total_users'];
}else{
$result['total_users'] = "0";
}

$sql_total_merchant = "Select count(user_id) as total_merchants from users where  user_type='Merchant' ";
$res_total_merchant = getXbyY($sql_total_merchant);
if ($res_total_merchant[0]['total_merchants']!="") {
$result['total_merchants'] = $res_total_merchant[0]['total_merchants'];
}else{
$result['total_merchants'] ="0";
}



$sql_total_affiliate ="Select count(user_id)  as total_affiliate from users where user_type='Affiliate' ";
$res_total_affiliate = getXbyY($sql_total_affiliate);
if ($res_total_affiliate[0]['total_affiliate']!="") {
$result['total_affiliate'] = $res_total_affiliate[0]['total_affiliate'];
}else{
$result['total_affiliate'] ="0";
}



$sql_total_transaction= "Select count(wallet_id) as total_transaction from wallet where transaction_type='New Payment'  ";
$res_total_transaction=getXbyY($sql_total_transaction);
if ($res_total_transaction[0]['total_transaction']!="") {
$result['total_transaction'] = $res_total_transaction[0]['total_transaction'];
}else{
$result['total_transaction'] ="0";
}



$sql_failed_payment = "Select sum(total_amount) as total from wallet where transaction_type='New Payment' and status='Failed' ";
$res_failed_payment = getXbyY($sql_failed_payment);

if ($res_failed_payment[0]['total']!="") {
$result['failed_payment'] = $res_failed_payment[0]['total'];
}else{
$result['failed_payment'] ="0";
}


$sql_success_payment = "Select sum(total_amount) as total from wallet where transaction_type='New Payment' and status='Success' ";
$res_success_payment = getXbyY($sql_success_payment);
if ($res_success_payment[0]['total']!="") {

$result['success_payment'] = $res_success_payment[0]['total'];
}else{
$result['success_payment'] ="0";
}

$sql_commission ="Select sum(amount) as total from wallet where transaction_type='Commission' and status='Success'  ";
$res_commission = getXbyY($sql_commission);
if ($res_commission[0]['total'] !="") {
$gst = ($res_commission[0]['total']*18)/100;
$tds = ($res_commission[0]['total']*2.5)/100;
}else{
	$gst="0";
	$tds="0";

}
$result['tds_gst']=$gst." / ".$tds;

$result['error']="0";






}else{
$result['error']="1";

}

echo json_encode($result);
?>