<?php
session_start();
include"include.php";
include"session.php";

$tables = '1';
$sql="Select w.*,u.user_id,u.amount_balance from withdrawal_request as w right join users as u on (u.user_id = w.user_id) Where  w.status='Approve' ";
// $sql="Select * from withdrawal_request Where  status='Approve' ";
$res = getXbyY($sql);
$rows=count($res);

// die();
include"includes/header.php";
include"html/approve_settlements.php";
include"includes/footer.php";
?>