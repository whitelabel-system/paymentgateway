<?php
session_start();

include "include.php";
include "session.php";




include "includes/header.php";
include "html/change_password.php";
include "includes/footer.php";
include "js/profile.js";
?>