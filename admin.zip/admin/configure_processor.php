<?php
session_start();
include"include.php";
include"session.php";
$page_name="configure_processor";
if(isset($_GET['aid'])){
	$user_id = $_GET['aid'];
}
if ($user_id>"0") {

}else{
	$user_id="0";
}


$sql = "Select * from user_card_process  where is_active='1' and user_id='".$user_id."' and status='Yes'";
$res = getXbyY($sql);
$rows = count($res);	
$sql_services = "Select * from services where is_active=1";
$res_services = getXbyY($sql_services);
$rows_services = count($res_services);	
 
$sql_user_service = "Select * from user_services where user_id='".$user_id."' and is_active ='1' ";
$res_user_service = getXbyY($sql_user_service);
$row_user_service = count($res_user_service);

 $sql_configure ="Select * from user_process_configure  where user_id = '".$user_id."' ";
 $res_congigure = getXbyY($sql_configure);
 $row_configure = count($res_congigure);
 if ($row_configure >"0") {
 	$o2->user_process_configure_id = $res_congigure[0]['user_process_configure_id'];
 	$o2 = $factory->get_object($o2->user_process_configure_id ,"user_process_configure" , "user_process_configure_id");
 }


if ($_POST['updte']=="1") {
	
	$o1->user_id = $_POST['user_id'];
	$o1->merchant_number = $_POST['merchant_number'];
	$o1->terminal_number = $_POST['terminal_number'];
	$o1->check_digit = $_POST['check_digit'];
	$o1->device_identification = $_POST['device_identification'];
	$o1->top_category = $_POST['top_category'];
	$o1->merchant_category = $_POST['merchant_category'];
	$counts = count($_POST['account_type']);
	$string = '';
	for($i=0 ; $i < $counts ;  $i++){
		$string .= $_POST['account_type'][$i];
		$string .= ',';
	}
	$o1->account_type = $string;
	
	$o1->is_active = "1";
	$o1->user_process_configure_id = $insertor->insert_object($o1, "user_process_configure");
	header("location:choose_user_plan.php?aid=$o1->user_id");
	
}



include "includes/header.php";
include "html/configure_processor.php";
include "includes/footer.php";
include "js/configure_processor.js";
?>