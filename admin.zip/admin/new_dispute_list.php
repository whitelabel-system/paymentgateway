<?php

session_start();
include"include.php";
include"session.php";
$page_name = "dispute_list";

$recharge_page = 1;
$tables = 1;

// pt($_POST);pt($_GET);
## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$length = $_POST['length'];

if ($row == "") {
    $row = 0;
}

if ($length == "") {
    $length = 10;
}

$trigger_from_date = "1=1";
$trigger_to_date = "1=1";
$trigger_user_id = "1=1";
$trigger_ref_number = "1=1";


if (isset($_SESSION['dispute_search'])) {

    if (isset($_SESSION['dispute_search']['from_date'])) {
	$trigger_from_date = "transaction_date >= '" . $_SESSION['payment_search']['from_date'] . " 00:00:00'";
    }
    if (isset($_SESSION['dispute_search']['to_date'])) {
	$trigger_to_date = "transaction_date <= '" . $_SESSION['payment_search']['to_date'] . " 23:59:59'";
    }
    if (isset($_SESSION['dispute_search']['user_id'])) {
	$trigger_user_id = "user_id='" . $_SESSION['payment_search']['user_id'] . "'  ";
    }

    if (isset($_SESSION['dispute_search']['ref_number'])) {
	$trigger_ref_number = "ref_number='" . $_SESSION['payment_search']['ref_number'] . "'  ";
    }
    
    if (isset($_SESSION['dispute_search']['status'])) {
        if($_SESSION['dispute_search']['status'] != 'All'){
            $trigger_status = "dispute_status='" . $_SESSION['dispute_search']['status']."'";
        }

    }
}

$triggers = $trigger_user_id . " and " . $trigger_from_date . " and " . $trigger_to_date . " and " . $trigger_ref_number;

$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value
//pt($_POST);

$sql_total = "Select count(wallet_id) as total_transactions from wallet where $triggers";
$res_total = getXbyY($sql_total);

$sql_transactions = "Select * from wallet where $triggers order by wallet_id ASC limit $row ,$length";
//transaction_type='New Payment' and status='Success' and status='Pending' and 
//$sql_transactions = "Select * from wallet where user_id = ".$o->user_id." order by transaction_date DESC";
$res_transactions = getXbyY($sql_transactions);
$row_transactions = count($res_transactions);

if ($row_transactions > 0) {

    for ($i = 0; $i < $row_transactions; $i++) {
	$class = transaction_type($res_transactions[$i]['transaction_type']);
	if ($class == "red") {
	    $sign = "-";
	} else {
	    $sign = "+";
	} 

	$sr_no = ($i + 1) + $row;

	$action = get_dispute_status($res_transactions[$i]['wallet_id']).'<br/><a class="btn btn-primary btn-sm" style="color:#fff" onclick=\'add_dispute("' . $res_transactions[$i]['wallet_id'] . '")\' >Add Dispute</a>';
	
	
	$ttype = $res_transactions[$i]['transaction_type'];
	$data[] = array(
	    "sr_no" => $sr_no,
	    "transaction_type" => $res_transactions[$i]['transaction_type'],
	    "user_details" => $res_transactions[$i]['user_name'],
	    "transaction_number" => $res_transactions[$i]['transaction_details'] . "<br>" . $res_transactions[$i]['ref_number'],
	    "total_amount" => "<i class='fa fa-rupee-sign'></i> " . $res_transactions[$i]['total_amount'],
	    "amount" => "<i class='fa fa-rupee-sign'></i> " . $res_transactions[$i]['amount'],
	    "transaction_date" => format_date($res_transactions[$i]['transaction_date']),
	    "status" => $res_transactions[$i]['status'],
	    "action" => $action,
		// "api" => $res_transactions[$i]['api_name'],
	);
    }
} else {
    $data = array();
}

## Response
$response = array(
    "draw" => intval($draw),
    "iTotalRecords" => $res_total[0]['total_transactions'],
    "iTotalDisplayRecords" => $res_total[0]['total_transactions'],
    "aaData" => $data,
);

echo json_encode($response);
?>