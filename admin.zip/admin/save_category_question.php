<?php
session_start();
include"include.php";
include"session.php";
$page_name="save_category_question";

if ($_POST['updte']=="1") {

	$o1->category_answer = $_POST['category_answer'];
	$o1->category_question = $_POST['category_question'];
	$o1->category_name = $_POST['category_name'];
	$o1->is_active = $_POST['is_active'];
	$o1->help_category_id =$_POST['help_category_id'];
	if ($_POST['help_category_question_id'] > 0) {
		$o1->help_category_question_id = $_POST['help_category_question_id'];  
		$o1->help_category_question_id= $updater->update_object($o1, "help_category_question");
		
		$result['error_msg']="Category Question Updated Successfully";
	}else{
		$o1->help_category_question_id = $insertor->insert_object($o1, "help_category_question");
		$result['error_msg']="Category Question Added Successfully";
	}
	$result['error']="1";
	
}else{
	$result['error']="0";
}
echo json_encode($result);

?>