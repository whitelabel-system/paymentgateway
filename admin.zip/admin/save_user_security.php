<?php

session_start();
include "include.php";
include "session.php";


if ($updte == 1) {
    if (isset($_POST['user_security_id'])) {
        $o2->user_security_id = $_POST['user_security_id'];
    } else {
        $o2->user_security_id = 0;
    }
    
    if ($o2->user_security_id > 0) {
        $o2 = $factory->get_object($o2->user_security_id, "user_security", "user_security_id");
    }
$count_block_ip_address = count($_POST['block_ip_address']);
$count_block_card = count($_POST['block_card']);
$count_block_country_id =count($_POST['block_country_id']);
$count_email = count($_POST['email']);
$count_domain =  count($_POST['domain']);
$count_card_digit = count($_POST['card_digit']);
$count = max($count_domain , $count_card_digit , $count_email , $count_block_country_id , $count_block_card , $count_block_ip_address);
for ($i=0; $i <$count ; $i++) { 
   $o2->user_id = $_POST['user_id'];
    $o2->email = $_POST['email'][$i];
    $o2->block_ip_address = $_POST['block_ip_address'][$i];
    $o2->block_card = $_POST['block_card'][$i];
    $o2->block_country_id = $_POST['block_country_id'][$i];
    $o2->card_digit = $_POST['card_digit'][$i];
    $o2->domain = $_POST['domain'][$i];
    $o2->transaction_amount_limit = $_POST['transaction_amount_limit'];
    $o2->transaction_per_day = $_POST['transaction_per_day'];
    $o2->is_active = 1;
     $o2->user_security_id = $insertor->insert_object($o2, "user_security");
        $result['error_msg'] = "User Security Added Successfully";
        unset($o2->user_security_id);
}


    // if ($o2->user_security_id > 0) {
    //     $o2->updated_at = todaysDate();
    //     $o2->user_security_id = $updater->update_object($o2, "user_security");
    //     $result['error_msg'] = "User Security Updated Successfully";
    // }else{

    //     $o2->user_security_id = $insertor->insert_object($o2, "user_security");
    //     $result['error_msg'] = "User Security Added Successfully";

    // }
    $result['user_id'] = $o2->user_id;    
    $result['error'] = 1;
   
} else {
    $result['error'] = 0;
    $result['error_msg'] = "Something went wrong. Please try again";
}

echo json_encode($result);
?>