<?php
session_start();

include "include.php";
include "session.php";

if (isset($_GET['aid'])) {
	$o1->credit_card_processor_id = $_GET['aid'];
} else {
	$o1->credit_card_processor_id = 0;
}

if ($o1->credit_card_processor_id > 0) {
	$o1 = $factory->get_object($o1->credit_card_processor_id, "credit_card_processor", "credit_card_processor_id");
} else {
	$o1->is_active = 1;
}

if ($updte == 1) {
	$o1->processor_name = $_POST['processor_name'];
	$o1->is_active = $_POST['is_active'];

	if ($o1->credit_card_processor_id > 0) {
		$o1->credit_card_processor_id = $updater->update_object($o1, "credit_card_processor");
	} else {
		$o1->credit_card_processor_id = $insertor->insert_object($o1, "credit_card_processor");
	}

	header("location:credit_card_processor.php?msgid=3");
}

include "includes/header.php";
include "html/add_credit_card_processor.php";
include "includes/footer.php";
?>