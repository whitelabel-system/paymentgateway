<?php

session_start();

include 'include.php';


if ($_POST['forget_email'] != '') {

    $sql = "select * from users where email ='" . $_POST['forget_email'] . "' and user_type='Admin' and is_active ='1'";
    $res = getXbyY($sql);
    $row = count($res);
    if ($row == '1') {
        $o1 = $factory->get_object($res[0]['user_id'], "users", "user_id");
        $password = reference_number();
        $email = $o1->email;
        $o1->password = cpassword($password);
        $subject = "Neope Business: New password";
        $message = "Your new password is :" . $password;

        $o1->user_id = $updater->update_object($o1, "users");
        sendmail($email_from, $email, $subject, $message);
        $result['error'] = '0';
        $result['error_msg'] = "New password sent on your email address";
    } else {
        $result['error'] = '1';
        $result['error_msg'] = "No user found";
    }
} else {
    $result['error'] = '1';
    $result['error_msg'] = "Please enter valid email";
}

echo json_encode($result);
?>