
<?php
session_start();

include "include.php";
include "session.php";

if (isset($_GET['aid'])) {
    $o1->notice_board_id = $_GET['aid'];
    if($o1->notice_board_id > 0){
    $sql_delete = "delete from notice_board where notice_board_id ='".$o1->notice_board_id."'";
    $set_delete = setXbyY($sql_delete);

    header("location:notice_board.php");
    
	}else{
        header("location:notice_board.php?msgid=");
    }
}else{
    header("location:notice_board.php?msgid=");
	}


?>