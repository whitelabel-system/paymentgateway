<?php
session_start();
include"include.php";
include'session.php';
$page_name="user_bank";

if (isset($_GET['aid'])) {
	$user_id = $_GET['aid'];
}else{
	$user_id="0";

}
if ($user_id > "0") {
	$o1= $factory->get_object($user_id,"users","user_id");
	$sql = "Select * from bank where user_id='".$user_id."' ";
	$res = getXbyY($sql);
	$row =count($res);
} 

include "includes/header.php";
include "html/user_bank.php";
include "includes/footer.php";
// include "js/user_bank.js";

?>