<?php
session_start();
include"include.php";
include"session.php";

if ($_POST['updte']=="1") {
	$o6 = $factory->get_object($_POST['user_id'] ,"users","user_id");
$amount_limit = $o6->amount_balance -$o6->disputed_amount;
	if ($_POST['amount'] > $amount_limit) {
		$result['error']="1";
		$result['error_msg']="Insufficient Balance";
		echo json_encode($result);
		die();
	}	
	if ( $_POST['amount'] < $o6->minimum_withdrawal_amount ) {
	$result['error']="1";
		$result['error_msg']="Minimum Withdrawal Amount Should be ".$o->minimum_withdrawal_amount." ";
		echo json_encode($result);
		die();	
	}

	$sql="Select * from bank where user_id='".$o6->user_id."' and is_active='1' ";
	$res = getXbyY($sql);
	$row = count($res);

	if ($row > "0") {

	}else{
		$result['error']="1";
		$result['error_msg']="Please Add Bank to Proceed";
		echo json_encode($result);
		die();
    }
	$o1->bank_id = $res[0]['bank_id'];
	$o1->country_id = $_POST['country_id'];
	$o2 = $factory->get_object($o1->country_id,"countries" , "country_id");

	$o1->total_amount = $_POST['amount'];
	if ($o2->commission_type =="percentage") {
		$surcharge_value = ($o1->total_amount * $o2->surcharge)/100; 

	}else{
		$surcharge_value = $o2->surcharge; 
	}
 		 		$o6->amount_balance =$o6->amount_balance - $o1->total_amount;
$o6->user_id = $updater->update_object($o6,"users");

	$o1->amount = $o1->total_amount - $surcharge_value;
	$o1->user_id  = $o6->user_id;
	$o1->status ="Pending";
	$o1->is_active='1';
	$o1->created_at = todaysDate();

	$o3->user_id = $o6->user_id;
	$o3->user_name =$o6->user_name;
	$o3->transaction_type = "Withdrawal Money";
	$o3->user_old_balance = $o6->amount_balance;
	$o3->amount = $o1->total_amount;
	$o3->user_new_balance = $o3->user_old_balance - $o3->amount;
	$o3->status ="Pending";
	$o3->created_at = todaysDate();
	$o3->transaction_details="Request to Withdrawal Amount of ".$o3->amount." at ".$o3->created_at;
	$o3->month_year = date("F") . "-" . date('Y');
	$o3->year = date('Y');
	$o3->ref_number =reference_number();
	$o3->transaction_date =todaysDate();
	$o3->wallet_id = $insertor->insert_object($o3,"wallet");

    $o5->is_active='1';
	$o5->parent_id = $o3->wallet_id;
	$o5->amount = $surcharge_value;
	$o5->transaction_type = "Commission";
	$o5->ref_number = reference_number();
	$o5->status = "Pending";
	$o5->transaction_date =$_POST['date'];
	$o5->user_id = $o6->user_id;
	$o5->month_year = date("F") . "-" . date('Y');
	$o5->year = date('Y');
	$o5->transaction_details = "Commission Value cut against the amount of".$_POST['amount'];
	$o5->user_name = $o6->user_name.' '.$o6->name;
	$o5->created_at = todaysDate();
	$o5->wallet_id = $insertor->insert_object($o5,"wallet");
	

$o4 = $factory->get_object("1", "users" , "user_id");  
		$email_to =$o4->email;
		$email_from = $o6->email;
		$email_subject = "New  Money Withdrawal request";
		//$email_message = "Verification Code : ".$o6->new_password;
		include "mails/withdrawal_request.php";

		sendmail($email_from, $email_to, $email_subject, $email_message);



	$o1->wallet_id = $o3->wallet_id;
	$o1->withdrawal_request_id = $insertor->insert_object($o1, "withdrawal_request");

	$result['error_msg']="Request Sent Successfully";
	$result['error']="0";
}else{
	$result['error']="1";
}
echo json_encode($result);
?>