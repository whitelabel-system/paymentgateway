<?php
session_start();
include 'include.php';
include 'session.php';

if ($_POST['updte']=="1") {

$sql ="UPDATE kyc SET   "



$result['error']="0";
$result['error_msg']="Removed Successfully";

}else{
	$result['error']="1";
	$result['error_msg']="Something Went Wrong";
}

echo json_encode($result);
?>