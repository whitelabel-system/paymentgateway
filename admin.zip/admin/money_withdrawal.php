<?php
session_start();
include"include.php";
include"session.php";
$page_name="money_withdrawal";
if(isset($_GET['aid'])){
$user_id = $_GET['aid'];
}else{
	$user_id = 0;
}

include 'includes/header.php';
include 'html/money_withdrawal.php';
include 'includes/footer.php';
include 'js/money_withdrawal.js';
?>