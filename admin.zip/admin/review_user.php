<?php
session_start();
include"include.php";
include"session.php";
$page_name="review_user";
$o1->user_id = $_GET['aid'];
$o1= $factory->get_object($o1->user_id , "users","user_id");
if ($o1->plan_id>"0") {
$o2 = $factory->get_object($o1->plan_id , "user_setting","user_setting_id");
}
// pt($o2);
$sql ="Select * from user_card_process where user_id ='".$o1->user_id."'  and status='Yes' order by user_card_process_id desc ";
$res = getXbyY($sql);
$row = count($res);
$slq_ser = "Select * from user_services Where user_id='".$o1->user_id."' ";
$res_ser =getXbyY($slq_ser);
$row_ser = count($res_ser);

include "includes/header.php";
include "html/review_user.php";
include "includes/footer.php";
?>