<?php
session_start();

include "include.php";
include "session.php";

$ajax_logout = 1;

$sql_request_money = "Select * from request_money where requested_user_id = ".$o->user_id." and is_active = 1 and status = 'Pending' order by request_money_id DESC limit 0,20";
$res_request_money = getXbyY($sql_request_money);
$row_request_money = count($res_request_money);


include "html/my_request_money.php";

?>

