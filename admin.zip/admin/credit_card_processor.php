<?php
session_start();

include "include.php";
include "session.php";

$tables = 1;


$sql = "Select * from credit_card_processor order by processor_name";
$res = getXbyY($sql);
$rows = count($res);	

include "includes/header.php";
include "html/credit_card_processor.php";
include "includes/footer.php";
?>