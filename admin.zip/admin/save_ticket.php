<?php

session_start();
include "include.php";
include "session.php";

if ($updte == 1) {
    if (isset($_POST['ticket_id'])) {
	$o1->ticket_id = $_POST['ticket_id'];
    } else {
	$o1->ticket_id = 0;
    }
//pt($_POST); 
    if ($o1->ticket_id > 0) {
	$o1 = $factory->get_object($o1->ticket_id, "tickets", "ticket_id");
    }

    $o2->user_id = $_POST['user_id'];
    $o2 = $factory->get_object($o2->user_id, "users", "user_id");
    $o1->user_id = $o2->user_id;
    $o1->sent_by = $o->user_type;
    $o1->email = $o2->email;
    $o1->name = $o2->name;
    $o1->mobile = $o2->mobile;
    $o1->ticket_type = $_POST['ticket_type'];
    $o1->status = "Pending";
    $o1->subject = $_POST['subject'];
    $o1->message = $_POST['message'];
    $o1->is_active = 1;
    $o1->is_read = "No";
    $o1->assigned_user = 0;
    $o1->parent_id = 0;
    $o1->priority = $_POST['priority'];
    $o1->department = $_POST['department'];
    $o1->assign_to = $_POST['assign_to'];
    if ($_POST['withdrawal_request_id'] > 0) {
	$o1->withdrawal_request_id = $_POST['withdrawal_request_id'];
	$result['page'] = "pending_settlements"; 
    } else if ($_POST['dispute_id'] > 0) {
	
	$result['page'] = "dispute"; 
    }  else if ($_POST['wallet_id'] > 0) {
	 $o1->wallet_id = $_POST['wallet_id'];
	$result['page'] = "refunds"; 
	$o7->user_id = $_POST['user_id'];
	$o7->status = 'Ticket';
	$o7->is_active = '1';
	$o7->wallet_id = $_POST['wallet_id'];
	$insertor->insert_object($o7,"refund");
	
    }
    $get_tickets = "select * from tickets where parent_id = 0";
    $res = getXbyY($get_tickets);
    $ticket_count = count($res);
    $initial = 1;
    $o1->ticket_number = "T00" . ($initial + $ticket_count);
 
    if ($o1->ticket_id > 0) {
	$o1->updated_at = todaysDate();
	$o1->ticket_id = $updater->update_object($o1, "tickets");
	$result['error_msg'] = "Ticket Updated Successfully";
    } else {
	$o1->created_at = todaysDate();
	$o1->updated_at = todaysDate();
	$o1->ticket_id = $insertor->insert_object($o1, "tickets");
	$result['error_msg'] = "Ticket Added Successfully";
	insert_notifications($o1->user_id, "New Ticket Added By" . $o1->name, "ticket");
    }
    $attachement_count = count($_FILES['attachment']['name']);
    for ($j = 0; $j < $attachement_count; $j++) {

	if ($_FILES['attachment']['name'][$j] != "") {

	    $sql = "Select * from ticket_attachment where ticket_id='" . $o1->ticket_id . "' ";
	    $res = getXbyY($sql);
	    $row = count($res);


	    $o5->send_by = $o->user_type;
	    $o5->ticket_id = $o1->ticket_id;
	    $o5->is_active = '1';
	    $ext = explode(".", $_FILES['attachment']['name'][$j]);



	    $tmpfile = $_FILES['attachment']['tmp_name'][$j];

	    $source = "../img/";



	    $destination = $row . "_" . $o1->ticket_number . "." . end($ext);

	    $thumbnail = 0;

	    $newsize = 250;

	    $watermark = '';



	    uploadimage($tmpfile, $source, $destination, $thumbnail, $newsize, $watermark);

	    $o5->ticket_file = $destination;
	    $o5->ticket_attachment_id = $insertor->insert_object($o5, "ticket_attachment");
	}
	$result['error'] = 0;
    }
} else {
    $result['error'] = 1;
    $result['error_msg'] = "Something went wrong. Please try again";
}

echo json_encode($result);
?>