<?php

session_start();
include "include.php";

if ($updte == 1) {
    $o->mobile = $_POST['mobile'];
    $o->password = cpassword($_POST['password']);

    $sql_check = "Select user_id, mobile, email, password from users where (mobile ='" . $o->mobile . "' or email = '" . $o->mobile . "') and password='" . $o->password . "' and (user_type = 'Admin' or user_type = 'Staff')";
    $res_check = getXbyY($sql_check);
    $row_check = count($res_check);

    if ($row_check == 1) {
        $o = $factory->get_object($res_check[0]['user_id'], "users", "user_id");



        if ($o->is_active == "1") {

            $_SESSION['admin_id'] = $res_check[0]['user_id'];
            $_SESSION['user_name'] = $o->user_name;
            $_SESSION['last_login'] = $o->last_login;

            $o->last_login = todaysDate();

            $o->user_id = $updater->update_object($o, "users");

            $result['error'] = 0;
            $result['error_msg'] = "Perfect Match. Taking you to Dashboard";
        } else {



            $result['error'] = 1;
            $result['error_msg'] = "User Blocked";
        }
    } else {
        $result['error'] = 1;
        $result['error_msg'] = "Username / Password Mismatch. Please try again";
    }
} else {
    $result['error'] = 1;
    $result['error_msg'] = "Something went wrong. Please try again";
}

echo json_encode($result);
?>