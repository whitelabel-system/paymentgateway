<?php
session_start();
include "include.php";
include "session.php";
$editor="1";

if (isset($_GET['aid'])) {
	$o1->ticket_id = $_GET['aid'];
} else {
	$o1->ticket_id = 0;
}
if ($o1->ticket_id > 0) {
	$o1 = $factory->get_object($o1->ticket_id, "tickets", "ticket_id");
} else {
	$o1->is_active = 1;
}

$sql = "select * from tickets where ticket_number ='".$o1->ticket_number."' ";
$res = getXbyY($sql);
$rows = count($res);

$sql_attachement = "select * from ticket_attachment Where ticket_id ='".$o1->ticket_id."' order by ticket_attachment_id desc ";
$res_attachement = getXbyY($sql_attachement);
$row_attachement = count($res_attachement);

include "includes/header.php";
include "html/ticket_reply.php";
include "includes/footer.php";
include "js/ticket_reply.js"
?>