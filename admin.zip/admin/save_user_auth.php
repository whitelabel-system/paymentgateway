 <?php

session_start();
include "include.php";
include "session.php";

if ($_POST['updte'] ==1) {

	$user=$_POST['id'];
	$status=$_POST['status'];
	$sql_update="update users set otp_enabled='".$status."' where user_id='".$user."' ";
	$res_update=setXbyY($sql_update);
	

	$result['error']=1;
	

} else {

	$result['error']=0;
	
}

echo json_encode($result);