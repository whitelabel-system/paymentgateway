<?php
session_start();

include "include.php";
include "session.php";
$ajax_logout = 1;

unset($_SESSION['chargeback_search']);

$from_date = $_POST['from_date'];
$to_date = $_POST['to_date'];

$user_id = $_POST['user_id'];
$status = $_POST['status'];

if ($from_date != "") {
	$_SESSION['chargeback_search']['from_date'] = $from_date ;
}
if ($to_date != "") {
	$_SESSION['chargeback_search']['to_date'] = $to_date ;
}
if ($status !="") {
	$_SESSION['chargeback_search']['status'] = $status ;
	
}

if ($user_id > 0 ) {
	$_SESSION['chargeback_search']['user_id'] = $user_id;
}


?>